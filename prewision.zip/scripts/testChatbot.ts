import { askPerplexityBTP } from "../server/_core/perplexityClient";

async function testChatbot() {
  console.log("🧪 Test du chatbot avec la question: 'Quels EPI pour un chantier ?'");
  console.log("---");

  try {
    const question = "Quels EPI pour un chantier ?";
    console.log(`Question: ${question}\n`);

    const response = await askPerplexityBTP(question);
    
    console.log("Réponse du chatbot:");
    console.log(response);
    console.log("\n---");
    
    // Count words
    const wordCount = response.split(/\s+/).length;
    console.log(`Nombre de mots: ${wordCount}`);
    console.log(`Respecte la limite de 100 mots: ${wordCount <= 100 ? "✅ OUI" : "❌ NON"}`);
    
  } catch (error) {
    console.error("❌ Erreur lors du test:", error);
  }
}

testChatbot();

