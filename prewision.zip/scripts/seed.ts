import "dotenv/config";
import { drizzle } from "drizzle-orm/mysql2";
import { organizations, news } from "../drizzle/schema";

async function seed() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const db = drizzle(process.env.DATABASE_URL);

  console.log("🌱 Seeding database...");

  // Insert organizations
  const orgsData = [
    {
      name: "OPPBTP",
      description: "Organisme Professionnel de Prévention du Bâtiment et des Travaux Publics - Premier réseau de prévention du BTP en France",
      website: "https://www.oppbtp.com",
      logo: "https://www.oppbtp.com/wp-content/uploads/2020/01/logo-oppbtp.svg",
      category: "OPPBTP" as const,
      isActive: true,
    },
    {
      name: "PreventionBTP.fr",
      description: "Portail complet de l'OPPBTP dédié à la prévention des risques dans le BTP",
      website: "https://www.preventionbtp.fr",
      logo: "https://www.preventionbtp.fr/static/logo.svg",
      category: "OPPBTP" as const,
      isActive: true,
    },
    {
      name: "INRS",
      description: "Institut National de Recherche et de Sécurité - Organisme de recherche en santé et sécurité au travail",
      website: "https://www.inrs.fr",
      logo: "https://www.inrs.fr/media/logo-inrs.svg",
      category: "INRS" as const,
      isActive: true,
    },
    {
      name: "FFB",
      description: "Fédération Française du Bâtiment - Représentant les entreprises du secteur",
      website: "https://www.ffbatiment.fr",
      logo: "https://www.ffbatiment.fr/logo.svg",
      category: "FFB" as const,
      isActive: true,
    },
    {
      name: "CARSAT",
      description: "Caisses d'Assurance Retraite et de la Santé au Travail - Prévention des risques professionnels par région",
      website: "https://www.carsat.fr",
      logo: "https://www.carsat.fr/logo.svg",
      category: "CARSAT" as const,
      isActive: true,
    },
  ];

  try {
    await db.insert(organizations).values(orgsData);
    console.log("✅ Organizations inserted successfully");
  } catch (error) {
    console.log("ℹ️  Organizations already exist or error occurred");
  }

  // Insert news articles
  const newsData = [
    {
      organizationId: 1,
      title: "Colloque 'Droit de la prévention' : vers une simplification du droit pour renforcer la prévention",
      description: "L'OPPBTP organise un colloque sur le droit de la prévention pour simplifier les régulations et renforcer la sécurité",
      content: "L'OPPBTP a organisé un colloque consacré au droit de la prévention, réunissant des experts du secteur pour discuter de la simplification des réglementations...",
      imageUrl: "https://www.oppbtp.com/wp-content/uploads/2025/10/colloque-droit.jpg",
      sourceUrl: "https://www.oppbtp.com/actualites/",
      category: "Regulation" as const,
      publishedAt: new Date("2025-10-22"),
      isActive: true,
    },
    {
      organizationId: 1,
      title: "Enquête sur la prévention des risques au sein des entreprises du BTP",
      description: "L'OPPBTP publie les résultats d'une enquête nationale sur l'état de la prévention dans les entreprises du BTP",
      content: "Les résultats de l'enquête montrent une amélioration significative de la culture de prévention dans le secteur du BTP...",
      imageUrl: "https://www.oppbtp.com/wp-content/uploads/2025/10/enquete-prevention.jpg",
      sourceUrl: "https://www.oppbtp.com/actualites/",
      category: "Prevention" as const,
      publishedAt: new Date("2025-10-20"),
      isActive: true,
    },
    {
      organizationId: 1,
      title: "Lab Innovation Santé & Prévention dans le BTP : une nouvelle approche collaborative",
      description: "Lancement d'un laboratoire d'innovation pour développer de nouvelles solutions en santé et prévention du BTP",
      content: "Le Lab Innovation réunit les acteurs du BTP pour co-créer des solutions innovantes en matière de santé et sécurité...",
      imageUrl: "https://www.oppbtp.com/wp-content/uploads/2025/10/lab-innovation.jpg",
      sourceUrl: "https://www.oppbtp.com/actualites/",
      category: "Innovation" as const,
      publishedAt: new Date("2025-10-15"),
      isActive: true,
    },
    {
      organizationId: 1,
      title: "Sécurité et prévention sur les chantiers : signature de la charte 'Chantier Franchement Sûr'",
      description: "Plusieurs organismes signent une charte commune pour promouvoir la sécurité sur les chantiers",
      content: "L'OPPBTP, la FFB et les CARSAT régionales signent une charte commune pour renforcer la sécurité sur les chantiers du BTP...",
      imageUrl: "https://www.oppbtp.com/wp-content/uploads/2025/10/charte-securite.jpg",
      sourceUrl: "https://www.oppbtp.com/actualites/",
      category: "Safety" as const,
      publishedAt: new Date("2025-10-06"),
      isActive: true,
    },
    {
      organizationId: 1,
      title: "Risques chimiques dans le BTP : une campagne de prévention pour protéger les travailleurs",
      description: "Campagne nationale de sensibilisation aux risques chimiques dans le secteur du bâtiment",
      content: "L'OPPBTP lance une campagne de prévention pour sensibiliser les travailleurs du BTP aux risques liés aux produits chimiques...",
      imageUrl: "https://www.oppbtp.com/wp-content/uploads/2025/10/risques-chimiques.jpg",
      sourceUrl: "https://www.oppbtp.com/actualites/",
      category: "Health" as const,
      publishedAt: new Date("2025-10-02"),
      isActive: true,
    },
    {
      organizationId: 3,
      title: "Prospective : l'INRS propulse le BTP en 2050",
      description: "L'INRS publie une étude prospective sur l'évolution du BTP et les défis de prévention à long terme",
      content: "L'INRS analyse les tendances futures du BTP et les implications pour la prévention des risques professionnels...",
      imageUrl: "https://www.inrs.fr/wp-content/uploads/2025/04/prospective-btp-2050.jpg",
      sourceUrl: "https://www.inrs.fr/",
      category: "Prevention" as const,
      publishedAt: new Date("2025-04-07"),
      isActive: true,
    },
    {
      organizationId: 4,
      title: "Semaine de la Prévention 2025 : programme complet de webinaires et formations",
      description: "La FFB organise une semaine dédiée à la prévention avec des webinaires et formations en ligne",
      content: "La Semaine de la Prévention 2025 propose un programme complet de webinaires et formations pour sensibiliser les entreprises du BTP...",
      imageUrl: "https://www.ffbatiment.fr/wp-content/uploads/2025/03/semaine-prevention.jpg",
      sourceUrl: "https://www.ffbatiment.fr/",
      category: "Training" as const,
      publishedAt: new Date("2025-03-31"),
      isActive: true,
    },
    {
      organizationId: 2,
      title: "Malaises mortels au travail : l'INRS préconise une meilleure prévention des risques cardiovasculaires",
      description: "Étude de l'INRS sur les accidents mortels liés aux problèmes cardiovasculaires dans le BTP",
      content: "L'INRS recommande une meilleure prévention des risques cardiovasculaires sur les chantiers du BTP...",
      imageUrl: "https://www.preventionbtp.fr/wp-content/uploads/2025/10/risques-cardiovasculaires.jpg",
      sourceUrl: "https://www.preventionbtp.fr/",
      category: "Health" as const,
      publishedAt: new Date("2025-10-10"),
      isActive: true,
    },
  ];

  try {
    await db.insert(news).values(newsData);
    console.log("✅ News inserted successfully");
  } catch (error) {
    console.log("ℹ️  News already exist or error occurred");
  }

  console.log("✨ Seeding completed!");
}

seed().catch((error) => {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
});

