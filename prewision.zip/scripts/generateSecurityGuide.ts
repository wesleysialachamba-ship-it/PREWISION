/**
 * Generate Security Guide Content using Perplexity AI
 * Run with: pnpm tsx scripts/generateSecurityGuide.ts
 */

import { callPerplexityWithHistory } from "../server/_core/perplexityClient";

async function generateSecurityGuide() {
  console.log("🤖 Generating BTP Security Guide 2025 with Perplexity AI...\n");

  try {
    // Generate comprehensive guide content
    const prompt = `Crée un guide complet sur les meilleures pratiques de sécurité BTP 2025 en français. 
Le guide doit couvrir:
1. Travaux en hauteur (équipements, prévention des chutes)
2. Équipements de Protection Individuelle (EPI) obligatoires
3. Normes DTU applicables
4. Prévention des risques chimiques
5. Formation et sensibilisation

Écris de manière claire et professionnelle, sans références ou citations. 
Structure avec des sections bien définies. Environ 800 mots.
Utilise des informations factuelles et à jour pour 2025.`;

    const response = await callPerplexityWithHistory(prompt, [
      {
        role: "system",
        content: `Tu es un expert en sécurité et santé au travail dans le BTP. 
Fournis un guide complet, clair et factuel sur les meilleures pratiques de sécurité.
Utilise un ton professionnel et informatif.
Pas de références ou citations dans le texte.
Réponds en français uniquement.`,
      },
    ]);

    console.log("✅ Generated Guide Content:\n");
    console.log(response);
    console.log("\n✅ Content generation completed!");

    return response;
  } catch (error) {
    console.error("❌ Error generating guide:", error);
    process.exit(1);
  }
}

// Run the generation
generateSecurityGuide().catch(console.error);

