/**
 * Test script for the 30-minute free access system
 */

import { createOrGetTempSession, checkTempSessionValidity, formatRemainingTime } from "../server/_core/tempSessionService";
import { registerUser, authenticateUser, getUserByEmail } from "../server/_core/localUserService";

async function runTests() {
  console.log("🧪 Starting Access System Tests...\n");

  try {
    // Test 1: Create temporary session
    console.log("✓ Test 1: Creating temporary session for IP 192.168.1.1");
    const session = await createOrGetTempSession("192.168.1.1");
    console.log(`  - Session created: ${session.sessionId}`);
    console.log(`  - Expires at: ${session.expiresAt}`);
    console.log(`  - Remaining: ${formatRemainingTime(session.remainingMs)}\n`);

    // Test 2: Check session validity
    console.log("✓ Test 2: Checking session validity");
    const validity = await checkTempSessionValidity("192.168.1.1");
    console.log(`  - Is valid: ${validity.isValid}`);
    console.log(`  - Remaining MS: ${validity.remainingMs}`);
    console.log(`  - Formatted: ${formatRemainingTime(validity.remainingMs)}\n`);

    // Test 3: Register user
    console.log("✓ Test 3: Registering new user");
    const registerResult = await registerUser({
      email: "testuser@example.com",
      password: "TestPassword123",
      name: "Test User",
    });
    console.log(`  - Success: ${registerResult.success}`);
    console.log(`  - User ID: ${registerResult.userId}\n`);

    // Test 4: Authenticate user
    console.log("✓ Test 4: Authenticating user");
    const authResult = await authenticateUser("testuser@example.com", "TestPassword123");
    console.log(`  - Success: ${authResult.success}`);
    console.log(`  - User ID: ${authResult.userId}`);
    console.log(`  - Email: ${authResult.email}`);
    console.log(`  - Name: ${authResult.name}\n`);

    // Test 5: Get user by email
    console.log("✓ Test 5: Retrieving user by email");
    const user = await getUserByEmail("testuser@example.com");
    console.log(`  - User found: ${user !== null}`);
    if (user) {
      console.log(`  - Email: ${user.email}`);
      console.log(`  - Name: ${user.name}`);
      console.log(`  - Active: ${user.isActive}`);
      console.log(`  - Email verified: ${user.isEmailVerified}\n`);
    }

    // Test 6: Invalid authentication
    console.log("✓ Test 6: Testing invalid authentication");
    const invalidAuth = await authenticateUser("testuser@example.com", "WrongPassword");
    console.log(`  - Success: ${invalidAuth.success}`);
    console.log(`  - Error: ${invalidAuth.error}\n`);

    // Test 7: Duplicate registration
    console.log("✓ Test 7: Testing duplicate registration");
    const duplicateReg = await registerUser({
      email: "testuser@example.com",
      password: "AnotherPassword123",
    });
    console.log(`  - Success: ${duplicateReg.success}`);
    console.log(`  - Error: ${duplicateReg.error}\n`);

    console.log("✅ All tests passed successfully!\n");

    // Summary
    console.log("📊 System Summary:");
    console.log("  - Free access duration: 30 minutes per IP");
    console.log("  - User registration: Enabled with email validation");
    console.log("  - Password hashing: bcrypt with 10 rounds");
    console.log("  - Session tracking: IP-based temporary sessions");
    console.log("  - Admin dashboard: Available at /admin");
    console.log("  - Login/Register: Available at /login and /register");

  } catch (error) {
    console.error("❌ Test failed:", error);
    process.exit(1);
  }
}

runTests();

