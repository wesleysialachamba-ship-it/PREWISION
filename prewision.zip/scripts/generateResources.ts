/**
 * Generate and seed resources (PDFs)
 * Run with: pnpm tsx scripts/generateResources.ts
 */

import {
  generateChecklistPDF,
  generateEPIGuidePDF,
  generateHeightWorksPDF,
} from "../server/_core/pdfGenerator";
import { addResource } from "../server/resourcesDb";
import { storagePut } from "../server/storage";

async function generateResources() {
  console.log("📄 Generating BTP Resources PDFs...\n");

  try {
    // Generate Checklist PDF
    console.log("📝 Generating Checklist Sécurité Chantier...");
    const checklistPDF = await generateChecklistPDF();
    const checklistResult = await storagePut(
      "resources/checklist-securite-chantier.pdf",
      checklistPDF,
      "application/pdf"
    );

    await addResource({
      title: "Checklist Sécurité Chantier",
      description:
        "Checklist complète pour vérifier tous les éléments essentiels de sécurité sur votre chantier. Inclut les vérifications avant, pendant et après les travaux.",
      category: "Sécurité",
      fileUrl: checklistResult.url,
      fileName: "checklist-securite-chantier.pdf",
      fileSize: checklistPDF.length,
      isActive: true,
    });
    console.log("✅ Checklist created and uploaded\n");

    // Generate EPI Guide PDF
    console.log("📝 Generating Guide Complet des EPI...");
    const epiPDF = await generateEPIGuidePDF();
    const epiResult = await storagePut(
      "resources/guide-epi-complet.pdf",
      epiPDF,
      "application/pdf"
    );

    await addResource({
      title: "Guide Complet des Équipements de Protection Individuelle",
      description:
        "Guide détaillé sur tous les types d'EPI obligatoires dans le BTP. Inclut les normes, l'utilisation correcte et la maintenance.",
      category: "EPI",
      fileUrl: epiResult.url,
      fileName: "guide-epi-complet.pdf",
      fileSize: epiPDF.length,
      isActive: true,
    });
    console.log("✅ EPI Guide created and uploaded\n");

    // Generate Height Works PDF
    console.log("📝 Generating Normes Travaux en Hauteur...");
    const heightPDF = await generateHeightWorksPDF();
    const heightResult = await storagePut(
      "resources/normes-travaux-hauteur.pdf",
      heightPDF,
      "application/pdf"
    );

    await addResource({
      title: "Normes de Sécurité pour les Travaux en Hauteur",
      description:
        "Guide complet des normes et procédures de sécurité pour les travaux en hauteur. Inclut les équipements obligatoires et les formations requises.",
      category: "Travaux en Hauteur",
      fileUrl: heightResult.url,
      fileName: "normes-travaux-hauteur.pdf",
      fileSize: heightPDF.length,
      isActive: true,
    });
    console.log("✅ Height Works Guide created and uploaded\n");

    console.log("✅ All resources generated and uploaded successfully!");
  } catch (error) {
    console.error("❌ Error generating resources:", error);
    process.exit(1);
  }
}

generateResources().catch(console.error);

