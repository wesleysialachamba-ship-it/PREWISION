/**
 * Test script for conversation history functionality
 * Tests the complete flow of creating conversations, adding messages, and retrieving history
 */

import { getDb } from "../server/db";
import {
  createConversation,
  getUserConversations,
  getConversationWithMessages,
  addMessageToConversation,
  updateConversationTitle,
  archiveConversation,
  deleteConversation,
} from "../server/chatDb";

async function testConversationHistory() {
  console.log("🧪 Starting Conversation History Tests...\n");

  try {
    const db = await getDb();
    if (!db) {
      throw new Error("Database not available");
    }

    const testEmail = "test@example.com";

    // Test 1: Create a conversation
    console.log("📝 Test 1: Creating a new conversation...");
    const conversationId = await createConversation(testEmail, "Test Conversation");
    console.log(`✅ Conversation created with ID: ${conversationId}\n`);

    // Test 2: Add messages to the conversation
    console.log("💬 Test 2: Adding messages to conversation...");
    const userMessageId = await addMessageToConversation(
      conversationId,
      "user",
      "Quels sont les EPI obligatoires sur un chantier ?"
    );
    console.log(`✅ User message added with ID: ${userMessageId}`);

    const assistantMessageId = await addMessageToConversation(
      conversationId,
      "assistant",
      "Les équipements de protection individuelle (EPI) obligatoires incluent : casque de sécurité, gilet de visibilité, chaussures de sécurité, et gants de protection."
    );
    console.log(`✅ Assistant message added with ID: ${assistantMessageId}\n`);

    // Test 3: Add another message with image
    console.log("🖼️  Test 3: Adding message with image...");
    const imageMessageId = await addMessageToConversation(
      conversationId,
      "assistant",
      "Voici une illustration des EPI essentiels.",
      "https://example.com/epi-image.jpg",
      "Équipements de protection individuelle"
    );
    console.log(`✅ Message with image added with ID: ${imageMessageId}\n`);

    // Test 4: Retrieve conversation with messages
    console.log("📖 Test 4: Retrieving conversation with messages...");
    const conversation = await getConversationWithMessages(conversationId);
    if (conversation) {
      console.log(`✅ Conversation retrieved:`);
      console.log(`   - Title: ${conversation.title}`);
      console.log(`   - Message count: ${conversation.messageCount}`);
      console.log(`   - Messages: ${conversation.messages.length}`);
      conversation.messages.forEach((msg, idx) => {
        console.log(`     ${idx + 1}. [${msg.role.toUpperCase()}] ${msg.content.substring(0, 50)}...`);
      });
    } else {
      console.log("❌ Failed to retrieve conversation");
    }
    console.log();

    // Test 5: Update conversation title
    console.log("✏️  Test 5: Updating conversation title...");
    await updateConversationTitle(conversationId, "EPI et Sécurité BTP");
    const updatedConv = await getConversationWithMessages(conversationId);
    console.log(`✅ Title updated to: "${updatedConv?.title}"\n`);

    // Test 6: Create another conversation
    console.log("📝 Test 6: Creating another conversation...");
    const conversationId2 = await createConversation(testEmail, "Travaux en Hauteur");
    await addMessageToConversation(
      conversationId2,
      "user",
      "Quelles sont les normes pour les travaux en hauteur ?"
    );
    await addMessageToConversation(
      conversationId2,
      "assistant",
      "Les travaux en hauteur doivent respecter les normes EN 795 et EN 353. Un harnais de sécurité est obligatoire."
    );
    console.log(`✅ Second conversation created with ID: ${conversationId2}\n`);

    // Test 7: Get all user conversations
    console.log("📚 Test 7: Retrieving all user conversations...");
    const userConversations = await getUserConversations(testEmail);
    console.log(`✅ Retrieved ${userConversations.length} conversations:`);
    userConversations.forEach((conv) => {
      console.log(`   - "${conv.title}" (${conv.messageCount} messages, created: ${new Date(conv.createdAt).toLocaleDateString("fr-FR")})`);
    });
    console.log();

    // Test 8: Archive a conversation
    console.log("📦 Test 8: Archiving a conversation...");
    await archiveConversation(conversationId);
    const archivedConv = await getConversationWithMessages(conversationId);
    console.log(`✅ Conversation archived: ${archivedConv?.isArchived}\n`);

    // Test 9: Get conversations after archiving (should exclude archived)
    console.log("📚 Test 9: Retrieving conversations after archiving...");
    const activeConversations = await getUserConversations(testEmail);
    console.log(`✅ Active conversations: ${activeConversations.length} (archived conversation excluded)\n`);

    // Test 10: Delete a conversation
    console.log("🗑️  Test 10: Deleting a conversation...");
    await deleteConversation(conversationId2);
    const remainingConversations = await getUserConversations(testEmail);
    console.log(`✅ Conversation deleted. Remaining: ${remainingConversations.length}\n`);

    console.log("✨ All tests completed successfully!");
    console.log("\n📊 Summary:");
    console.log(`   - Conversations created: 2`);
    console.log(`   - Messages added: 4`);
    console.log(`   - Conversations archived: 1`);
    console.log(`   - Conversations deleted: 1`);
    console.log(`   - Active conversations: ${remainingConversations.length}`);

  } catch (error) {
    console.error("❌ Test failed:", error);
    process.exit(1);
  }
}

// Run the tests
testConversationHistory().then(() => {
  process.exit(0);
});

