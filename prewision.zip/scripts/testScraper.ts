/**
 * Test script for article scraper and summarizer
 * Run with: pnpm tsx scripts/testScraper.ts
 */

import { scrapeArticlesFromSource, summarizeArticle, categorizeArticle } from "../server/_core/articleScraper";
import { addBlogArticle, articleExists } from "../server/blogDb";

const ARTICLE_SOURCES = [
  {
    name: "PreventionBTP - Actualités",
    url: "https://www.preventionbtp.fr/actualites",
    selector: ".article, .post, .news-item",
    titleSelector: "h2, h3, .title",
    linkSelector: "a",
    dateSelector: ".date, .published-date, time",
  },
];

async function testScraper() {
  console.log("🔍 Starting article scraper test...\n");

  try {
    const source = ARTICLE_SOURCES[0];
    console.log(`📡 Fetching articles from: ${source.name}`);
    console.log(`   URL: ${source.url}\n`);

    // Scrape articles
    const articles = await scrapeArticlesFromSource(source);

    if (articles.length === 0) {
      console.log("❌ No articles found. The website structure may have changed.");
      console.log("   Try updating the CSS selectors in articleScraper.ts");
      return;
    }

    console.log(`✅ Found ${articles.length} articles\n`);

    // Process first article
    if (articles.length > 0) {
      const article = articles[0];

      console.log("📰 First Article:");
      console.log(`   Title: ${article.title}`);
      console.log(`   URL: ${article.url}`);
      console.log(`   Excerpt: ${article.excerpt.substring(0, 100)}...\n`);

      // Check if article exists
      const exists = await articleExists(article.url);
      if (exists) {
        console.log("⚠️  Article already exists in database");
        return;
      }

      // Summarize article
      console.log("🤖 Summarizing article with Perplexity AI...");
      const summary = await summarizeArticle(article);

      console.log("✅ Summary generated:");
      console.log(`   ${summary}\n`);

      // Categorize article
      const category = categorizeArticle(article);
      console.log(`📂 Category: ${category}\n`);

      // Add to database
      console.log("💾 Adding article to database...");
      const blogArticle = await addBlogArticle({
        title: article.title,
        summary,
        originalUrl: article.url,
        sourceWebsite: article.source.url,
        sourceTitle: article.source.name,
        category,
        imageUrl: article.imageUrl,
        originalPublishedAt: article.publishedDate,
        isActive: true,
      });

      if (blogArticle) {
        console.log("✅ Article successfully added to database!");
        console.log(`   ID: ${blogArticle.id}`);
        console.log(`   Created: ${blogArticle.createdAt}`);
      } else {
        console.log("❌ Failed to add article to database");
      }
    }

    console.log("\n✅ Test completed successfully!");
  } catch (error) {
    console.error("❌ Error during test:", error);
    process.exit(1);
  }
}

// Run the test
testScraper().catch(console.error);

