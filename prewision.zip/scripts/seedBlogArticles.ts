/**
 * Seed blog articles for testing
 * Run with: pnpm tsx scripts/seedBlogArticles.ts
 */

import { addBlogArticle } from "../server/blogDb";

const testArticles = [
  {
    title: "Nouvelles normes de sécurité pour les travaux en hauteur en 2024",
    summary:
      "Les organismes de prévention du BTP ont publié de nouvelles directives concernant la sécurité des travaux en hauteur. Ces normes renforcent les exigences en matière d'équipements de protection individuelle et imposent une formation obligatoire pour tous les travailleurs. Les entreprises doivent se conformer à ces nouvelles règles avant le 1er janvier 2025.",
    originalUrl: "https://www.preventionbtp.fr/actualites/normes-2024",
    sourceWebsite: "https://www.preventionbtp.fr",
    sourceTitle: "PreventionBTP",
    category: "Réglementation" as const,
    imageUrl: "https://via.placeholder.com/400x300?text=Normes+Sécurité",
    originalPublishedAt: new Date("2024-10-15"),
    isActive: true,
  },
  {
    title: "Webinaire : Prévention des risques chimiques sur les chantiers",
    summary:
      "L'INRS organise un webinaire gratuit sur la prévention des risques chimiques dans le secteur du BTP. Cette formation couvre l'identification des substances dangereuses, les équipements de protection appropriés et les procédures d'urgence. Le webinaire se déroulera en ligne et sera enregistré pour consultation ultérieure.",
    originalUrl: "https://www.inrs.fr/webinaires/risques-chimiques",
    sourceWebsite: "https://www.inrs.fr",
    sourceTitle: "INRS",
    category: "Formation" as const,
    imageUrl: "https://via.placeholder.com/400x300?text=Webinaire+INRS",
    originalPublishedAt: new Date("2024-10-10"),
    isActive: true,
  },
  {
    title: "Étude : Impact de la santé mentale sur la sécurité au travail",
    summary:
      "Une nouvelle étude menée par l'INRS révèle une corrélation significative entre la santé mentale des travailleurs et les incidents de sécurité. Les résultats montrent que les entreprises qui investissent dans le bien-être mental de leurs employés enregistrent une réduction de 30% des accidents du travail.",
    originalUrl: "https://www.inrs.fr/publications/etude-sante-mentale",
    sourceWebsite: "https://www.inrs.fr",
    sourceTitle: "INRS",
    category: "Santé" as const,
    imageUrl: "https://via.placeholder.com/400x300?text=Santé+Mentale",
    originalPublishedAt: new Date("2024-10-08"),
    isActive: true,
  },
  {
    title: "Innovations en équipements de protection : les nouveaux EPI du marché",
    summary:
      "Les fabricants d'équipements de protection proposent des innovations majeures pour améliorer le confort et la sécurité. Les nouveaux EPI intègrent des technologies intelligentes de monitoring, des matériaux plus légers et des designs ergonomiques. Ces innovations réduisent la fatigue des travailleurs tout en améliorant la conformité réglementaire.",
    originalUrl: "https://www.officiel-prevention.com/innovations-epi",
    sourceWebsite: "https://www.officiel-prevention.com",
    sourceTitle: "Officiel Prévention",
    category: "Innovation" as const,
    imageUrl: "https://via.placeholder.com/400x300?text=Innovations+EPI",
    originalPublishedAt: new Date("2024-10-05"),
    isActive: true,
  },
  {
    title: "Prévention des chutes : guide complet pour les entreprises",
    summary:
      "Ce guide complet de l'OPPBTP fournit des recommandations détaillées pour prévenir les chutes sur les chantiers. Il couvre l'évaluation des risques, la mise en place de protections collectives, l'utilisation des EPI et la formation des travailleurs. Le guide inclut également des études de cas et des bonnes pratiques d'entreprises.",
    originalUrl: "https://www.oppbtp.fr/guides/prevention-chutes",
    sourceWebsite: "https://www.oppbtp.fr",
    sourceTitle: "OPPBTP",
    category: "Prévention" as const,
    imageUrl: "https://via.placeholder.com/400x300?text=Prévention+Chutes",
    originalPublishedAt: new Date("2024-10-01"),
    isActive: true,
  },
  {
    title: "Rapport annuel 2024 : statistiques des accidents du travail en BTP",
    summary:
      "Le rapport annuel de la CARSAT révèle les statistiques des accidents du travail dans le secteur du BTP pour l'année 2024. Les données montrent une augmentation de 5% des accidents par rapport à l'année précédente, avec un focus particulier sur les travaux en hauteur et les risques chimiques. Des recommandations sont proposées pour améliorer la sécurité.",
    originalUrl: "https://www.carsat.fr/rapport-2024",
    sourceWebsite: "https://www.carsat.fr",
    sourceTitle: "CARSAT",
    category: "Sécurité" as const,
    imageUrl: "https://via.placeholder.com/400x300?text=Rapport+CARSAT",
    originalPublishedAt: new Date("2024-09-28"),
    isActive: true,
  },
];

async function seedBlogArticles() {
  console.log("🌱 Starting blog articles seed...\n");

  try {
    let addedCount = 0;

    for (const article of testArticles) {
      try {
        console.log(`📝 Adding article: "${article.title.substring(0, 50)}..."`);

        const result = await addBlogArticle(article);

        if (result) {
          console.log(`   ✅ Added (ID: ${result.id})\n`);
          addedCount++;
        } else {
          console.log(`   ❌ Failed to add\n`);
        }
      } catch (error) {
        console.error(`   ❌ Error:`, error);
        console.log();
      }
    }

    console.log(`\n✅ Seed completed! Added ${addedCount}/${testArticles.length} articles`);
  } catch (error) {
    console.error("❌ Error during seed:", error);
    process.exit(1);
  }
}

// Run the seed
seedBlogArticles().catch(console.error);

