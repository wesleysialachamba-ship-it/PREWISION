import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import {
  Download,
  ArrowLeft,
  FileText,
  AlertCircle,
  Loader2,
  CheckCircle,
} from "lucide-react";

interface DownloadFormData {
  name: string;
  email: string;
}

export default function Resources() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState<number | null>(null);
  const [formData, setFormData] = useState<DownloadFormData>({
    name: "",
    email: "",
  });
  const [downloadSuccess, setDownloadSuccess] = useState<number | null>(null);

  const resourcesQuery = trpc.resources.list.useQuery();
  const downloadMutation = trpc.resources.recordDownload.useMutation();

  const categories = [
    "Sécurité",
    "EPI",
    "Travaux en Hauteur",
    "Prévention",
    "Formation",
  ];

  const filteredResources = selectedCategory
    ? resourcesQuery.data?.filter((r) => r.category === selectedCategory)
    : resourcesQuery.data;

  const handleDownloadClick = (resourceId: number) => {
    setShowForm(resourceId);
    setFormData({ name: "", email: "" });
  };

  const handleSubmitForm = async (resourceId: number) => {
    if (!formData.email || !formData.name) {
      alert("Veuillez remplir tous les champs");
      return;
    }

    setDownloadingId(resourceId);

    try {
      // Record the download
      await downloadMutation.mutateAsync({
        resourceId,
        email: formData.email,
        name: formData.name,
      });

      // Find the resource and trigger download
      const resource = resourcesQuery.data?.find((r) => r.id === resourceId);
      if (resource) {
        const link = document.createElement("a");
        link.href = resource.fileUrl;
        link.download = resource.fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        setDownloadSuccess(resourceId);
        setShowForm(null);

        // Reset success message after 3 seconds
        setTimeout(() => setDownloadSuccess(null), 3000);
      }
    } catch (error) {
      console.error("Error recording download:", error);
      alert("Une erreur s'est produite. Veuillez réessayer.");
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Retour
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Ressources BTP
              </h1>
              <p className="text-sm text-slate-600">
                Guides et outils téléchargeables pour la sécurité
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Category Filter */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Filtrer par catégorie
            </h2>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                onClick={() => setSelectedCategory(null)}
              >
                Tous les ressources
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={
                    selectedCategory === category ? "default" : "outline"
                  }
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Resources Grid */}
          {resourcesQuery.isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          ) : resourcesQuery.error ? (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="pt-6 flex items-center gap-3">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <p className="text-red-800">
                  Erreur lors du chargement des ressources
                </p>
              </CardContent>
            </Card>
          ) : filteredResources && filteredResources.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources.map((resource) => (
                <Card key={resource.id} className="hover:shadow-lg transition">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <CardTitle className="text-base line-clamp-2">
                          {resource.title}
                        </CardTitle>
                        <p className="text-xs text-slate-500 mt-2">
                          {resource.category}
                        </p>
                      </div>
                      <FileText className="h-5 w-5 text-blue-600 flex-shrink-0" />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-slate-600 line-clamp-3">
                      {resource.description}
                    </p>

                    {downloadSuccess === resource.id && (
                      <div className="flex items-center gap-2 text-green-600 text-sm bg-green-50 p-2 rounded">
                        <CheckCircle className="h-4 w-4" />
                        Téléchargement en cours...
                      </div>
                    )}

                    {showForm === resource.id ? (
                      <div className="space-y-3 border-t pt-4">
                        <input
                          type="text"
                          placeholder="Votre nom"
                          value={formData.name}
                          onChange={(e) =>
                            setFormData({ ...formData, name: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="email"
                          placeholder="Votre email"
                          value={formData.email}
                          onChange={(e) =>
                            setFormData({ ...formData, email: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleSubmitForm(resource.id)}
                            disabled={downloadingId === resource.id}
                            className="flex-1 gap-2"
                            size="sm"
                          >
                            {downloadingId === resource.id ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Téléchargement...
                              </>
                            ) : (
                              <>
                                <Download className="h-4 w-4" />
                                Télécharger
                              </>
                            )}
                          </Button>
                          <Button
                            onClick={() => setShowForm(null)}
                            variant="outline"
                            size="sm"
                          >
                            Annuler
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Button
                        onClick={() => handleDownloadClick(resource.id)}
                        className="w-full gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Télécharger
                      </Button>
                    )}

                    <p className="text-xs text-slate-500 text-center">
                      {resource.downloadCount} téléchargement
                      {resource.downloadCount > 1 ? "s" : ""}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6 text-center text-slate-600">
                Aucune ressource disponible dans cette catégorie
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

