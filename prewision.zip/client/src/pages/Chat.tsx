import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Send, Loader2, AlertCircle, ArrowLeft, Lightbulb, Plus, Trash2, Archive, Edit2, Check, X } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  imageUrl?: string;
  imageSuggestion?: string;
}

interface Conversation {
  id: number;
  title: string;
  messageCount: number;
  createdAt: Date;
  updatedAt: Date;
  isArchived: boolean;
}

const SUGGESTED_QUESTIONS = [
  "Quels équipements de protection sont obligatoires sur un chantier ?",
  "Quelles sont les normes de sécurité pour les travaux en hauteur ?",
  "Comment prévenir les risques électriques sur un chantier ?",
];

// Component to render message content with proper formatting
function MessageContent({ content }: { content: string }) {
  // Split content by bullet points or line breaks
  const lines = content.split(/\n|(?=•|-)/);
  const hasBullets = content.includes("•") || content.includes("-");

  if (hasBullets) {
    return (
      <div className="space-y-2">
        {lines.map((line, index) => {
          const trimmed = line.trim();
          if (!trimmed) return null;
          
          // Check if line starts with bullet or dash
          const isBullet = trimmed.startsWith("•") || trimmed.startsWith("-");
          const text = isBullet ? trimmed.substring(1).trim() : trimmed;
          
          return (
            <div key={index} className="flex gap-3">
              {isBullet && <span className="text-[#FF7A00] font-bold">•</span>}
              <p className="text-base leading-relaxed">{text}</p>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <p className="text-base leading-relaxed whitespace-pre-wrap">
      {content}
    </p>
  );
}

// Sidebar component for conversation history
function ConversationSidebar({
  conversations,
  currentConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  onArchiveConversation,
  isLoading,
}: {
  conversations: Conversation[];
  currentConversationId: number | null;
  onSelectConversation: (id: number) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: number) => void;
  onArchiveConversation: (id: number) => void;
  isLoading: boolean;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingTitle, setEditingTitle] = useState("");
  const updateTitleMutation = trpc.chat.updateTitle.useMutation();

  const handleSaveTitle = async (conversationId: number) => {
    if (editingTitle.trim()) {
      try {
        await updateTitleMutation.mutateAsync({
          conversationId,
          title: editingTitle,
        });
        setEditingId(null);
      } catch (error) {
        console.error("Failed to update title:", error);
      }
    }
  };

  return (
    <div className="w-64 bg-[#003D5C] text-white flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-[#FF7A00]">
        <Button
          onClick={onNewConversation}
          disabled={isLoading}
          className="w-full bg-[#FF7A00] hover:bg-[#E66A00] text-white font-bold flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Nouvelle conversation
        </Button>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {conversations.length === 0 ? (
          <p className="text-sm text-gray-300 text-center py-8">
            Aucune conversation pour le moment
          </p>
        ) : (
          conversations.map((conv) => (
            <div
              key={conv.id}
              className={`p-3 rounded-lg cursor-pointer transition-colors group ${
                currentConversationId === conv.id
                  ? "bg-[#FF7A00] text-white"
                  : "bg-[#004B7A] hover:bg-[#005A8F] text-gray-100"
              }`}
            >
              {editingId === conv.id ? (
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    className="flex-1 px-2 py-1 rounded bg-white text-[#003D5C] text-sm"
                    autoFocus
                  />
                  <button
                    onClick={() => handleSaveTitle(conv.id)}
                    className="p-1 hover:bg-white/20 rounded"
                  >
                    <Check className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="p-1 hover:bg-white/20 rounded"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => onSelectConversation(conv.id)}
                  className="flex-1"
                >
                  <p className="font-medium text-sm truncate">{conv.title}</p>
                  <p className="text-xs opacity-75 mt-1">
                    {conv.messageCount} messages
                  </p>
                  <p className="text-xs opacity-60 mt-1">
                    {new Date(conv.updatedAt).toLocaleDateString("fr-FR")}
                  </p>
                </div>
              )}

              {/* Action buttons */}
              {currentConversationId === conv.id && !editingId && (
                <div className="flex gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingId(conv.id);
                      setEditingTitle(conv.title);
                    }}
                    className="p-1 hover:bg-white/20 rounded flex-1 flex items-center justify-center"
                    title="Renommer"
                  >
                    <Edit2 className="h-3 w-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onArchiveConversation(conv.id);
                    }}
                    className="p-1 hover:bg-white/20 rounded flex-1 flex items-center justify-center"
                    title="Archiver"
                  >
                    <Archive className="h-3 w-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteConversation(conv.id);
                    }}
                    className="p-1 hover:bg-red-500/50 rounded flex-1 flex items-center justify-center"
                    title="Supprimer"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default function Chat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Bienvenue ! Je suis votre assistant IA spécialisé en prévention du BTP. Je peux vous aider à répondre à vos questions sur la sécurité, la santé au travail et les actualités du secteur. Comment puis-je vous aider ?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const [showSidebar, setShowSidebar] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // tRPC queries and mutations
  const conversationsQuery = trpc.chat.getConversations.useQuery();
  const createConversationMutation = trpc.chat.createConversation.useMutation();
  const addMessageMutation = trpc.chat.addMessage.useMutation();
  const deleteConversationMutation = trpc.chat.delete.useMutation();
  const archiveConversationMutation = trpc.chat.archive.useMutation();
  const getConversationQuery = trpc.chat.getConversation.useQuery(
    { conversationId: currentConversationId || 0 },
    { enabled: !!currentConversationId }
  );
  const saveChatMutation = trpc.chat.saveInteraction.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load conversation when selected
  useEffect(() => {
    if (currentConversationId && getConversationQuery.data) {
      const conv = getConversationQuery.data;
      if (conv && conv.messages) {
        const loadedMessages: Message[] = conv.messages.map((msg) => ({
          id: msg.id.toString(),
          role: msg.role,
          content: msg.content,
          timestamp: new Date(msg.createdAt),
          imageUrl: msg.imageUrl || undefined,
          imageSuggestion: msg.imageSuggestion || undefined,
        }));
        setMessages(loadedMessages);
        setShowSuggestions(false);
      }
    }
  }, [getConversationQuery.data, currentConversationId]);

  const handleNewConversation = async () => {
    try {
      const result = await createConversationMutation.mutateAsync({
        title: "Nouvelle conversation",
      });
      setCurrentConversationId(result.conversationId);
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: "Bienvenue ! Je suis votre assistant IA spécialisé en prévention du BTP. Je peux vous aider à répondre à vos questions sur la sécurité, la santé au travail et les actualités du secteur. Comment puis-je vous aider ?",
          timestamp: new Date(),
        },
      ]);
      setShowSuggestions(true);
      setInput("");
      await conversationsQuery.refetch();
    } catch (error) {
      console.error("Failed to create conversation:", error);
    }
  };

  const handleSendMessage = async (questionText?: string) => {
    const userInput = questionText || input;
    if (!userInput.trim()) return;

    // Create conversation if not exists
    if (!currentConversationId) {
      try {
        const result = await createConversationMutation.mutateAsync({
          title: userInput.substring(0, 50) + (userInput.length > 50 ? "..." : ""),
        });
        setCurrentConversationId(result.conversationId);
      } catch (error) {
        console.error("Failed to create conversation:", error);
        return;
      }
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: userInput,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    setShowSuggestions(false);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userInput,
          context: "BTP prevention",
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Erreur ${response.status}`);
      }

      const data = await response.json();
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.response || "Je n'ai pas pu traiter votre demande. Veuillez réessayer.",
        timestamp: new Date(),
        imageUrl: data.imageUrl,
        imageSuggestion: data.imageSuggestion,
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Save to database
      try {
        if (currentConversationId) {
          await addMessageMutation.mutateAsync({
            conversationId: currentConversationId,
            role: "user",
            content: userInput,
          });
          await addMessageMutation.mutateAsync({
            conversationId: currentConversationId,
            role: "assistant",
            content: assistantMessage.content,
            imageUrl: assistantMessage.imageUrl,
            imageSuggestion: assistantMessage.imageSuggestion,
          });
        }

        await saveChatMutation.mutateAsync({
          message: userInput,
          response: assistantMessage.content,
          category: "BTP Prevention",
        });
      } catch (dbError) {
        console.warn("Failed to save chat history:", dbError);
      }

      // Refetch conversations to update message count
      await conversationsQuery.refetch();
    } catch (error) {
      console.error("Error:", error);
      const errorMessage: Message = {
        id: (Date.now() + 2).toString(),
        role: "assistant",
        content: `Désolé, une erreur s'est produite. ${error instanceof Error ? error.message : "Erreur inconnue"}. Veuillez réessayer.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    handleSendMessage(question);
  };

  const handleDeleteConversation = async (conversationId: number) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cette conversation ?")) {
      try {
        await deleteConversationMutation.mutateAsync({ conversationId });
        if (currentConversationId === conversationId) {
          setCurrentConversationId(null);
          setMessages([
            {
              id: "welcome",
              role: "assistant",
              content: "Bienvenue ! Je suis votre assistant IA spécialisé en prévention du BTP. Je peux vous aider à répondre à vos questions sur la sécurité, la santé au travail et les actualités du secteur. Comment puis-je vous aider ?",
              timestamp: new Date(),
            },
          ]);
          setShowSuggestions(true);
        }
        await conversationsQuery.refetch();
      } catch (error) {
        console.error("Failed to delete conversation:", error);
      }
    }
  };

  const handleArchiveConversation = async (conversationId: number) => {
    try {
      await archiveConversationMutation.mutateAsync({ conversationId });
      if (currentConversationId === conversationId) {
        setCurrentConversationId(null);
        setMessages([
          {
            id: "welcome",
            role: "assistant",
            content: "Bienvenue ! Je suis votre assistant IA spécialisé en prévention du BTP. Je peux vous aider à répondre à vos questions sur la sécurité, la santé au travail et les actualités du secteur. Comment puis-je vous aider ?",
            timestamp: new Date(),
          },
        ]);
        setShowSuggestions(true);
      }
      await conversationsQuery.refetch();
    } catch (error) {
      console.error("Failed to archive conversation:", error);
    }
  };

  const handleSelectConversation = (conversationId: number) => {
    setCurrentConversationId(conversationId);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col" style={{ fontFamily: "Arial, sans-serif" }}>
      <header className="bg-white shadow-md border-b-4 border-b-[#FF7A00]">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <img src="/logo.png" alt="PRÉVISION" className="h-32 w-auto hover:opacity-80 transition-opacity cursor-pointer" />
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-[#003D5C]">Chatbot Prévention BTP</h1>
              <p className="text-sm text-gray-600">Alimenté par Perplexity AI</p>
            </div>
          </div>
          {user && (
            <div className="text-right">
              <p className="text-sm text-gray-600">Connecté en tant que</p>
              <p className="font-medium text-[#003D5C]">{user.name || user.email}</p>
            </div>
          )}
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        {user && showSidebar && (
          <ConversationSidebar
            conversations={conversationsQuery.data || []}
            currentConversationId={currentConversationId}
            onSelectConversation={handleSelectConversation}
            onNewConversation={handleNewConversation}
            onDeleteConversation={handleDeleteConversation}
            onArchiveConversation={handleArchiveConversation}
            isLoading={isLoading}
          />
        )}

        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="container mx-auto px-6 py-8 flex-1 flex flex-col overflow-hidden">
            <div className="max-w-4xl mx-auto w-full flex flex-col flex-1">
              <Card className="flex-1 flex flex-col shadow-lg overflow-hidden">
                <CardContent className="flex-1 overflow-y-auto p-8 space-y-6 flex flex-col bg-gradient-to-b from-white to-[#F5F9FC]">
                  {showSuggestions && messages.length === 1 && (
                    <div className="flex-1 flex items-center justify-center">
                      <div className="w-full max-w-md">
                        <div className="text-center mb-8">
                          <Lightbulb className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                          <h3 className="text-xl font-bold text-[#003D5C] mb-3">Questions suggérées</h3>
                          <p className="text-base text-gray-600">Cliquez sur une question pour commencer</p>
                        </div>
                        <div className="space-y-4">
                          {SUGGESTED_QUESTIONS.map((question, index) => (
                            <Button
                              key={index}
                              onClick={() => handleSuggestedQuestion(question)}
                              variant="outline"
                              className="w-full text-left h-auto py-4 px-5 justify-start border-2 border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10 text-base font-medium"
                              disabled={isLoading}
                            >
                              <span>{question}</span>
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                  {!showSuggestions && (
                    <>
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-2xl px-6 py-4 rounded-lg ${
                              message.role === "user"
                                ? "bg-[#003D5C] text-white rounded-br-none shadow-md"
                                : "bg-white text-[#003D5C] rounded-bl-none border-2 border-[#FF7A00] shadow-md"
                            }`}
                          >
                            <MessageContent content={message.content} />
                            {message.imageUrl && (
                              <div className="mt-4 space-y-2">
                                <img
                                  src={message.imageUrl}
                                  alt={message.imageSuggestion || "Image illustration"}
                                  className="max-w-sm rounded-lg object-cover"
                                />
                                {message.imageSuggestion && (
                                  <p className="text-xs opacity-70 italic">
                                    Illustration : {message.imageSuggestion}
                                  </p>
                                )}
                              </div>
                            )}
                            <span className="text-xs opacity-70 mt-3 block">
                              {message.timestamp.toLocaleTimeString("fr-FR", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                        </div>
                      ))}
                      {isLoading && (
                        <div className="flex justify-start">
                          <div className="bg-[#F5F9FC] text-[#003D5C] px-6 py-4 rounded-lg rounded-bl-none border-2 border-[#FF7A00] shadow-md">
                            <Loader2 className="h-6 w-6 animate-spin text-[#FF7A00]" />
                          </div>
                        </div>
                      )}
                    </>
                  )}
                  <div ref={messagesEndRef} />
                </CardContent>

                <div className="border-t-2 border-[#FF7A00] p-6 bg-white">
                  <div className="flex gap-3">
                    <textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Posez votre question sur la prévention du BTP..."
                      className="flex-1 p-4 border-2 border-[#FF7A00] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FF7A00] resize-none text-base"
                      style={{ fontFamily: "Arial, sans-serif", fontSize: "16px" }}
                      rows={3}
                      disabled={isLoading}
                    />
                    <Button
                      onClick={() => handleSendMessage()}
                      disabled={isLoading || !input.trim()}
                      className="self-end gap-2 bg-[#FF7A00] hover:bg-[#E66A00] text-white font-bold px-6 py-3 text-base"
                    >
                      {isLoading ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <Send className="h-5 w-5" />
                      )}
                      Envoyer
                    </Button>
                  </div>
                </div>
              </Card>

              <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-l-4 border-l-[#FF7A00] shadow-md">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg text-[#003D5C] font-bold">Sujets courants</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-base text-gray-700">
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Prévention des chutes</p>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Équipements de protection</p>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Risques chimiques</p>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Formations obligatoires</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-[#FF7A00] shadow-md">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg text-[#003D5C] font-bold">Conseils</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-base text-gray-700">
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Soyez spécifique dans vos questions</p>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Mentionnez votre métier ou secteur</p>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Posez une question à la fois</p>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <p>Consultez les sources officielles</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-[#FF7A00] shadow-md">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg text-[#003D5C] font-bold">Ressources</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-base">
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <a href="https://www.oppbtp.com" target="_blank" rel="noopener noreferrer" className="text-[#FF7A00] hover:underline font-medium">OPPBTP</a>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <a href="https://www.preventionbtp.fr" target="_blank" rel="noopener noreferrer" className="text-[#FF7A00] hover:underline font-medium">PreventionBTP</a>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-[#FF7A00] font-bold">•</span>
                      <a href="https://www.inrs.fr" target="_blank" rel="noopener noreferrer" className="text-[#FF7A00] hover:underline font-medium">INRS</a>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

