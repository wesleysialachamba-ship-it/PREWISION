import FeedbackForm from "@/components/FeedbackForm";
import { MessageSquare } from "lucide-react";

export default function Feedback() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12">
      <div className="max-w-2xl mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <MessageSquare className="w-8 h-8 text-blue-600" />
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-4">Votre avis nous intéresse</h1>
            <p className="text-xl text-gray-600">
              Aidez-nous à améliorer PREWISION en partageant votre expérience
            </p>
          </div>

          {/* Feedback Form */}
          <FeedbackForm />

          {/* Info Box */}
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-semibold text-blue-900 mb-2">
              Pourquoi nous demandons votre feedback ?
            </h3>
            <ul className="text-blue-800 space-y-2 text-sm">
              <li>✓ Améliorer la qualité du chatbot</li>
              <li>✓ Sélectionner les articles les plus utiles</li>
              <li>✓ Ajouter de nouvelles fonctionnalités</li>
              <li>✓ Mieux servir la communauté BTP</li>
            </ul>
          </div>
      </div>
    </div>
  );
}

