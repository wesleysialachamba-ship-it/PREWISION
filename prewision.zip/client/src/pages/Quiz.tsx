import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, RotateCcw } from "lucide-react";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  image?: string;
}

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Quels équipements de protection individuelle (EPI) sont obligatoires sur tout chantier BTP ?",
    options: [
      "Casque de sécurité, gilet de visibilité, chaussures de sécurité, gants",
      "Uniquement un casque de sécurité",
      "Casque et gants suffisent",
      "Aucun équipement n'est obligatoire",
    ],
    correctAnswer: 0,
    explanation:
      "Sur tout chantier BTP, les EPI obligatoires incluent : casque de sécurité (protection contre les chocs), gilet de visibilité (visibilité des travailleurs), chaussures de sécurité (protection des pieds), et gants de protection. Ces équipements sont essentiels pour prévenir les accidents graves.",
    image: "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=500&h=300&fit=crop",
  },
  {
    id: 2,
    question: "À partir de quelle hauteur un harnais de sécurité est-il obligatoire ?",
    options: [
      "À partir de 1 mètre",
      "À partir de 2 mètres",
      "À partir de 3 mètres",
      "À partir de 5 mètres",
    ],
    correctAnswer: 1,
    explanation:
      "Selon les normes de sécurité BTP, un harnais de sécurité est obligatoire à partir de 2 mètres de hauteur. C'est une mesure essentielle pour prévenir les chutes, qui sont l'une des principales causes d'accidents mortels sur les chantiers.",
    image: "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=500&h=300&fit=crop",
  },
  {
    id: 3,
    question: "Quelle est la fréquence minimale des formations de sécurité obligatoires ?",
    options: [
      "Une fois par an",
      "Une fois tous les 2 ans",
      "Une fois tous les 5 ans",
      "Aucune formation n'est obligatoire",
    ],
    correctAnswer: 0,
    explanation:
      "Les formations de sécurité obligatoires doivent être renouvelées au minimum une fois par an. Cela garantit que les travailleurs restent à jour sur les procédures de sécurité et les risques spécifiques à leur environnement de travail.",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=300&fit=crop",
  },
  {
    id: 4,
    question: "Quel est le délai d'intervention d'une ambulance sur un chantier en cas d'urgence ?",
    options: [
      "5 minutes maximum",
      "15 minutes maximum",
      "30 minutes maximum",
      "Il n'y a pas de délai défini",
    ],
    correctAnswer: 1,
    explanation:
      "Le délai d'intervention d'une ambulance doit être de 15 minutes maximum depuis le chantier. C'est pourquoi il est crucial de localiser les chantiers à proximité de services d'urgence et de maintenir une communication directe avec les services de secours.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=500&h=300&fit=crop",
  },
  {
    id: 5,
    question: "Quelle norme régit la sécurité des échafaudages sur les chantiers ?",
    options: [
      "Norme EN 12810",
      "Norme EN 795",
      "Norme EN 353",
      "Norme EN 471",
    ],
    correctAnswer: 0,
    explanation:
      "La norme EN 12810 régit la sécurité des échafaudages de façade. Cette norme définit les exigences de conception, de fabrication et d'utilisation des échafaudages pour garantir la sécurité des travailleurs. Les normes EN 795 et EN 353 concernent les systèmes d'arrêt de chute.",
    image: "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=500&h=300&fit=crop",
  },
];

interface Answer {
  questionId: number;
  selectedAnswer: number;
}

export default function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [showResults, setShowResults] = useState(false);

  const question = QUIZ_QUESTIONS[currentQuestion];
  const currentAnswer = answers.find((a) => a.questionId === question.id);

  const handleSelectAnswer = (optionIndex: number) => {
    if (currentAnswer) {
      setAnswers(
        answers.map((a) =>
          a.questionId === question.id
            ? { ...a, selectedAnswer: optionIndex }
            : a
        )
      );
    } else {
      setAnswers([...answers, { questionId: question.id, selectedAnswer: optionIndex }]);
    }
  };

  const handleNext = () => {
    if (currentQuestion < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResults(false);
  };

  const correctCount = answers.filter((a) => {
    const q = QUIZ_QUESTIONS.find((q) => q.id === a.questionId);
    return q && a.selectedAnswer === q.correctAnswer;
  }).length;

  const percentage = Math.round((correctCount / QUIZ_QUESTIONS.length) * 100);

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#F5F9FC] to-white pt-8 pb-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <Link href="/">
            <a className="text-[#FF7A00] hover:underline mb-6 inline-block">
              ← Retour à l'accueil
            </a>
          </Link>

          <Card className="border-l-4 border-l-[#FF7A00] shadow-lg">
            <CardHeader className="bg-gradient-to-r from-[#003D5C] to-[#004B7A] text-white">
              <CardTitle className="text-2xl">Résultats du Quiz</CardTitle>
            </CardHeader>
            <CardContent className="pt-8">
              <div className="text-center mb-8">
                <div className="text-6xl font-bold text-[#FF7A00] mb-4">{percentage}%</div>
                <p className="text-xl text-[#003D5C] font-semibold">
                  {correctCount} sur {QUIZ_QUESTIONS.length} réponses correctes
                </p>
              </div>

              <div className="space-y-4 mb-8">
                {QUIZ_QUESTIONS.map((q, idx) => {
                  const answer = answers.find((a) => a.questionId === q.id);
                  const isCorrect = answer && answer.selectedAnswer === q.correctAnswer;

                  return (
                    <div
                      key={q.id}
                      className={`p-4 rounded-lg border-l-4 ${
                        isCorrect
                          ? "bg-green-50 border-l-green-500"
                          : "bg-red-50 border-l-red-500"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {isCorrect ? (
                          <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                        )}
                        <div className="flex-1">
                          <p className="font-semibold text-[#003D5C] mb-2">
                            Question {idx + 1}: {q.question}
                          </p>
                          <p className="text-sm text-gray-700 mb-2">
                            <span className="font-medium">Votre réponse :</span>{" "}
                            {answer ? q.options[answer.selectedAnswer] : "Non répondu"}
                          </p>
                          {!isCorrect && (
                            <p className="text-sm text-gray-700 mb-2">
                              <span className="font-medium">Bonne réponse :</span>{" "}
                              {q.options[q.correctAnswer]}
                            </p>
                          )}
                          <p className="text-sm text-gray-600 italic">{q.explanation}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleRestart}
                  className="flex-1 bg-[#FF7A00] hover:bg-[#E66A00] text-white font-bold"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Recommencer le quiz
                </Button>
                <Link href="/blog">
                  <Button
                    variant="outline"
                    className="flex-1 border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"
                  >
                    Lire les actualités
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F9FC] to-white pt-8 pb-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <Link href="/">
          <a className="text-[#FF7A00] hover:underline mb-6 inline-block">
            ← Retour à l'accueil
          </a>
        </Link>

        <Card className="border-l-4 border-l-[#FF7A00] shadow-lg">
          <CardHeader className="bg-gradient-to-r from-[#003D5C] to-[#004B7A] text-white">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">Quiz Sécurité BTP</CardTitle>
              <span className="text-sm bg-white/20 px-3 py-1 rounded-full">
                Question {currentQuestion + 1}/{QUIZ_QUESTIONS.length}
              </span>
            </div>
          </CardHeader>

          <CardContent className="pt-8">
            {/* Progress bar */}
            <div className="mb-8">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-[#FF7A00] h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${((currentQuestion + 1) / QUIZ_QUESTIONS.length) * 100}%`,
                  }}
                />
              </div>
            </div>

            {/* Question */}
            <h2 className="text-xl font-bold text-[#003D5C] mb-6">{question.question}</h2>

            {/* Image */}
            {question.image && (
              <img
                src={question.image}
                alt="Question illustration"
                className="w-full h-48 object-cover rounded-lg mb-6"
              />
            )}

            {/* Options */}
            <div className="space-y-3 mb-8">
              {question.options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectAnswer(idx)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-colors ${
                    currentAnswer?.selectedAnswer === idx
                      ? "border-[#FF7A00] bg-[#FF7A00]/10"
                      : "border-gray-200 hover:border-[#FF7A00]"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        currentAnswer?.selectedAnswer === idx
                          ? "border-[#FF7A00] bg-[#FF7A00]"
                          : "border-gray-300"
                      }`}
                    >
                      {currentAnswer?.selectedAnswer === idx && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <span className="text-[#003D5C] font-medium">{option}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex gap-4">
              <Button
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                variant="outline"
                className="flex-1 border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"
              >
                ← Précédent
              </Button>
              <Button
                onClick={handleNext}
                disabled={!currentAnswer}
                className="flex-1 bg-[#FF7A00] hover:bg-[#E66A00] text-white font-bold"
              >
                {currentQuestion === QUIZ_QUESTIONS.length - 1 ? "Voir les résultats" : "Suivant →"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

