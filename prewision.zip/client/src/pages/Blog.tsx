import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, ExternalLink, RefreshCw, Share2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Link } from "wouter";
import AdSenseAd from "@/components/AdSenseAd";

export default function Blog() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Get categories
  const { data: categories, isLoading: categoriesLoading } = trpc.blog.getCategories.useQuery();

  // Get articles
  const { data: articles, isLoading: articlesLoading, refetch } = trpc.blog.getRecent.useQuery({
    limit: 20,
  });

  // Get filtered articles by category
  const { data: filteredArticles, isLoading: filteredLoading } = trpc.blog.getByCategory.useQuery(
    { category: selectedCategory || "", limit: 20 },
    { enabled: !!selectedCategory }
  );

  // Trigger manual scraping (admin only)
  const triggerScrapingMutation = trpc.blog.triggerScraping.useMutation({
    onSuccess: () => {
      setIsRefreshing(false);
      refetch();
    },
    onError: () => {
      setIsRefreshing(false);
    },
  });

  const handleRefresh = async () => {
    if (user?.role !== "admin") return;
    setIsRefreshing(true);
    triggerScrapingMutation.mutate();
  };

  const displayArticles = selectedCategory ? filteredArticles : articles;
  const isLoading = selectedCategory ? filteredLoading : articlesLoading;

  const categoryColor: Record<string, string> = {
    "Sécurité": "bg-orange-100 text-orange-800",
    "Santé": "bg-blue-100 text-blue-800",
    "Prévention": "bg-[#003D5C] text-white",
    "Réglementation": "bg-purple-100 text-purple-800",
    "Formation": "bg-yellow-100 text-yellow-800",
    "Innovation": "bg-indigo-100 text-indigo-800",
    "Autre": "bg-gray-100 text-gray-800",
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header with Logo */}
      <header className="bg-white shadow-md border-b-4 border-b-[#FF7A00]">
        <div className="max-w-6xl mx-auto px-4 py-2 flex items-center">
          <Link href="/">
            <img src="/logo.png" alt="PRÉVISION" className="h-32 w-auto hover:opacity-80 transition-opacity cursor-pointer" />
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[#003D5C] to-[#004080] text-white py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">Actualités BTP : Sécurité et Santé</h1>
          <p className="text-blue-100 text-lg">
            Découvrez les dernières actualités et informations sur la sécurité et la santé au travail dans le BTP
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Admin Controls */}
        {user?.role === "admin" && (
          <div className="mb-8 p-4 bg-[#F5F9FC] border-l-4 border-l-[#FF7A00] rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-[#003D5C]">Contrôles Administrateur</h3>
                <p className="text-sm text-gray-600">Rafraîchir les actualités depuis les sources officielles</p>
              </div>
              <Button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="gap-2 bg-[#FF7A00] hover:bg-[#E66A00]"
              >
                {isRefreshing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Mise à jour en cours...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    Rafraîchir les actualités
                  </>
                )}
              </Button>
            </div>
          </div>
        )}

        {/* Category Filter */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-[#003D5C] mb-4">Filtrer par catégorie</h2>
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => setSelectedCategory(null)}
              variant={selectedCategory === null ? "default" : "outline"}
              className={selectedCategory === null ? "bg-[#FF7A00] hover:bg-[#E66A00]" : "border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"}
            >
              Tous les articles
            </Button>
            {categoriesLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              categories?.map((category) => (
                <Button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className={selectedCategory === category ? "bg-[#FF7A00] hover:bg-[#E66A00]" : "border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"}
                >
                  {category}
                </Button>
              ))
            )}
          </div>
        </div>

        {/* Articles */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#FF7A00]" />
          </div>
        ) : displayArticles && displayArticles.length > 0 ? (
          <div className="space-y-6">
            {displayArticles.map((article, index) => (
              <div key={article.id}>
                <Card className="hover:shadow-lg transition-shadow border-l-4 border-l-[#FF7A00]">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <CardTitle className="text-[#003D5C] mb-2">{article.title}</CardTitle>
                        <CardDescription className="text-gray-600">
                          {new Date(article.createdAt).toLocaleDateString("fr-FR", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </CardDescription>
                      </div>
                      <Badge className={categoryColor[article.category] || "bg-gray-100 text-gray-800"}>
                        {article.category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {/* Article Image */}
                    {article.imageUrl && (
                      <div className="mb-6 -mx-6 -mt-6">
                        <img
                          src={article.imageUrl}
                          alt={article.title}
                          className="w-full h-64 object-cover rounded-t-lg"
                        />
                        <p className="text-xs text-gray-500 px-6 py-2 bg-gray-50 rounded-b-lg">
                          Illustration: {article.sourceTitle}
                        </p>
                      </div>
                    )}
                    <p className="text-gray-700 mb-4 leading-relaxed">{article.summary}</p>
                    <div className="flex gap-2 flex-wrap">
                      <Button asChild variant="outline" className="border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10">
                        <a href={article.originalUrl || "#"} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Lire l'article
                        </a>
                      </Button>
                      <Button variant="ghost" size="sm" className="text-[#FF7A00] hover:bg-[#FF7A00]/10">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* AdSense Ad every 3 articles */}
                {(index + 1) % 3 === 0 && <AdSenseAd slotId="ca-pub-xxxxxxxxxxxxxxxx" />}
              </div>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-gray-500">Aucun article trouvé</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

