import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import {
  ArrowLeft,
  MessageSquare,
  Eye,
  Plus,
  AlertCircle,
  Loader2,
} from "lucide-react";

interface NewThreadForm {
  title: string;
  content: string;
  authorName: string;
  authorEmail: string;
  category: string;
}

export default function Forum() {
  const [showNewThreadForm, setShowNewThreadForm] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [formData, setFormData] = useState<NewThreadForm>({
    title: "",
    content: "",
    authorName: "",
    authorEmail: "",
    category: "Général",
  });

  const threadsQuery = trpc.forum.getThreads.useQuery({
    limit: 20,
    offset: 0,
  });
  const createThreadMutation = trpc.forum.createThread.useMutation();

  const categories = [
    "Général",
    "Sécurité",
    "EPI",
    "Travaux en Hauteur",
    "Formations",
    "Normes et Régulations",
  ];

  const handleSubmitThread = async () => {
    if (
      !formData.title ||
      !formData.content ||
      !formData.authorName ||
      !formData.authorEmail
    ) {
      alert("Veuillez remplir tous les champs");
      return;
    }

    try {
      await createThreadMutation.mutateAsync({
        title: formData.title,
        content: formData.content,
        authorName: formData.authorName,
        authorEmail: formData.authorEmail,
        category: formData.category,
      });

      // Reset form
      setFormData({
        title: "",
        content: "",
        authorName: "",
        authorEmail: "",
        category: "Général",
      });
      setShowNewThreadForm(false);

      // Refresh threads
      threadsQuery.refetch();

      alert("Votre discussion a été soumise pour modération");
    } catch (error) {
      console.error("Error creating thread:", error);
      alert("Une erreur s'est produite");
    }
  };

  const filteredThreads = selectedCategory
    ? threadsQuery.data?.filter((t) => t.category === selectedCategory)
    : threadsQuery.data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Retour
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Forum BTP</h1>
              <p className="text-sm text-slate-600">
                Discussions et questions sur la sécurité et la prévention
              </p>
            </div>
          </div>
          <Button onClick={() => setShowNewThreadForm(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Nouvelle Discussion
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* New Thread Form */}
          {showNewThreadForm && (
            <Card className="mb-8 border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle>Créer une nouvelle discussion</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Titre
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                    placeholder="Titre de votre discussion"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Catégorie
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Votre nom
                  </label>
                  <input
                    type="text"
                    value={formData.authorName}
                    onChange={(e) =>
                      setFormData({ ...formData, authorName: e.target.value })
                    }
                    placeholder="Votre nom"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Votre email
                  </label>
                  <input
                    type="email"
                    value={formData.authorEmail}
                    onChange={(e) =>
                      setFormData({ ...formData, authorEmail: e.target.value })
                    }
                    placeholder="votre@email.com"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Contenu
                  </label>
                  <textarea
                    value={formData.content}
                    onChange={(e) =>
                      setFormData({ ...formData, content: e.target.value })
                    }
                    placeholder="Décrivez votre question ou discussion..."
                    rows={5}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleSubmitThread}
                    disabled={createThreadMutation.isPending}
                  >
                    {createThreadMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Envoi...
                      </>
                    ) : (
                      "Publier"
                    )}
                  </Button>
                  <Button
                    onClick={() => setShowNewThreadForm(false)}
                    variant="outline"
                  >
                    Annuler
                  </Button>
                </div>

                <p className="text-xs text-slate-600 bg-yellow-50 p-3 rounded border border-yellow-200">
                  ⚠️ Votre discussion sera modérée avant publication. Veuillez respecter les règles de la communauté.
                </p>
              </CardContent>
            </Card>
          )}

          {/* Category Filter */}
          <div className="mb-6">
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                onClick={() => setSelectedCategory(null)}
                size="sm"
              >
                Toutes les catégories
              </Button>
              {categories.map((cat) => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "outline"}
                  onClick={() => setSelectedCategory(cat)}
                  size="sm"
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          {/* Threads List */}
          {threadsQuery.isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          ) : threadsQuery.error ? (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="pt-6 flex items-center gap-3">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <p className="text-red-800">
                  Erreur lors du chargement des discussions
                </p>
              </CardContent>
            </Card>
          ) : filteredThreads && filteredThreads.length > 0 ? (
            <div className="space-y-4">
              {filteredThreads.map((thread) => (
                <Link key={thread.id} href={`/forum/${thread.id}`}>
                  <Card className="hover:shadow-lg transition cursor-pointer">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            {thread.isPinned && (
                              <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">
                                Épinglé
                              </span>
                            )}
                            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                              {thread.category}
                            </span>
                          </div>
                          <h3 className="text-lg font-semibold text-slate-900 mb-2">
                            {thread.title}
                          </h3>
                          <p className="text-sm text-slate-600 line-clamp-2">
                            {thread.content}
                          </p>
                          <p className="text-xs text-slate-500 mt-2">
                            Par {thread.authorName} • {new Date(thread.createdAt).toLocaleDateString("fr-FR")}
                          </p>
                        </div>
                        <div className="flex gap-4 text-slate-600">
                          <div className="flex items-center gap-1">
                            <MessageSquare className="h-4 w-4" />
                            <span className="text-sm">{thread.replyCount}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="h-4 w-4" />
                            <span className="text-sm">{thread.viewCount}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6 text-center text-slate-600">
                Aucune discussion dans cette catégorie
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

