import { useState, useEffect } from "react";
import { Users, Clock, LogOut, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

interface User {
  id: number;
  email: string;
  name: string | null;
  isEmailVerified: boolean;
  isActive: boolean;
  createdAt: Date;
  lastLoginAt: Date | null;
}

export default function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  const getAllUsersQuery = trpc.auth.getAllUsers.useQuery({ limit: 100, offset: 0 });

  useEffect(() => {
    if (getAllUsersQuery.data) {
      setUsers(getAllUsersQuery.data.users);
      setIsLoading(false);
    }
  }, [getAllUsersQuery.data]);

  const handleRefresh = () => {
    setIsLoading(true);
    getAllUsersQuery.refetch();
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "Never";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F9FC] to-[#E8F1F7] pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-[#003D5C] mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-600">
            Manage users and monitor system activity
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Total Users */}
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-l-[#FF7A00]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Users</p>
                <p className="text-3xl font-bold text-[#003D5C]">
                  {users.length}
                </p>
              </div>
              <Users className="h-12 w-12 text-[#FF7A00] opacity-20" />
            </div>
          </div>

          {/* Verified Users */}
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-l-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Verified Users</p>
                <p className="text-3xl font-bold text-green-600">
                  {users.filter((u) => u.isEmailVerified).length}
                </p>
              </div>
              <Clock className="h-12 w-12 text-green-500 opacity-20" />
            </div>
          </div>

          {/* Active Users */}
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-l-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Active Users</p>
                <p className="text-3xl font-bold text-blue-600">
                  {users.filter((u) => u.isActive).length}
                </p>
              </div>
              <LogOut className="h-12 w-12 text-blue-500 opacity-20" />
            </div>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* Table Header */}
          <div className="bg-[#003D5C] text-white p-6 flex items-center justify-between">
            <h2 className="text-xl font-bold">Registered Users</h2>
            <Button
              onClick={handleRefresh}
              disabled={isLoading}
              className="bg-[#FF7A00] hover:bg-[#E66A00] text-white flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border-b border-red-200 p-4 text-red-700">
              {error}
            </div>
          )}

          {/* Loading State */}
          {isLoading && (
            <div className="p-8 text-center">
              <p className="text-gray-600">Loading users...</p>
            </div>
          )}

          {/* Empty State */}
          {!isLoading && users.length === 0 && (
            <div className="p-8 text-center">
              <p className="text-gray-600">No users registered yet</p>
            </div>
          )}

          {/* Users Table */}
          {!isLoading && users.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Registered
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Last Login
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr
                      key={user.id}
                      className="border-b border-gray-200 hover:bg-gray-50 transition-colors"
                    >
                      <td className="px-6 py-4 text-sm text-gray-900">
                        {user.email}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {user.name || "-"}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-block h-2 w-2 rounded-full ${
                              user.isActive ? "bg-green-500" : "bg-red-500"
                            }`}
                          ></span>
                          <span className="text-gray-600">
                            {user.isActive ? "Active" : "Inactive"}
                          </span>
                          {user.isEmailVerified && (
                            <span className="ml-2 inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                              Verified
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {formatDate(user.createdAt)}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {formatDate(user.lastLoginAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer Info */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="font-semibold text-blue-900 mb-2">System Information</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Free access duration: 30 minutes per IP address</li>
            <li>• Users must register to access after trial period</li>
            <li>• Passwords are securely hashed with bcrypt</li>
            <li>• Admin dashboard is protected and requires authentication</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

