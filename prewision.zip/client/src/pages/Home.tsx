import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2, AlertCircle, Search, Newspaper, MessageSquare, BookOpen, Download, Users } from "lucide-react";
import { useState } from "react";
import { useAuth as useAuthHook } from "@/_core/hooks/useAuth";
import SEOMeta from "@/components/SEOMeta";

export default function Home() {
  const { user, isAuthenticated } = useAuthHook();
  
  // SEO Meta tags
  const seoSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "PRÉVISION - Prévention et Sécurité BTP",
    "description": "Plateforme d'information sur la sécurité et la santé au travail dans le secteur du BTP. Chatbot IA, actualités, guides pratiques et ressources.",
    "url": "https://prewision.fr",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://prewision.fr/blog?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Fetch news and organizations
  const { data: recentNews, isLoading: newsLoading } = trpc.news.getRecent.useQuery();
  const { data: organizations, isLoading: orgsLoading } = trpc.organizations.getAll.useQuery();
  const { data: categoryNews } = trpc.news.getByCategory.useQuery(
    { category: selectedCategory || "Prevention", limit: 10 },
    { enabled: !!selectedCategory }
  );

  const newsToDisplay = selectedCategory ? categoryNews : recentNews;

  return (
    <>
      <SEOMeta
        title="PRÉVISION - Sécurité et Prévention BTP"
        description="Plateforme d'information sur la sécurité et la santé au travail dans le secteur du BTP. Chatbot IA, actualités, guides pratiques et ressources."
        keywords="sécurité BTP, prévention chantier, EPI, normes DTU, santé travail, formations BTP"
        ogImage="/logo.png"
        canonical="https://prewision.fr"
        schema={seoSchema}
      />
    <div className="min-h-screen bg-white">
      {/* Header */}      <header className="sticky top-0 z-50 bg-white shadow-md border-b-4 border-b-[#FF7A00]">
        <div className="container mx-auto px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="PRÉVISION" className="h-40 w-auto" />          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <span className="text-sm font-medium text-[#003D5C] hover:text-[#FF7A00] cursor-pointer">Accueil</span>
            </Link>
            <Link href="/blog">
              <span className="text-sm font-medium text-[#003D5C] hover:text-[#FF7A00] cursor-pointer">Blog</span>
            </Link>
            <Link href="/chat">
              <span className="text-sm font-medium text-[#003D5C] hover:text-[#FF7A00] cursor-pointer">Chatbot</span>
            </Link>
            <Link href="/resources">
              <span className="text-sm font-medium text-[#003D5C] hover:text-[#FF7A00] cursor-pointer">Ressources</span>
            </Link>
            <Link href="/forum">
              <span className="text-sm font-medium text-[#003D5C] hover:text-[#FF7A00] cursor-pointer">Forum</span>
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-[#003D5C]">Bienvenue, {user?.name}</span>
              </div>
            ) : (
              <Button asChild size="sm" className="bg-[#FF7A00] hover:bg-[#E66A00]">
                <a href={getLoginUrl()}>Se connecter</a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#003D5C] to-[#004080] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl font-bold mb-4">
            Restez informé sur la prévention du BTP
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Découvrez les dernières actualités des organismes de prévention du bâtiment et des travaux publics en France
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/blog">
              <Button size="lg" className="bg-[#FF7A00] hover:bg-[#E66A00]">
                Parcourir les actualités
              </Button>
            </Link>
            <Link href="/chat">
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                Poser une question
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#F5F9FC]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-[#003D5C] text-center mb-12">
            Nos Services
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="border-l-4 border-l-[#FF7A00] hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <MessageSquare className="w-6 h-6 text-[#FF7A00]" />
                  <CardTitle className="text-[#003D5C]">Chatbot IA</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Posez vos questions sur la sécurité BTP et obtenez des réponses instantanées
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-[#FF7A00] hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Newspaper className="w-6 h-6 text-[#FF7A00]" />
                  <CardTitle className="text-[#003D5C]">Actualités</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Suivez les dernières actualités des organismes de prévention
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-[#FF7A00] hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Download className="w-6 h-6 text-[#FF7A00]" />
                  <CardTitle className="text-[#003D5C]">Ressources</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Téléchargez des guides et checklists de sécurité
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-[#FF7A00] hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Users className="w-6 h-6 text-[#FF7A00]" />
                  <CardTitle className="text-[#003D5C]">Forum</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Échangez avec la communauté BTP
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Organizations Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-[#003D5C] mb-12">
            Organismes de Prévention
          </h2>
          {orgsLoading ? (
            <div className="flex justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-[#FF7A00]" />
            </div>
          ) : organizations && organizations.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {organizations.map((org) => (
                <Card key={org.id} className="hover:shadow-lg transition-shadow border-t-4 border-t-[#FF7A00]">
                  <CardHeader>
                    <CardTitle className="text-[#003D5C]">{org.name}</CardTitle>
                    <CardDescription>{org.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild variant="outline" className="w-full border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10">
                      <a href={org.website || "#"} target="_blank" rel="noopener noreferrer">
                        Visiter
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <AlertCircle className="w-8 h-8 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucun organisme trouvé</p>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {/* Latest News Section */}
      <section className="py-16 bg-[#F5F9FC]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-[#003D5C] mb-12">
            Dernières Actualités
          </h2>

          {newsLoading ? (
            <div className="flex justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-[#FF7A00]" />
            </div>
          ) : newsToDisplay && newsToDisplay.length > 0 ? (
            <div className="grid gap-6">
              {newsToDisplay.slice(0, 3).map((news) => (
                <Card key={news.id} className="hover:shadow-lg transition-shadow border-l-4 border-l-[#FF7A00]">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <CardTitle className="text-[#003D5C]">{news.title}</CardTitle>
                        <CardDescription>Source: {news.organizationId}</CardDescription>
                      </div>
                      <Badge className="bg-[#FF7A00] text-white">{news.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4">{news.description}</p>
                    <Button asChild variant="outline" className="border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10">
                      <a href={news.sourceUrl || "#"} target="_blank" rel="noopener noreferrer">
                        Lire l'article
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <AlertCircle className="w-8 h-8 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune actualité disponible</p>
              </CardContent>
            </Card>
          )}

          <div className="text-center mt-8">
            <Link href="/blog">
              <Button size="lg" className="bg-[#FF7A00] hover:bg-[#E66A00]">
                Voir toutes les actualités
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-[#003D5C] to-[#004080] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Besoin d'aide ?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Utilisez notre chatbot alimenté par Perplexity.ai pour obtenir des réponses instantanées
          </p>
          <Link href="/chat">
            <Button size="lg" className="bg-[#FF7A00] hover:bg-[#E66A00]">
              Accéder au Chatbot
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#003D5C] text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-4">PRÉVISION</h3>
              <p className="text-blue-100 text-sm">
                La vision prévention du BTP au Génie civil
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Ressources</h4>
              <ul className="text-blue-100 text-sm space-y-2">
                <li><Link href="/blog"><span className="hover:text-[#FF7A00]">Actualités</span></Link></li>
                <li><Link href="/resources"><span className="hover:text-[#FF7A00]">Ressources</span></Link></li>
                <li><Link href="/chat"><span className="hover:text-[#FF7A00]">Chatbot</span></Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Légal</h4>
              <ul className="text-blue-100 text-sm space-y-2">
                <li><span className="hover:text-[#FF7A00] cursor-pointer">Mentions légales</span></li>
                <li><span className="hover:text-[#FF7A00] cursor-pointer">Confidentialité</span></li>
                <li><span className="hover:text-[#FF7A00] cursor-pointer">Conditions</span></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <p className="text-blue-100 text-sm">contact@prewision.fr</p>
            </div>
          </div>
          <div className="border-t border-blue-700 pt-8 text-center text-blue-100 text-sm">
            <p>© 2025 PRÉVISION. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
}

