import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Download } from "lucide-react";
import SEOMeta from "@/components/SEOMeta";

interface Guide {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  image: string;
  category: string;
  readTime: number;
  keywords: string[];
}

const GUIDES: Guide[] = [
  {
    id: 1,
    title: "Choisir ses EPI : Guide complet pour la sécurité du chantier",
    slug: "choisir-epi",
    excerpt:
      "Découvrez comment sélectionner les équipements de protection individuelle adaptés à votre chantier BTP.",
    content: `
# Choisir ses EPI : Guide complet pour la sécurité du chantier

## Introduction
Les équipements de protection individuelle (EPI) sont essentiels pour garantir la sécurité des travailleurs sur les chantiers BTP. Choisir les bons EPI peut faire la différence entre un accident grave et une journée de travail sûre.

## Types d'EPI obligatoires

### Casque de sécurité
Le casque de sécurité protège contre les chocs à la tête. Il doit être conforme à la norme EN 397 et remplacé tous les 3-5 ans. Vérifiez régulièrement l'état de la coque et de la jugulaire.

### Gilet de visibilité
Le gilet de visibilité rend le travailleur visible, surtout en conditions de faible luminosité. La norme EN 20471 définit les exigences. Portez-le constamment sur le chantier.

### Chaussures de sécurité
Les chaussures de sécurité (norme EN ISO 20345) protègent les pieds contre les chocs et les perforations. Elles doivent être confortables et adaptées au type de chantier.

### Gants de protection
Les gants protègent contre les coupures, les abrasions et les produits chimiques. Le type de gant dépend du risque : gants de cuir pour les travaux généraux, gants nitrile pour les produits chimiques.

## Sélection selon le type de chantier

### Travaux en hauteur
Pour les travaux en hauteur (à partir de 2 mètres), ajoutez un harnais de sécurité (norme EN 361) et une longe (norme EN 354). Ces équipements sont obligatoires.

### Travaux électriques
Pour les travaux électriques, utilisez des gants isolants (norme EN 60903) et des chaussures isolantes. Vérifiez la classe de tension appropriée.

### Travaux avec produits chimiques
Portez des gants chimiques, des lunettes de protection et un masque respiratoire si nécessaire. Consultez la fiche de données de sécurité du produit.

## Maintenance et remplacement

- Inspectez vos EPI avant chaque utilisation
- Nettoyez régulièrement vos équipements
- Remplacez les EPI endommagés immédiatement
- Respectez les dates d'expiration
- Stockez les EPI dans un endroit sec et protégé

## Conclusion
Choisir les bons EPI et les maintenir correctement est un investissement dans la sécurité de votre équipe. N'hésitez pas à consulter les organismes de prévention comme l'OPPBTP ou l'INRS pour des conseils spécifiques.
    `,
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=400&fit=crop&auto=format&q=80",
    category: "Sécurité",
    readTime: 8,
    keywords: ["EPI", "équipement protection", "sécurité chantier", "norme EN"],
  },
  {
    id: 2,
    title: "Sécuriser un échafaudage : Normes et bonnes pratiques",
    slug: "securiser-echafaudage",
    excerpt:
      "Apprenez les normes essentielles pour installer et sécuriser correctement un échafaudage sur votre chantier.",
    content: `
# Sécuriser un échafaudage : Normes et bonnes pratiques

## Introduction
L'échafaudage est un élément crucial des chantiers BTP. Une mauvaise installation peut entraîner des chutes graves. Ce guide vous aide à sécuriser correctement vos échafaudages.

## Normes applicables

### Norme EN 12810
La norme EN 12810 régit la sécurité des échafaudages de façade. Elle définit les exigences de conception, de fabrication et d'utilisation.

### Norme EN 12811
La norme EN 12811 concerne les méthodes d'essai des échafaudages et des systèmes de protection.

## Installation sécurisée

### Préparation du sol
- Vérifiez que le sol est stable et plan
- Utilisez des plaques de répartition pour les sols mous
- Assurez-vous que le drainage est correct

### Montage de l'échafaudage
- Suivez les plans de montage fournis par le fabricant
- Utilisez des ouvriers qualifiés et formés
- Vérifiez chaque élément avant l'assemblage
- Serrez tous les boulons et écrous correctement

### Stabilité et ancrage
- Ancrez l'échafaudage à la structure du bâtiment tous les 4 étages
- Utilisez des contreventements diagonaux
- Vérifiez la stabilité après chaque étape du montage

## Vérifications régulières

### Avant utilisation
- Inspectez visuellement tous les éléments
- Vérifiez l'absence de corrosion ou de dommages
- Testez la stabilité en appliquant une charge

### Pendant l'utilisation
- Vérifiez quotidiennement l'état de l'échafaudage
- Nettoyez les plateformes des débris
- Vérifiez que les garde-corps sont en place

### Après mauvais temps
- Inspectez après des tempêtes ou des vents forts
- Vérifiez les ancrages et les contreventements
- Remplacez les éléments endommagés

## Équipements de protection

- Harnais de sécurité obligatoire pour les travaux en hauteur
- Filets de sécurité sous l'échafaudage
- Garde-corps sur toutes les plateformes
- Accès sécurisé (escaliers ou échelles)

## Conclusion
La sécurité de l'échafaudage dépend d'une installation correcte et de vérifications régulières. Consultez les organismes de prévention pour des formations spécialisées.
    `,
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&h=400&fit=crop&auto=format&q=80",
    category: "Structures",
    readTime: 10,
    keywords: ["échafaudage", "normes EN", "sécurité hauteur", "installation"],
  },
  {
    id: 3,
    title: "Normes DTU simplifiées : Essentiel pour les chantiers BTP",
    slug: "normes-dtu",
    excerpt:
      "Comprendre les normes DTU essentielles pour assurer la qualité et la sécurité de vos chantiers.",
    content: `
# Normes DTU simplifiées : Essentiel pour les chantiers BTP

## Introduction
Les normes DTU (Documents Techniques Unifiés) sont des références incontournables en BTP. Elles définissent les règles de l'art pour la construction. Voici un guide simplifié des normes essentielles.

## Qu'est-ce qu'une norme DTU ?

Les DTU sont des documents qui décrivent les règles de mise en œuvre des matériaux et des techniques de construction. Ils couvrent :
- Les matériaux à utiliser
- Les méthodes de mise en œuvre
- Les vérifications et contrôles
- Les garanties et responsabilités

## DTU essentielles par domaine

### Maçonnerie
- DTU 20.1 : Travaux de maçonnerie de petits éléments
- DTU 20.12 : Briques creuses de terre cuite
- DTU 20.13 : Blocs béton creux

### Charpente
- DTU 31.1 : Charpente en bois
- DTU 32.1 : Charpente métallique
- DTU 32.2 : Assemblages par boulons

### Couverture
- DTU 40.11 : Tuiles plates
- DTU 40.12 : Tuiles canal
- DTU 40.2 : Ardoises

### Étanchéité
- DTU 43.1 : Étanchéité des toitures
- DTU 43.4 : Étanchéité des terrasses

## Mise en œuvre des DTU

### Avant le chantier
1. Consultez les DTU applicables
2. Vérifiez la disponibilité des matériaux
3. Formez votre équipe aux exigences
4. Préparez les outils et équipements

### Pendant le chantier
1. Respectez les conditions climatiques (température, humidité)
2. Vérifiez chaque étape de mise en œuvre
3. Documentez les travaux effectués
4. Signalez les non-conformités

### Après le chantier
1. Effectuez les tests et vérifications
2. Documentez l'achèvement des travaux
3. Conservez les preuves de conformité
4. Délivrez les garanties appropriées

## Responsabilités légales

Le respect des DTU est obligatoire en France. Les entreprises qui ne respectent pas les DTU peuvent être tenues responsables des défauts de construction et des dommages causés.

## Où trouver les DTU ?

- Site officiel de l'AFNOR (Association Française de Normalisation)
- Organisations professionnelles du BTP
- Éditeurs spécialisés
- Organismes de formation

## Conclusion
Les normes DTU sont essentielles pour garantir la qualité et la sécurité de vos chantiers. Investissez dans la formation de votre équipe et consultez les DTU avant chaque projet.
    `,
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&h=400&fit=crop&auto=format&q=80",
    category: "Normes",
    readTime: 10,
    keywords: ["DTU", "normes BTP", "réglementation", "construction"],
  },
];

export default function Guides() {
  const seoSchema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Guides pratiques BTP - Sécurité et Prévention",
    description: "Guides pratiques complets sur la sécurité et la prévention dans le secteur du BTP",
    url: "https://prewision.fr/guides",
  };

  return (
    <>
      <SEOMeta
        title="Guides pratiques BTP - Sécurité et Prévention | PRÉVISION"
        description="Découvrez nos guides pratiques complets sur la sécurité BTP : EPI, échafaudages, normes DTU et bien d'autres."
        keywords="guides BTP, sécurité chantier, EPI, échafaudage, normes DTU, prévention"
        ogImage="/logo.png"
        canonical="https://prewision.fr/guides"
        schema={seoSchema}
      />

      <div className="min-h-screen bg-gradient-to-b from-[#F5F9FC] to-white pt-8 pb-12">
        <div className="container mx-auto px-4 max-w-5xl">
          {/* Header */}
          <div className="mb-12">
            <Link href="/">
              <a className="text-[#FF7A00] hover:underline mb-6 inline-block">
                ← Retour à l'accueil
              </a>
            </Link>
            <h1 className="text-4xl font-bold text-[#003D5C] mb-4">Guides Pratiques BTP</h1>
            <p className="text-lg text-gray-700">
              Découvrez nos guides complets sur la sécurité et la prévention dans le secteur du BTP.
            </p>
          </div>

          {/* Guides Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {GUIDES.map((guide) => (
              <Card
                key={guide.id}
                className="border-l-4 border-l-[#FF7A00] shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
              >
                <img
                  src={guide.image}
                  alt={guide.title}
                  className="w-full h-48 object-cover"
                />
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xs font-bold text-[#FF7A00] bg-[#FF7A00]/10 px-2 py-1 rounded">
                      {guide.category}
                    </span>
                    <span className="text-xs text-gray-500">{guide.readTime} min</span>
                  </div>
                  <CardTitle className="text-lg text-[#003D5C]">{guide.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 text-sm mb-4">{guide.excerpt}</p>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {guide.keywords.slice(0, 2).map((keyword) => (
                      <span
                        key={keyword}
                        className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                      >
                        {keyword}
                      </span>
                    ))}
                  </div>
                  <Link href={`/guides/${guide.slug}`}>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"
                    >
                      Lire le guide
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* CTA Section */}
          <Card className="bg-gradient-to-r from-[#003D5C] to-[#004B7A] text-white border-0">
            <CardContent className="pt-12 pb-12 text-center">
              <h2 className="text-2xl font-bold mb-4">Besoin d'aide supplémentaire ?</h2>
              <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
                Consultez nos ressources téléchargeables ou posez une question à notre chatbot spécialisé en sécurité BTP.
              </p>
              <div className="flex gap-4 justify-center flex-wrap">
                <Link href="/chat">
                  <Button className="bg-[#FF7A00] hover:bg-[#E66A00] text-white">
                    Poser une question
                  </Button>
                </Link>
                <Link href="/resources">
                  <Button
                    variant="outline"
                    className="text-white border-white hover:bg-white/10"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Télécharger les ressources
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

