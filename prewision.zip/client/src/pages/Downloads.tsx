import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Share2, Mail, Copy, Check } from "lucide-react";
import SEOMeta from "@/components/SEOMeta";

interface PDF {
  id: number;
  title: string;
  description: string;
  category: string;
  pages: number;
  size: string;
  downloadUrl: string;
  qrCode: string;
}

const PDFS: PDF[] = [
  {
    id: 1,
    title: "Checklist EPI - Vérification Quotidienne",
    description:
      "Checklist complète pour vérifier l'état de vos équipements de protection individuelle avant chaque journée de travail.",
    category: "EPI",
    pages: 2,
    size: "1.2 MB",
    downloadUrl: "/pdfs/checklist-epi.pdf",
    qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://prewision.fr/downloads/checklist-epi",
  },
  {
    id: 2,
    title: "Guide de Sécurité en Hauteur",
    description:
      "Guide complet couvrant les normes, les équipements et les procédures de sécurité pour les travaux en hauteur.",
    category: "Sécurité",
    pages: 8,
    size: "3.5 MB",
    downloadUrl: "/pdfs/guide-hauteur.pdf",
    qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://prewision.fr/downloads/guide-hauteur",
  },
  {
    id: 3,
    title: "Plan de Prévention - Modèle",
    description:
      "Modèle de plan de prévention à adapter selon votre chantier et vos risques spécifiques.",
    category: "Prévention",
    pages: 5,
    size: "2.1 MB",
    downloadUrl: "/pdfs/plan-prevention.pdf",
    qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://prewision.fr/downloads/plan-prevention",
  },
];

export default function Downloads() {
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [emailForm, setEmailForm] = useState({
    email: "",
    pdfId: null as number | null,
  });
  const [showEmailForm, setShowEmailForm] = useState(false);

  const handleDownload = (pdfId: number) => {
    const pdf = PDFS.find((p) => p.id === pdfId);
    if (pdf) {
      // Trigger download
      const link = document.createElement("a");
      link.href = pdf.downloadUrl;
      link.download = pdf.title;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleCopyLink = (pdfId: number) => {
    const pdf = PDFS.find((p) => p.id === pdfId);
    if (pdf) {
      const shareUrl = `https://prewision.fr/downloads/${pdf.id}`;
      navigator.clipboard.writeText(shareUrl);
      setCopiedId(pdfId);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const handleEmailShare = async (pdfId: number) => {
    setEmailForm({ email: "", pdfId });
    setShowEmailForm(true);
  };

  const handleSendEmail = async () => {
    if (!emailForm.email || !emailForm.pdfId) return;

    // In production, this would call a backend API
    console.log("Sending PDF to:", emailForm.email);
    alert(
      `Lien de téléchargement envoyé à ${emailForm.email} (simulation)`
    );
    setShowEmailForm(false);
    setEmailForm({ email: "", pdfId: null });
  };

  return (
    <>
      <SEOMeta
        title="Téléchargements Gratuits - PRÉVISION"
        description="Téléchargez nos guides, checklists et modèles de sécurité BTP gratuitement."
        keywords="téléchargement PDF, guides BTP, checklists sécurité, modèles"
      />

      <div className="min-h-screen bg-gradient-to-br from-[#F5F9FC] to-[#E8F1F7] pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-[#003D5C] mb-4">
              📥 Téléchargements Gratuits
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl">
              Accédez à nos ressources gratuites : guides, checklists et modèles
              pour améliorer la sécurité de vos chantiers BTP.
            </p>
          </div>

          {/* PDFs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {PDFS.map((pdf) => (
              <Card key={pdf.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg text-[#003D5C]">
                    {pdf.title}
                  </CardTitle>
                  <div className="flex gap-2 mt-2">
                    <span className="inline-block bg-[#FF7A00] text-white text-xs px-3 py-1 rounded-full">
                      {pdf.category}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 text-sm">{pdf.description}</p>

                  {/* QR Code */}
                  <div className="flex justify-center p-4 bg-gray-50 rounded-lg">
                    <img
                      src={pdf.qrCode}
                      alt={`QR Code for ${pdf.title}`}
                      className="w-32 h-32"
                    />
                  </div>

                  {/* File Info */}
                  <div className="text-sm text-gray-500 space-y-1">
                    <p>📄 {pdf.pages} pages</p>
                    <p>💾 {pdf.size}</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-2">
                    <Button
                      onClick={() => handleDownload(pdf.id)}
                      className="w-full bg-[#FF7A00] hover:bg-[#E66A00] text-white"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleCopyLink(pdf.id)}
                        variant="outline"
                        className="flex-1"
                      >
                        {copiedId === pdf.id ? (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Copié !
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4 mr-2" />
                            Copier
                          </>
                        )}
                      </Button>

                      <Button
                        onClick={() => handleEmailShare(pdf.id)}
                        variant="outline"
                        className="flex-1"
                      >
                        <Mail className="w-4 h-4 mr-2" />
                        Email
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Email Share Form */}
          {showEmailForm && emailForm.pdfId && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
              <Card className="w-full max-w-md">
                <CardHeader>
                  <CardTitle>Partager par Email</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Votre email
                    </label>
                    <input
                      type="email"
                      value={emailForm.email}
                      onChange={(e) =>
                        setEmailForm({ ...emailForm, email: e.target.value })
                      }
                      placeholder="votre@email.com"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FF7A00]"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={handleSendEmail}
                      className="flex-1 bg-[#FF7A00] hover:bg-[#E66A00] text-white"
                    >
                      Envoyer
                    </Button>
                    <Button
                      onClick={() => setShowEmailForm(false)}
                      variant="outline"
                      className="flex-1"
                    >
                      Annuler
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Info Section */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-[#003D5C] flex items-center gap-2">
                <Share2 className="w-5 h-5" />
                Comment partager ?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">
                  1. Partage par QR Code
                </h3>
                <p className="text-gray-600 text-sm">
                  Scannez le code QR avec votre téléphone pour partager le lien
                  directement.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">
                  2. Partage par Lien
                </h3>
                <p className="text-gray-600 text-sm">
                  Cliquez sur "Copier" pour copier le lien et le partager par
                  email, chat, ou réseaux sociaux.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">
                  3. Partage par Email
                </h3>
                <p className="text-gray-600 text-sm">
                  Entrez votre email pour recevoir un lien de téléchargement
                  direct.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

