/**
 * Hook for Google Analytics tracking
 */

export function useAnalytics() {
  const trackEvent = (eventName: string, eventData?: Record<string, any>) => {
    if (typeof window !== "undefined" && (window as any).gtag) {
      (window as any).gtag("event", eventName, eventData);
    }
  };

  const trackPageView = (pagePath: string, pageTitle: string) => {
    if (typeof window !== "undefined" && (window as any).gtag) {
      (window as any).gtag("event", "page_view", {
        page_path: pagePath,
        page_title: pageTitle,
      });
    }
  };

  const trackChatbotUsage = (question: string, category: string) => {
    trackEvent("chatbot_question", {
      question_length: question.length,
      category,
      timestamp: new Date().toISOString(),
    });
  };

  const trackArticleView = (articleId: number, title: string) => {
    trackEvent("article_view", {
      article_id: articleId,
      title,
    });
  };

  const trackResourceDownload = (resourceId: number, resourceName: string) => {
    trackEvent("resource_download", {
      resource_id: resourceId,
      resource_name: resourceName,
    });
  };

  const trackForumThreadCreated = (threadId: number, category: string) => {
    trackEvent("forum_thread_created", {
      thread_id: threadId,
      category,
    });
  };

  const trackNewsletterSignup = (email: string) => {
    trackEvent("newsletter_signup", {
      email_domain: email.split("@")[1],
    });
  };

  return {
    trackEvent,
    trackPageView,
    trackChatbotUsage,
    trackArticleView,
    trackResourceDownload,
    trackForumThreadCreated,
    trackNewsletterSignup,
  };
}

