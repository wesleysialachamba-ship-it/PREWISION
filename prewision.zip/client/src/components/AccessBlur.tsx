import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Lock, LogIn } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function AccessBlur() {
  const [, setLocation] = useLocation();
  const [isExpired, setIsExpired] = useState(false);
  const [ipAddress, setIpAddress] = useState<string>("");
  const [showBlur, setShowBlur] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const checkTempSessionQuery = trpc.auth.checkTempSession.useQuery(
    { ipAddress },
    { enabled: !!ipAddress && !isAuthenticated, refetchInterval: 5000 }
  );

  // Get IP address on mount
  useEffect(() => {
    const getIpAddress = async () => {
      try {
        const response = await fetch("https://api.ipify.org?format=json");
        const data = await response.json();
        setIpAddress(data.ip);
      } catch (error) {
        console.error("Failed to get IP address:", error);
      }
    };

    getIpAddress();
  }, []);

  // Check if user is authenticated
  useEffect(() => {
    const isAuth = localStorage.getItem("isAuthenticated") === "true";
    setIsAuthenticated(isAuth);
  }, []);

  // Check if session is expired
  useEffect(() => {
    if (isAuthenticated) {
      setShowBlur(false);
      return;
    }

    if (checkTempSessionQuery.data) {
      const data = checkTempSessionQuery.data as any;
      const { isValid } = data;

      if (!isValid) {
        setIsExpired(true);
        setShowBlur(true);
      } else {
        setIsExpired(false);
        setShowBlur(false);
      }
    }
  }, [checkTempSessionQuery.data, isAuthenticated]);

  if (!showBlur) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm pointer-events-auto">
      {/* Blur overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/60 backdrop-blur-md pointer-events-none"></div>

      {/* Content */}
      <div className="relative z-10 max-w-md mx-auto px-4 pointer-events-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-8 text-center">
          {/* Icon */}
          <div className="mb-6 flex justify-center">
            <div className="bg-red-100 rounded-full p-4">
              <Lock className="h-8 w-8 text-red-600" />
            </div>
          </div>

          {/* Title */}
          <h2 className="text-2xl font-bold text-[#003D5C] mb-3">
            Accès Expiré
          </h2>

          {/* Message */}
          <p className="text-gray-600 mb-6">
            Votre accès gratuit de 30 minutes a expiré. Veuillez vous connecter ou créer un compte pour continuer à accéder au site PRÉVISION.
          </p>

          {/* Buttons */}
          <div className="space-y-3 pointer-events-auto">
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setLocation("/login");
              }}
              className="w-full bg-[#FF7A00] hover:bg-[#E66A00] active:bg-[#D65A00] text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:shadow-xl"
            >
              <LogIn className="h-5 w-5" />
              Se Connecter
            </button>

            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setLocation("/register");
              }}
              className="w-full bg-[#003D5C] hover:bg-[#002847] active:bg-[#001a33] text-white font-bold py-3 rounded-lg transition-colors cursor-pointer shadow-lg hover:shadow-xl"
            >
              Créer un Compte
            </button>
          </div>

          {/* Info */}
          <p className="text-xs text-gray-500 mt-6">
            L'inscription vous permet d'accéder à tous les contenus de PREWISION sans limite de temps.
          </p>
        </div>
      </div>
    </div>
  );
}

