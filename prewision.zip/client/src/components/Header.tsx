import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { label: "Accueil", href: "/" },
    { label: "Chatbot", href: "/chat" },
    { label: "Actualités", href: "/blog" },
    { label: "Quiz", href: "/quiz" },
    { label: "Guides", href: "/guides" },
    { label: "Téléchargements", href: "/downloads" },
    { label: "Ressources", href: "/resources" },
    { label: "Forum", href: "/forum" },
  ];

  const isActive = (href: string) => {
    if (href === "/" && location === "/") return true;
    if (href !== "/" && location.startsWith(href)) return true;
    return false;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white shadow-md border-b-4 border-b-[#FF7A00]">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <div className="flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer">
            <img
              src="/logo.png"
              alt="PRÉVISION"
              className="h-12 w-auto"
            />
            <span className="hidden sm:inline text-lg font-bold text-[#003D5C]">PRÉVISION</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <button
                className={`px-4 py-2 rounded-md font-medium transition-colors ${
                  isActive(item.href)
                    ? "bg-[#FF7A00] text-white"
                    : "text-[#003D5C] hover:bg-[#F5F9FC]"
                }`}
              >
                {item.label}
              </button>
            </Link>
          ))}
        </nav>

        {/* Auth Section */}
        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <>
              <span className="text-sm text-gray-600">
                {user.name || user.email}
              </span>
              <Button
                onClick={() => logout()}
                variant="outline"
                size="sm"
                className="border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"
              >
                Déconnexion
              </Button>
            </>
          ) : (
            <a href={getLoginUrl()}>
              <Button
                size="sm"
                className="bg-[#FF7A00] hover:bg-[#E66A00] text-white"
              >
                Connexion
              </Button>
            </a>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden p-2 hover:bg-gray-100 rounded-lg"
          aria-label="Toggle menu"
        >
          {isMenuOpen ? (
            <X className="h-6 w-6 text-[#003D5C]" />
          ) : (
            <Menu className="h-6 w-6 text-[#003D5C]" />
          )}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 py-4 px-4 space-y-2">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <button
                onClick={() => setIsMenuOpen(false)}
                className={`w-full text-left px-4 py-2 rounded-md font-medium transition-colors ${
                  isActive(item.href)
                    ? "bg-[#FF7A00] text-white"
                    : "text-[#003D5C] hover:bg-[#F5F9FC]"
                }`}
              >
                {item.label}
              </button>
            </Link>
          ))}
          <div className="border-t border-gray-200 pt-4 mt-4">
            {user ? (
              <>
                <p className="text-sm text-gray-600 px-4 py-2">
                  {user.name || user.email}
                </p>
                <Button
                  onClick={() => {
                    logout();
                    setIsMenuOpen(false);
                  }}
                  variant="outline"
                  size="sm"
                  className="w-full border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00]/10"
                >
                  Déconnexion
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button
                  size="sm"
                  className="w-full bg-[#FF7A00] hover:bg-[#E66A00] text-white"
                >
                  Connexion
                </Button>
              </a>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

