/**
 * SEO Head Component
 * Manages meta tags and structured data for each page
 */

interface SEOHeadProps {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  ogType?: string;
  ogImage?: string;
  structuredData?: Record<string, any>;
}

export function SEOHead({
  title,
  description,
  keywords,
  canonical,
  ogType = "website",
  ogImage,
  structuredData,
}: SEOHeadProps) {
  // Update document title
  if (typeof document !== "undefined") {
    document.title = title;

    // Update or create meta tags
    updateMetaTag("description", description);
    if (keywords) {
      updateMetaTag("keywords", keywords);
    }
    if (canonical) {
      updateCanonicalTag(canonical);
    }

    // Update OG tags
    updateMetaTag("og:type", ogType, "property");
    updateMetaTag("og:title", title, "property");
    updateMetaTag("og:description", description, "property");
    if (ogImage) {
      updateMetaTag("og:image", ogImage, "property");
    }

    // Add structured data if provided
    if (structuredData) {
      addStructuredData(structuredData);
    }
  }

  return null;
}

function updateMetaTag(
  name: string,
  content: string,
  attribute: "name" | "property" = "name"
) {
  let element = document.querySelector(`meta[${attribute}="${name}"]`);

  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attribute, name);
    document.head.appendChild(element);
  }

  element.setAttribute("content", content);
}

function updateCanonicalTag(href: string) {
  let link = document.querySelector("link[rel='canonical']");

  if (!link) {
    link = document.createElement("link");
    link.setAttribute("rel", "canonical");
    document.head.appendChild(link);
  }

  link.setAttribute("href", href);
}

function addStructuredData(data: Record<string, any>) {
  // Remove existing structured data script
  const existingScript = document.querySelector('script[type="application/ld+json"]');
  if (existingScript) {
    existingScript.remove();
  }

  // Add new structured data
  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.textContent = JSON.stringify(data);
  document.head.appendChild(script);
}

