import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
    import { Label } from "@/components/ui/label";
    import { Textarea } from "@/components/ui/textarea";
import { Star, Send, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function FeedbackForm() {
  const [email, setEmail] = useState("");
  const [chatbotRating, setChatbotRating] = useState(0);
  const [chatbotFeedback, setChatbotFeedback] = useState("");
  const [articlesRating, setArticlesRating] = useState(0);
  const [articlesFeedback, setArticlesFeedback] = useState("");
  const [additionalComments, setAdditionalComments] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const submitFeedback = trpc.feedback.submit.useMutation({
    onSuccess: () => {
      setIsSubmitted(true);
      toast.success("Merci pour votre feedback !");
      setTimeout(() => {
        setEmail("");
        setChatbotRating(0);
        setChatbotFeedback("");
        setArticlesRating(0);
        setArticlesFeedback("");
        setAdditionalComments("");
        setIsSubmitted(false);
      }, 3000);
    },
    onError: (error: any) => {
      toast.error("Erreur lors de l'envoi du feedback");
      console.error(error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      toast.error("Veuillez entrer votre email");
      return;
    }

    submitFeedback.mutate({
      email,
      chatbotRating: chatbotRating || undefined,
      chatbotFeedback: chatbotFeedback || undefined,
      articlesRating: articlesRating || undefined,
      articlesFeedback: articlesFeedback || undefined,
      additionalComments: additionalComments || undefined,
    });
  };

  if (isSubmitted) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardContent className="py-12 text-center">
          <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-green-800 mb-2">
            Merci pour votre feedback !
          </h3>
          <p className="text-green-700">
            Vos commentaires nous aident à améliorer PREWISION
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Votre avis nous intéresse</CardTitle>
        <CardDescription>
          Aidez-nous à améliorer PREWISION en partageant votre feedback
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Email */}
          <div className="space-y-2">
            <Label htmlFor="email">Votre email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="votre@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          {/* Chatbot Rating */}
          <div className="space-y-3">
            <Label>Que pensez-vous du chatbot ?</Label>
            <div className="space-y-2">
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setChatbotRating(star)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= chatbotRating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  </button>
                ))}
              </div>
              {chatbotRating > 0 && (
                <p className="text-sm text-gray-600">
                  {chatbotRating === 1 && "Très insatisfait"}{" "}
                  {chatbotRating === 2 && "Insatisfait"}{" "}
                  {chatbotRating === 3 && "Neutre"}{" "}
                  {chatbotRating === 4 && "Satisfait"}{" "}
                  {chatbotRating === 5 && "Très satisfait"}
                </p>
              )}
            </div>
            <Textarea
              placeholder="Partagez vos commentaires sur le chatbot (optionnel)"
              value={chatbotFeedback}
              onChange={(e) => setChatbotFeedback(e.target.value)}
              className="resize-none"
              rows={3}
            />
          </div>

          {/* Articles Rating */}
          <div className="space-y-3">
            <Label>Les articles sont-ils utiles ?</Label>
            <div className="space-y-2">
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setArticlesRating(star)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= articlesRating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  </button>
                ))}
              </div>
              {articlesRating > 0 && (
                <p className="text-sm text-gray-600">
                  {articlesRating === 1 && "Pas utiles du tout"}{" "}
                  {articlesRating === 2 && "Peu utiles"}{" "}
                  {articlesRating === 3 && "Moyennement utiles"}{" "}
                  {articlesRating === 4 && "Utiles"}{" "}
                  {articlesRating === 5 && "Très utiles"}
                </p>
              )}
            </div>
            <Textarea
              placeholder="Dites-nous ce que vous pensez des articles (optionnel)"
              value={articlesFeedback}
              onChange={(e) => setArticlesFeedback(e.target.value)}
              className="resize-none"
              rows={3}
            />
          </div>

          {/* Additional Comments */}
          <div className="space-y-2">
            <Label htmlFor="comments">Commentaires supplémentaires</Label>
            <Textarea
              id="comments"
              placeholder="Avez-vous des suggestions pour améliorer PREWISION ? (optionnel)"
              value={additionalComments}
              onChange={(e) => setAdditionalComments(e.target.value)}
              className="resize-none"
              rows={3}
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={submitFeedback.isPending || !email}
            className="w-full"
          >
            {submitFeedback.isPending ? (
              "Envoi en cours..."
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Envoyer mon feedback
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

