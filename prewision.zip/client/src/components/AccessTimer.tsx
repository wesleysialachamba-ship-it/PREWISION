import { useEffect, useState } from "react";
import { Clock, AlertCircle } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function AccessTimer() {
  const [, setLocation] = useLocation();
  const [timeRemaining, setTimeRemaining] = useState<string>("");
  const [isExpired, setIsExpired] = useState(false);
  const [ipAddress, setIpAddress] = useState<string>("");

  const checkTempSessionQuery = trpc.auth.checkTempSession.useQuery(
    { ipAddress },
    { enabled: !!ipAddress, refetchInterval: 5000 }
  );

  // Get IP address on mount
  useEffect(() => {
    const getIpAddress = async () => {
      try {
        const response = await fetch("https://api.ipify.org?format=json");
        const data = await response.json();
        setIpAddress(data.ip);
      } catch (error) {
        console.error("Failed to get IP address:", error);
      }
    };

    getIpAddress();
  }, []);

  // Update timer display
  useEffect(() => {
    if (checkTempSessionQuery.data) {
      const data = checkTempSessionQuery.data as any;
      const { isValid, formattedTime } = data;

      if (!isValid) {
        setIsExpired(true);
        setTimeRemaining("Expired");
        // Redirect to login after a short delay
        setTimeout(() => {
          setLocation("/login");
        }, 2000);
      } else {
        setIsExpired(false);
        setTimeRemaining(formattedTime || "");
      }
    }
  }, [checkTempSessionQuery.data, setLocation]);

  if (!timeRemaining) {
    return null;
  }

  return (
    <div
      className={`fixed top-16 left-0 right-0 z-40 transition-all duration-300 ${
        isExpired
          ? "bg-red-50 border-b border-red-200"
          : "bg-amber-50 border-b border-amber-200"
      }`}
    >
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {isExpired ? (
            <AlertCircle className="h-5 w-5 text-red-600" />
          ) : (
            <Clock className="h-5 w-5 text-amber-600" />
          )}
          <div>
            <p
              className={`text-sm font-semibold ${
                isExpired ? "text-red-900" : "text-amber-900"
              }`}
            >
              {isExpired
                ? "Your free access has expired"
                : "Free Access Timer"}
            </p>
            <p
              className={`text-xs ${
                isExpired ? "text-red-700" : "text-amber-700"
              }`}
            >
              {isExpired
                ? "Please sign in to continue"
                : `Time remaining: ${timeRemaining}`}
            </p>
          </div>
        </div>

        {isExpired && (
          <button
            onClick={() => setLocation("/login")}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded transition-colors"
          >
            Sign In
          </button>
        )}
      </div>
    </div>
  );
}

