import { useState, useEffect } from "react";
import { Lock, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PasswordProtectionProps {
  onUnlock: () => void;
  correctPassword: string;
}

export default function PasswordProtection({
  onUnlock,
  correctPassword,
}: PasswordProtectionProps) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLocked, setIsLocked] = useState(true);

  // Check if already unlocked in session
  useEffect(() => {
    const sessionUnlocked = sessionStorage.getItem("siteUnlocked");
    if (sessionUnlocked === "true") {
      setIsLocked(false);
      onUnlock();
    }
  }, [onUnlock]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password === correctPassword) {
      setError("");
      setIsLocked(false);
      sessionStorage.setItem("siteUnlocked", "true");
      onUnlock();
    } else {
      setError("Mot de passe incorrect. Veuillez réessayer.");
      setPassword("");
    }
  };

  if (!isLocked) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-md w-full p-8">
        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className="bg-[#FF7A00]/10 p-4 rounded-full">
            <Lock className="h-8 w-8 text-[#FF7A00]" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-2xl font-bold text-[#003D5C] text-center mb-2">
          Accès au site
        </h1>
        <p className="text-gray-600 text-center mb-6">
          Entrez le mot de passe pour découvrir le site BTP.
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Password Input */}
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              placeholder="Mot de passe"
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-[#FF7A00] transition-colors"
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
            >
              {showPassword ? (
                <EyeOff className="h-5 w-5" />
              ) : (
                <Eye className="h-5 w-5" />
              )}
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full bg-[#FF7A00] hover:bg-[#E66A00] text-white font-bold py-3 rounded-lg transition-colors"
          >
            Accéder au site
          </Button>
        </form>

        {/* Footer */}
        <p className="text-xs text-gray-500 text-center mt-6">
          Site protégé par mot de passe pour accès privé
        </p>
      </div>
    </div>
  );
}

