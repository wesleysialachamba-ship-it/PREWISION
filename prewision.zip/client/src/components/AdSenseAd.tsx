import { useEffect } from "react";

interface AdSenseAdProps {
  /**
   * AdSense slot ID
   */
  slotId: string;
  /**
   * Ad format: "auto", "horizontal", "vertical", "rectangle"
   */
  format?: "auto" | "horizontal" | "vertical" | "rectangle";
  /**
   * Full width responsive
   */
  fullWidth?: boolean;
  /**
   * Custom className
   */
  className?: string;
}

/**
 * Google AdSense Ad Component
 * Displays non-intrusive ads in designated areas
 */
export default function AdSenseAd({
  slotId,
  format = "auto",
  fullWidth = true,
  className = "",
}: AdSenseAdProps) {
  useEffect(() => {
    // Push ad to AdSense queue if script is loaded
    if (typeof window !== "undefined" && (window as any).adsbygoogle) {
      try {
        ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
      } catch (error) {
        console.error("AdSense error:", error);
      }
    }
  }, [slotId]);

  // Don't render if AdSense ID is not configured
  const adsenseId = import.meta.env.VITE_ADSENSE_ID;
  if (!adsenseId) {
    return null;
  }

  return (
    <div className={`my-6 flex justify-center ${className}`}>
      <ins
        className="adsbygoogle"
        style={{
          display: fullWidth ? "block" : "inline-block",
          textAlign: "center",
          width: fullWidth ? "100%" : "auto",
          height: format === "rectangle" ? "250px" : "auto",
        }}
        data-ad-client={adsenseId}
        data-ad-slot={slotId}
        data-ad-format={format}
        data-full-width-responsive={fullWidth ? "true" : "false"}
      />
    </div>
  );
}

