import { useState, useEffect } from "react";
import { X, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NotificationBannerProps {
  title: string;
  message: string;
  articleUrl?: string;
  onDismiss?: () => void;
  autoHideDuration?: number;
}

export default function NotificationBanner({
  title,
  message,
  articleUrl,
  onDismiss,
  autoHideDuration = 0,
}: NotificationBannerProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (autoHideDuration > 0) {
      const timer = setTimeout(() => {
        setIsVisible(false);
        onDismiss?.();
      }, autoHideDuration);
      return () => clearTimeout(timer);
    }
  }, [autoHideDuration, onDismiss]);

  if (!isVisible) return null;

  return (
    <div className="fixed top-20 left-0 right-0 z-40 mx-4 md:mx-auto md:max-w-2xl md:left-1/2 md:-translate-x-1/2">
      <div className="bg-gradient-to-r from-[#FF7A00] to-[#E66A00] text-white rounded-lg shadow-lg p-4 flex items-start gap-4">
        <Bell className="h-5 w-5 flex-shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-sm md:text-base">{title}</h3>
          <p className="text-xs md:text-sm opacity-90 mt-1">{message}</p>
          {articleUrl && (
            <a
              href={articleUrl}
              className="inline-block mt-2 text-xs md:text-sm underline hover:opacity-80 transition-opacity"
            >
              Lire l'article →
            </a>
          )}
        </div>
        <button
          onClick={() => {
            setIsVisible(false);
            onDismiss?.();
          }}
          className="flex-shrink-0 p-1 hover:bg-white/20 rounded transition-colors"
          aria-label="Fermer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

