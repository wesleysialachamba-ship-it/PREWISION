import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import Chat from "@/pages/Chat";
import Blog from "@/pages/Blog";
import Resources from "@/pages/Resources";
import Forum from "@/pages/Forum";
import Feedback from "@/pages/Feedback";
import Quiz from "@/pages/Quiz";
import Guides from "@/pages/Guides";
import Downloads from "@/pages/Downloads";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import RegisterAdvanced from "@/pages/RegisterAdvanced";
import AdminDashboard from "@/pages/AdminDashboard";
import Header from "@/components/Header";
import NotificationBanner from "@/components/NotificationBanner";
import PasswordProtection from "@/components/PasswordProtection";
import AccessTimer from "@/components/AccessTimer";
import AccessBlur from "@/components/AccessBlur";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { trpc } from "@/lib/trpc";

interface Notification {
  id: string;
  title: string;
  message: string;
  articleUrl?: string;
}

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/chat"} component={Chat} />
      <Route path={"/blog"} component={Blog} />
      <Route path={"/guides"} component={Guides} />
      <Route path={"/downloads"} component={Downloads} />
      <Route path={"/login"} component={Login} />
      <Route path={"/register"} component={Register} />
      <Route path={"/register-advanced"} component={RegisterAdvanced} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/resources"} component={Resources} />
      <Route path={"/forum"} component={Forum} />
      <Route path={"/feedback"} component={Feedback} />
      <Route path={"/quiz"} component={Quiz} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const recentBlogQuery = trpc.blog.getRecent.useQuery({ limit: 1 });
  
  const PASSWORD = "BTP2025";

  // Check for new articles on mount and periodically
  useEffect(() => {
    const checkNewArticles = () => {
      const lastCheckTime = localStorage.getItem("lastNotificationCheck");
      const now = new Date().getTime();

      // Check every 5 minutes
      if (!lastCheckTime || now - parseInt(lastCheckTime) > 5 * 60 * 1000) {
        if (recentBlogQuery.data && recentBlogQuery.data.length > 0) {
          const latestArticle = recentBlogQuery.data[0];
          const lastNotifiedArticle = localStorage.getItem("lastNotifiedArticle");

          if (lastNotifiedArticle !== latestArticle.id.toString()) {
            const notification: Notification = {
              id: `notif-${latestArticle.id}`,
              title: "📰 Nouvelle actualité BTP",
              message: latestArticle.title,
              articleUrl: `/blog?article=${latestArticle.id}`,
            };

            setNotifications((prev) => [notification, ...prev]);
            localStorage.setItem("lastNotifiedArticle", latestArticle.id.toString());
          }
        }

        localStorage.setItem("lastCheckTime", now.toString());
      }
    };

    checkNewArticles();
    const interval = setInterval(checkNewArticles, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [recentBlogQuery.data]);

  const handleDismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          {!isUnlocked && (
            <PasswordProtection
              correctPassword={PASSWORD}
              onUnlock={() => setIsUnlocked(true)}
            />
          )}
          <Header />
          <AccessTimer />
          <AccessBlur />
          
          {/* Notifications */}
          <div className="space-y-2">
            {notifications.map((notification) => (
              <NotificationBanner
                key={notification.id}
                title={notification.title}
                message={notification.message}
                articleUrl={notification.articleUrl}
                onDismiss={() => handleDismissNotification(notification.id)}
                autoHideDuration={8000}
              />
            ))}
          </div>

          {/* Main content with padding for fixed header */}
          <main className="pt-20">
            <Router />
          </main>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

