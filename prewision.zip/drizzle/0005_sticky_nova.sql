CREATE TABLE `forumReplies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`threadId` int NOT NULL,
	`content` text NOT NULL,
	`authorEmail` varchar(320) NOT NULL,
	`authorName` varchar(255) NOT NULL,
	`status` enum('published','pending','rejected') NOT NULL DEFAULT 'pending',
	`isAnswer` boolean NOT NULL DEFAULT false,
	`likes` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `forumReplies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `forumThreads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`content` text NOT NULL,
	`authorEmail` varchar(320) NOT NULL,
	`authorName` varchar(255) NOT NULL,
	`category` varchar(255) NOT NULL,
	`status` enum('published','pending','rejected') NOT NULL DEFAULT 'pending',
	`replyCount` int NOT NULL DEFAULT 0,
	`viewCount` int NOT NULL DEFAULT 0,
	`isPinned` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `forumThreads_id` PRIMARY KEY(`id`)
);
