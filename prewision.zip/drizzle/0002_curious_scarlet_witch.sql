CREATE TABLE `blogArticles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`summary` text NOT NULL,
	`originalUrl` varchar(500) NOT NULL,
	`sourceWebsite` varchar(255) NOT NULL,
	`sourceTitle` varchar(255) NOT NULL,
	`category` enum('Sécurité','Santé','Prévention','Réglementation','Formation','Innovation','Autre') NOT NULL DEFAULT 'Autre',
	`imageUrl` varchar(500),
	`originalPublishedAt` timestamp,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `blogArticles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scrapingJobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceUrl` varchar(500) NOT NULL,
	`sourceName` varchar(255) NOT NULL,
	`lastScrapedAt` timestamp,
	`nextScrapedAt` timestamp,
	`articlesFound` int NOT NULL DEFAULT 0,
	`articlesAdded` int NOT NULL DEFAULT 0,
	`status` enum('pending','running','completed','failed') NOT NULL DEFAULT 'pending',
	`errorMessage` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `scrapingJobs_id` PRIMARY KEY(`id`)
);
