CREATE TABLE `rssSourceSuggestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`rssUrl` varchar(500),
	`websiteUrl` varchar(500) NOT NULL,
	`category` varchar(255) NOT NULL,
	`relevanceScore` int NOT NULL DEFAULT 0,
	`status` enum('pending','approved','rejected','active') NOT NULL DEFAULT 'pending',
	`discoveredAt` timestamp NOT NULL DEFAULT (now()),
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rssSourceSuggestions_id` PRIMARY KEY(`id`)
);
