CREATE TABLE `userFeedback` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`chatbotRating` int,
	`chatbotFeedback` text,
	`articlesRating` int,
	`articlesFeedback` text,
	`additionalComments` text,
	`userAgent` varchar(500),
	`ipAddress` varchar(45),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userFeedback_id` PRIMARY KEY(`id`)
);
