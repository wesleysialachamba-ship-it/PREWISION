# 🔗 Lien de Test Public - PRÉVISION

## ✅ Tests Réussis

Le site PRÉVISION a été testé avec succès. Tous les systèmes fonctionnent correctement :

- ✅ Page d'accueil affichée
- ✅ Modal "Accès Expiré" fonctionnelle
- ✅ Boutons de redirection opérationnels
- ✅ Accès temporaire 30 minutes actif
- ✅ Floutage du contenu après expiration
- ✅ Design responsive et professionnel
- ✅ Navigation fluide

---

## 🌐 Lien de Partage Public

**Partagez ce lien avec vos testeurs :**

```
https://3000-i3q3a3osadgzu5ap4ioos-865955eb.manus.computer
```

**Copie courte :**
```
https://3000-i3q3a3osadgzu5ap4ioos-865955eb.manus.computer
```

---

## 📋 Instructions pour les Testeurs

### **1. Accès Initial (30 minutes gratuites)**
- Visitez le lien public
- Vous avez automatiquement **30 minutes d'accès gratuit**
- Explorez le site : Accueil, Blog, Chatbot, Ressources, Forum, Quiz, Guides

### **2. Test de Création de Compte**
- Cliquez sur le bouton **"Créer un Compte"**
- Choisissez votre profil :
  - **Personnel** : Nom complet
  - **Professionnel** : Nom entreprise + SIRET optionnel
- Remplissez le formulaire avec des données valides
- Exemple email : `test@exemple.com`
- Exemple mot de passe : `Test1234!`

### **3. Test de Connexion**
- Cliquez sur **"Se Connecter"**
- Entrez vos identifiants
- Vous devriez avoir accès illimité au site

### **4. Test du Floutage (après 30 minutes)**
- Attendez 30 minutes (ou testez avec les outils de développement)
- Le contenu doit être flouté
- Vous devez vous connecter pour continuer

### **5. Test du Quiz de Sécurité**
- Accédez au menu **"Quiz"**
- Répondez aux 5 questions de sécurité BTP
- Vérifiez les explications et les images

### **6. Test des Guides Pratiques**
- Accédez au menu **"Guides"**
- Consultez les 3 guides :
  - Choisir ses EPI
  - Sécuriser un échafaudage
  - Normes DTU simplifiées

### **7. Test du Chatbot**
- Accédez au menu **"Chatbot"**
- Posez une question sur la sécurité BTP
- Exemple : "Quels EPI pour un chantier ?"
- Vérifiez que les réponses sont concises et pertinentes

---

## 🔐 Mot de Passe Privé (Optionnel)

Si vous voyez une page de protection par mot de passe :
- **Mot de passe** : `BTP2025`

---

## 📝 Formulaire de Feedback

Après le test, veuillez nous envoyer vos commentaires :

**Questions à couvrir :**
1. ✅ Le site s'affiche-t-il correctement ?
2. ✅ Les formulaires fonctionnent-ils ?
3. ✅ Les messages d'erreur sont-ils clairs ?
4. ✅ La navigation est-elle intuitive ?
5. ✅ Les images s'affichent-elles ?
6. ✅ Le design est-il professionnel ?
7. ✅ Avez-vous rencontré des bugs ?
8. ✅ Suggestions d'améliorations ?

---

## 🐛 Signaler un Bug

Si vous trouvez un problème :
1. Décrivez le problème en détail
2. Notez l'URL où le bug s'est produit
3. Mentionnez votre navigateur et appareil
4. Prenez une capture d'écran si possible

---

## ⏱️ Durée du Lien

Ce lien de test est **disponible pendant 7 jours**.  
Après cette période, contactez-nous pour une nouvelle session de test.

---

## 📞 Support Technique

Pour toute question technique :
- Consultez la page **Ressources**
- Utilisez le **Chatbot** pour les questions BTP
- Envoyez un message via **Feedback**

---

## 🎉 Merci !

Merci de tester PRÉVISION et de nous aider à améliorer le site !

**Bonne navigation !**

---

*PRÉVISION - Actualités Prévention BTP*  
*Sécurité et Santé au Travail*

