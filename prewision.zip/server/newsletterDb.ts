/**
 * Database helpers for newsletter management
 */

import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  newsletterSubscribers,
  newsletterSends,
  InsertNewsletterSubscriber,
  InsertNewsletterSend,
  NewsletterSubscriber,
  NewsletterSend,
} from "../drizzle/schema";
import { randomBytes } from "crypto";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Subscribe a user to the newsletter
 */
export async function subscribeToNewsletter(
  email: string,
  name?: string
): Promise<NewsletterSubscriber | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot subscribe: database not available");
    return null;
  }

  try {
    const unsubscribeToken = randomBytes(32).toString("hex");

    const result = await db.insert(newsletterSubscribers).values({
      email,
      name,
      unsubscribeToken,
      isActive: true,
    });

    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(newsletterSubscribers)
      .where(eq(newsletterSubscribers.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to subscribe:", error);
    throw error;
  }
}

/**
 * Unsubscribe from newsletter
 */
export async function unsubscribeFromNewsletter(
  unsubscribeToken: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot unsubscribe: database not available");
    return false;
  }

  try {
    await db
      .update(newsletterSubscribers)
      .set({ isActive: false })
      .where(eq(newsletterSubscribers.unsubscribeToken, unsubscribeToken));

    return true;
  } catch (error) {
    console.error("[Database] Failed to unsubscribe:", error);
    return false;
  }
}

/**
 * Get active newsletter subscribers
 */
export async function getActiveSubscribers(): Promise<NewsletterSubscriber[]> {
  const db = await getDb();
  if (!db) {
    console.warn(
      "[Database] Cannot get subscribers: database not available"
    );
    return [];
  }

  try {
    const subscribers = await db
      .select()
      .from(newsletterSubscribers)
      .where(eq(newsletterSubscribers.isActive, true));

    return subscribers;
  } catch (error) {
    console.error("[Database] Failed to get subscribers:", error);
    return [];
  }
}

/**
 * Check if email is already subscribed
 */
export async function isEmailSubscribed(email: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check email: database not available");
    return false;
  }

  try {
    const existing = await db
      .select()
      .from(newsletterSubscribers)
      .where(
        and(
          eq(newsletterSubscribers.email, email),
          eq(newsletterSubscribers.isActive, true)
        )
      )
      .limit(1);

    return existing.length > 0;
  } catch (error) {
    console.error("[Database] Failed to check email:", error);
    return false;
  }
}

/**
 * Record newsletter send
 */
export async function recordNewsletterSend(
  data: InsertNewsletterSend
): Promise<NewsletterSend | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot record send: database not available");
    return null;
  }

  try {
    const result = await db.insert(newsletterSends).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(newsletterSends)
      .where(eq(newsletterSends.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to record send:", error);
    throw error;
  }
}

/**
 * Get newsletter statistics
 */
export async function getNewsletterStats(): Promise<{
  totalSubscribers: number;
  activeSubscribers: number;
  totalSends: number;
  lastSendDate?: Date;
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get stats: database not available");
    return {
      totalSubscribers: 0,
      activeSubscribers: 0,
      totalSends: 0,
    };
  }

  try {
    const subscribers = await db
      .select()
      .from(newsletterSubscribers);

    const activeSubscribers = await db
      .select()
      .from(newsletterSubscribers)
      .where(eq(newsletterSubscribers.isActive, true));

    const sends = await db
      .select()
      .from(newsletterSends)
      .orderBy(desc(newsletterSends.sentAt))
      .limit(1);

    return {
      totalSubscribers: subscribers.length,
      activeSubscribers: activeSubscribers.length,
      totalSends: subscribers.length, // Approximate
      lastSendDate: sends.length > 0 ? sends[0].sentAt : undefined,
    };
  } catch (error) {
    console.error("[Database] Failed to get stats:", error);
    return {
      totalSubscribers: 0,
      activeSubscribers: 0,
      totalSends: 0,
    };
  }
}

