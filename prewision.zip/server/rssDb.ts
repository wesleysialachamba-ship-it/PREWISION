/**
 * Database helpers for RSS source suggestions
 */

import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  rssSourceSuggestions,
  InsertRssSourceSuggestion,
  RssSourceSuggestion,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Add a new RSS source suggestion
 */
export async function addRssSourceSuggestion(
  data: InsertRssSourceSuggestion
): Promise<RssSourceSuggestion | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add suggestion: database not available");
    return null;
  }

  try {
    const result = await db.insert(rssSourceSuggestions).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(rssSourceSuggestions)
      .where(eq(rssSourceSuggestions.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to add suggestion:", error);
    throw error;
  }
}

/**
 * Get pending RSS source suggestions (for admin review)
 */
export async function getPendingRssSuggestions(): Promise<RssSourceSuggestion[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get suggestions: database not available");
    return [];
  }

  try {
    const suggestions = await db
      .select()
      .from(rssSourceSuggestions)
      .where(eq(rssSourceSuggestions.status, "pending"))
      .orderBy(desc(rssSourceSuggestions.relevanceScore), rssSourceSuggestions.discoveredAt);

    return suggestions;
  } catch (error) {
    console.error("[Database] Failed to get pending suggestions:", error);
    return [];
  }
}

/**
 * Get all active RSS sources
 */
export async function getActiveRssSources(): Promise<RssSourceSuggestion[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sources: database not available");
    return [];
  }

  try {
    const sources = await db
      .select()
      .from(rssSourceSuggestions)
      .where(eq(rssSourceSuggestions.status, "active"))
      .orderBy(desc(rssSourceSuggestions.relevanceScore));

    return sources;
  } catch (error) {
    console.error("[Database] Failed to get active sources:", error);
    return [];
  }
}

/**
 * Approve RSS source suggestion
 */
export async function approveRssSource(sourceId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot approve source: database not available");
    return false;
  }

  try {
    await db
      .update(rssSourceSuggestions)
      .set({
        status: "active",
        approvedAt: new Date(),
      })
      .where(eq(rssSourceSuggestions.id, sourceId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to approve source:", error);
    return false;
  }
}

/**
 * Reject RSS source suggestion
 */
export async function rejectRssSource(sourceId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot reject source: database not available");
    return false;
  }

  try {
    await db
      .update(rssSourceSuggestions)
      .set({ status: "rejected" })
      .where(eq(rssSourceSuggestions.id, sourceId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to reject source:", error);
    return false;
  }
}

/**
 * Check if source already exists
 */
export async function sourceExists(websiteUrl: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check source: database not available");
    return false;
  }

  try {
    const existing = await db
      .select()
      .from(rssSourceSuggestions)
      .where(eq(rssSourceSuggestions.websiteUrl, websiteUrl))
      .limit(1);

    return existing.length > 0;
  } catch (error) {
    console.error("[Database] Failed to check source:", error);
    return false;
  }
}

/**
 * Get RSS sources by category
 */
export async function getRssSourcesByCategory(
  category: string
): Promise<RssSourceSuggestion[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sources: database not available");
    return [];
  }

  try {
    const sources = await db
      .select()
      .from(rssSourceSuggestions)
      .where(
        and(
          eq(rssSourceSuggestions.category, category),
          eq(rssSourceSuggestions.status, "active")
        )
      )
      .orderBy(desc(rssSourceSuggestions.relevanceScore));

    return sources;
  } catch (error) {
    console.error("[Database] Failed to get sources by category:", error);
    return [];
  }
}

