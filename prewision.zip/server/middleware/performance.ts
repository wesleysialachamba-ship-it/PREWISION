/**
 * Performance Optimization Middleware
 * Implements compression, caching headers, and performance best practices
 */

import { Express, Request, Response, NextFunction } from "express";
import compression from "compression";

/**
 * Configure performance middleware
 */
export function configurePerformance(app: Express): void {
  // Enable gzip compression
  app.use(
    compression({
      level: 6, // Balance between compression ratio and speed
      threshold: 1024, // Only compress responses larger than 1KB
      filter: (req, res) => {
        if (req.headers["x-no-compression"]) {
          return false;
        }
        return compression.filter(req, res);
      },
    })
  );

  // Set cache headers for static assets
  app.use((req: Request, res: Response, next: NextFunction) => {
    // Cache CSS, JS, images for 1 year
    if (
      req.path.match(/\.(js|css|png|jpg|jpeg|gif|svg|woff|woff2|ttf|eot)$/)
    ) {
      res.set("Cache-Control", "public, max-age=31536000, immutable");
    }
    // Cache HTML for 1 hour
    else if (req.path.match(/\.html$/)) {
      res.set("Cache-Control", "public, max-age=3600");
    }
    // Don't cache API responses (they have their own caching strategy)
    else if (req.path.startsWith("/api") || req.path.startsWith("/trpc")) {
      res.set("Cache-Control", "no-cache, no-store, must-revalidate");
      res.set("Pragma", "no-cache");
      res.set("Expires", "0");
    }
    // Default: cache for 1 hour
    else {
      res.set("Cache-Control", "public, max-age=3600");
    }

    next();
  });

  // Security headers
  app.use((req: Request, res: Response, next: NextFunction) => {
    // Prevent MIME type sniffing
    res.set("X-Content-Type-Options", "nosniff");

    // Enable XSS protection
    res.set("X-XSS-Protection", "1; mode=block");

    // Clickjacking protection
    res.set("X-Frame-Options", "SAMEORIGIN");

    // Referrer policy
    res.set("Referrer-Policy", "strict-origin-when-cross-origin");

    // Feature policy
    res.set(
      "Permissions-Policy",
      "geolocation=(), microphone=(), camera=()"
    );

    next();
  });

  // Performance monitoring
  app.use((req: Request, res: Response, next: NextFunction) => {
    const startTime = Date.now();

    res.on("finish", () => {
      const duration = Date.now() - startTime;

      // Log slow requests (> 1 second)
      if (duration > 1000) {
        console.warn(
          `[Performance] Slow request: ${req.method} ${req.path} (${duration}ms)`
        );
      }

      // Add performance header
      res.set("X-Response-Time", `${duration}ms`);
    });

    next();
  });
}

/**
 * Image optimization configuration
 */
export const imageOptimizationConfig = {
  // Unsplash image optimization
  unsplash: {
    // Add quality parameter to Unsplash URLs
    quality: 80, // 0-100
    // Add width parameter for responsive images
    widths: [320, 640, 1024, 1280],
    // Format preference
    format: "auto", // Let Unsplash choose the best format
  },

  // Local image optimization
  local: {
    // Maximum image size
    maxSize: 5 * 1024 * 1024, // 5MB
    // Allowed formats
    formats: ["image/jpeg", "image/png", "image/webp", "image/svg+xml"],
    // Compression quality
    quality: 80,
  },
};

/**
 * Generate optimized Unsplash image URL
 */
export function getOptimizedUnsplashUrl(
  baseUrl: string,
  width?: number,
  height?: number
): string {
  const url = new URL(baseUrl);

  // Add quality parameter
  url.searchParams.set("q", imageOptimizationConfig.unsplash.quality.toString());

  // Add width parameter
  if (width) {
    url.searchParams.set("w", width.toString());
  }

  // Add height parameter
  if (height) {
    url.searchParams.set("h", height.toString());
  }

  // Add format parameter
  url.searchParams.set("fm", "auto");

  // Add fit parameter
  url.searchParams.set("fit", "crop");

  return url.toString();
}

/**
 * Performance metrics interface
 */
export interface PerformanceMetrics {
  pageLoadTime: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  cumulativeLayoutShift: number;
  timeToInteractive: number;
}

/**
 * Calculate PageSpeed score (simplified)
 */
export function calculatePageSpeedScore(metrics: PerformanceMetrics): number {
  let score = 100;

  // FCP: First Contentful Paint (target: < 1.8s)
  if (metrics.firstContentfulPaint > 1800) {
    score -= Math.min(25, (metrics.firstContentfulPaint - 1800) / 100);
  }

  // LCP: Largest Contentful Paint (target: < 2.5s)
  if (metrics.largestContentfulPaint > 2500) {
    score -= Math.min(25, (metrics.largestContentfulPaint - 2500) / 100);
  }

  // CLS: Cumulative Layout Shift (target: < 0.1)
  if (metrics.cumulativeLayoutShift > 0.1) {
    score -= Math.min(25, metrics.cumulativeLayoutShift * 100);
  }

  // TTI: Time to Interactive (target: < 3.8s)
  if (metrics.timeToInteractive > 3800) {
    score -= Math.min(25, (metrics.timeToInteractive - 3800) / 100);
  }

  return Math.max(0, Math.round(score));
}

