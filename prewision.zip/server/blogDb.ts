/**
 * Database helpers for blog articles and scraping jobs
 */

import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  blogArticles,
  scrapingJobs,
  InsertBlogArticle,
  InsertScrapingJob,
  BlogArticle,
  ScrapingJob,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Add a new blog article
 */
export async function addBlogArticle(
  article: InsertBlogArticle
): Promise<BlogArticle | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add blog article: database not available");
    return null;
  }

  try {
    const result = await db.insert(blogArticles).values(article);
    const id = result[0].insertId as number;

    // Fetch and return the inserted article
    const inserted = await db
      .select()
      .from(blogArticles)
      .where(eq(blogArticles.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to add blog article:", error);
    throw error;
  }
}

/**
 * Get recent blog articles
 */
export async function getRecentBlogArticles(
  limit: number = 10
): Promise<BlogArticle[]> {
  const db = await getDb();
  if (!db) {
    console.warn(
      "[Database] Cannot get blog articles: database not available"
    );
    return [];
  }

  try {
    const articles = await db
      .select()
      .from(blogArticles)
      .where(eq(blogArticles.isActive, true))
      .orderBy(desc(blogArticles.createdAt))
      .limit(limit);

    return articles;
  } catch (error) {
    console.error("[Database] Failed to get blog articles:", error);
    return [];
  }
}

/**
 * Get blog articles by category
 */
export async function getBlogArticlesByCategory(
  category: string,
  limit: number = 10
): Promise<BlogArticle[]> {
  const db = await getDb();
  if (!db) {
    console.warn(
      "[Database] Cannot get blog articles: database not available"
    );
    return [];
  }

  try {
    const articles = await db
      .select()
      .from(blogArticles)
      .where(
        and(
          eq(blogArticles.category, category as any),
          eq(blogArticles.isActive, true)
        )
      )
      .orderBy(desc(blogArticles.createdAt))
      .limit(limit);

    return articles;
  } catch (error) {
    console.error("[Database] Failed to get blog articles by category:", error);
    return [];
  }
}

/**
 * Check if article already exists
 */
export async function articleExists(originalUrl: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check article: database not available");
    return false;
  }

  try {
    const existing = await db
      .select()
      .from(blogArticles)
      .where(eq(blogArticles.originalUrl, originalUrl))
      .limit(1);

    return existing.length > 0;
  } catch (error) {
    console.error("[Database] Failed to check article existence:", error);
    return false;
  }
}

/**
 * Create or update scraping job
 */
export async function createOrUpdateScrapingJob(
  job: InsertScrapingJob
): Promise<ScrapingJob | null> {
  const db = await getDb();
  if (!db) {
    console.warn(
      "[Database] Cannot create scraping job: database not available"
    );
    return null;
  }

  try {
    // Check if job exists
    const existing = await db
      .select()
      .from(scrapingJobs)
      .where(eq(scrapingJobs.sourceUrl, job.sourceUrl))
      .limit(1);

    if (existing.length > 0) {
      // Update existing job
      await db
        .update(scrapingJobs)
        .set(job)
        .where(eq(scrapingJobs.sourceUrl, job.sourceUrl));

      const updated = await db
        .select()
        .from(scrapingJobs)
        .where(eq(scrapingJobs.sourceUrl, job.sourceUrl))
        .limit(1);

      return updated.length > 0 ? updated[0] : null;
    } else {
      // Create new job
      const result = await db.insert(scrapingJobs).values(job);
      const id = result[0].insertId as number;

      const inserted = await db
        .select()
        .from(scrapingJobs)
        .where(eq(scrapingJobs.id, id))
        .limit(1);

      return inserted.length > 0 ? inserted[0] : null;
    }
  } catch (error) {
    console.error("[Database] Failed to create/update scraping job:", error);
    throw error;
  }
}

/**
 * Get scraping jobs
 */
export async function getScrapingJobs(
  onlyActive: boolean = true
): Promise<ScrapingJob[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get scraping jobs: database not available");
    return [];
  }

  try {
    let query = db.select().from(scrapingJobs);

    if (onlyActive) {
      query = query.where(eq(scrapingJobs.isActive, true)) as any;
    }

    const jobs = await query.orderBy(desc(scrapingJobs.updatedAt));
    return jobs;
  } catch (error) {
    console.error("[Database] Failed to get scraping jobs:", error);
    return [];
  }
}

/**
 * Get all categories
 */
export async function getBlogCategories(): Promise<string[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get categories: database not available");
    return [];
  }

  try {
    const articles = await db
      .select({ category: blogArticles.category })
      .from(blogArticles)
      .where(eq(blogArticles.isActive, true));

    const uniqueCategories = new Set(articles.map((a) => a.category));
    const categories = Array.from(uniqueCategories);
    return categories;
  } catch (error) {
    console.error("[Database] Failed to get categories:", error);
    return [];
  }
}

