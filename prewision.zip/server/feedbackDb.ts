/**
 * Database helpers for user feedback
 */

import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { userFeedback, InsertUserFeedback, UserFeedback } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Save user feedback
 */
export async function saveFeedback(
  data: InsertUserFeedback
): Promise<UserFeedback | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save feedback: database not available");
    return null;
  }

  try {
    const result = await db.insert(userFeedback).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(userFeedback)
      .where(eq(userFeedback.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to save feedback:", error);
    throw error;
  }
}

/**
 * Get recent feedback (for admin)
 */
export async function getRecentFeedback(limit: number = 50): Promise<UserFeedback[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get feedback: database not available");
    return [];
  }

  try {
    const feedback = await db
      .select()
      .from(userFeedback)
      .orderBy(desc(userFeedback.createdAt))
      .limit(limit);

    return feedback;
  } catch (error) {
    console.error("[Database] Failed to get feedback:", error);
    return [];
  }
}

/**
 * Get feedback statistics
 */
export async function getFeedbackStats(): Promise<{
  totalFeedback: number;
  avgChatbotRating: number;
  avgArticlesRating: number;
  chatbotPositive: number;
  articlesPositive: number;
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get stats: database not available");
    return {
      totalFeedback: 0,
      avgChatbotRating: 0,
      avgArticlesRating: 0,
      chatbotPositive: 0,
      articlesPositive: 0,
    };
  }

  try {
    const allFeedback = await db.select().from(userFeedback);

    const totalFeedback = allFeedback.length;
    const chatbotRatings = allFeedback
      .filter((f) => f.chatbotRating)
      .map((f) => f.chatbotRating as number);
    const articlesRatings = allFeedback
      .filter((f) => f.articlesRating)
      .map((f) => f.articlesRating as number);

    const avgChatbotRating =
      chatbotRatings.length > 0
        ? chatbotRatings.reduce((a, b) => a + b, 0) / chatbotRatings.length
        : 0;
    const avgArticlesRating =
      articlesRatings.length > 0
        ? articlesRatings.reduce((a, b) => a + b, 0) / articlesRatings.length
        : 0;

    const chatbotPositive = chatbotRatings.filter((r) => r >= 4).length;
    const articlesPositive = articlesRatings.filter((r) => r >= 4).length;

    return {
      totalFeedback,
      avgChatbotRating: Math.round(avgChatbotRating * 10) / 10,
      avgArticlesRating: Math.round(avgArticlesRating * 10) / 10,
      chatbotPositive,
      articlesPositive,
    };
  } catch (error) {
    console.error("[Database] Failed to get stats:", error);
    return {
      totalFeedback: 0,
      avgChatbotRating: 0,
      avgArticlesRating: 0,
      chatbotPositive: 0,
      articlesPositive: 0,
    };
  }
}

