/**
 * Database helpers for resources management
 */

import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  resources,
  resourceDownloads,
  InsertResource,
  InsertResourceDownload,
  Resource,
  ResourceDownload,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Add a new resource
 */
export async function addResource(
  data: InsertResource
): Promise<Resource | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add resource: database not available");
    return null;
  }

  try {
    const result = await db.insert(resources).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(resources)
      .where(eq(resources.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to add resource:", error);
    throw error;
  }
}

/**
 * Get all active resources
 */
export async function getActiveResources(): Promise<Resource[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get resources: database not available");
    return [];
  }

  try {
    const allResources = await db
      .select()
      .from(resources)
      .where(eq(resources.isActive, true))
      .orderBy(desc(resources.createdAt));

    return allResources;
  } catch (error) {
    console.error("[Database] Failed to get resources:", error);
    return [];
  }
}

/**
 * Get resources by category
 */
export async function getResourcesByCategory(
  category: string
): Promise<Resource[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get resources: database not available");
    return [];
  }

  try {
    const categoryResources = await db
      .select()
      .from(resources)
      .where(
        and(
          eq(resources.category, category),
          eq(resources.isActive, true)
        )
      )
      .orderBy(desc(resources.createdAt));

    return categoryResources;
  } catch (error) {
    console.error("[Database] Failed to get resources by category:", error);
    return [];
  }
}

/**
 * Record a resource download
 */
export async function recordDownload(
  data: InsertResourceDownload
): Promise<ResourceDownload | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot record download: database not available");
    return null;
  }

  try {
    const result = await db.insert(resourceDownloads).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(resourceDownloads)
      .where(eq(resourceDownloads.id, id))
      .limit(1);

    // Increment download count
    if (inserted.length > 0) {
      await db
        .update(resources)
        .set({
          downloadCount: data.resourceId,
        })
        .where(eq(resources.id, data.resourceId));
    }

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to record download:", error);
    throw error;
  }
}

/**
 * Get download statistics for a resource
 */
export async function getResourceStats(resourceId: number): Promise<{
  downloadCount: number;
  lastDownloadDate?: Date;
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get stats: database not available");
    return { downloadCount: 0 };
  }

  try {
    const resource = await db
      .select()
      .from(resources)
      .where(eq(resources.id, resourceId))
      .limit(1);

    if (resource.length === 0) {
      return { downloadCount: 0 };
    }

    const downloads = await db
      .select()
      .from(resourceDownloads)
      .where(eq(resourceDownloads.resourceId, resourceId))
      .orderBy(desc(resourceDownloads.downloadedAt))
      .limit(1);

    return {
      downloadCount: resource[0].downloadCount,
      lastDownloadDate:
        downloads.length > 0 ? downloads[0].downloadedAt : undefined,
    };
  } catch (error) {
    console.error("[Database] Failed to get stats:", error);
    return { downloadCount: 0 };
  }
}

/**
 * Get total downloads count
 */
export async function getTotalDownloads(): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get total downloads: database not available");
    return 0;
  }

  try {
    const downloads = await db.select().from(resourceDownloads);
    return downloads.length;
  } catch (error) {
    console.error("[Database] Failed to get total downloads:", error);
    return 0;
  }
}

