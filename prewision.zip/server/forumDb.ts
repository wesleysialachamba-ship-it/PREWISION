/**
 * Database helpers for forum management
 */

import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  forumThreads,
  forumReplies,
  InsertForumThread,
  InsertForumReply,
  ForumThread,
  ForumReply,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Create a new forum thread
 */
export async function createForumThread(
  data: InsertForumThread
): Promise<ForumThread | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create thread: database not available");
    return null;
  }

  try {
    const result = await db.insert(forumThreads).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(forumThreads)
      .where(eq(forumThreads.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create thread:", error);
    throw error;
  }
}

/**
 * Get published forum threads
 */
export async function getPublishedThreads(
  limit: number = 20,
  offset: number = 0
): Promise<ForumThread[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get threads: database not available");
    return [];
  }

  try {
    const threads = await db
      .select()
      .from(forumThreads)
      .where(eq(forumThreads.status, "published"))
      .orderBy(desc(forumThreads.isPinned), desc(forumThreads.createdAt))
      .limit(limit)
      .offset(offset);

    return threads;
  } catch (error) {
    console.error("[Database] Failed to get threads:", error);
    return [];
  }
}

/**
 * Get forum thread by ID with replies
 */
export async function getThreadWithReplies(
  threadId: number
): Promise<{
  thread: ForumThread | null;
  replies: ForumReply[];
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get thread: database not available");
    return { thread: null, replies: [] };
  }

  try {
    const thread = await db
      .select()
      .from(forumThreads)
      .where(eq(forumThreads.id, threadId))
      .limit(1);

    const replies = await db
      .select()
      .from(forumReplies)
      .where(
        and(
          eq(forumReplies.threadId, threadId),
          eq(forumReplies.status, "published")
        )
      )
      .orderBy(desc(forumReplies.isAnswer), desc(forumReplies.likes), forumReplies.createdAt);

    // Increment view count
    if (thread.length > 0) {
      await db
        .update(forumThreads)
        .set({ viewCount: thread[0].viewCount + 1 })
        .where(eq(forumThreads.id, threadId));
    }

    return {
      thread: thread.length > 0 ? thread[0] : null,
      replies,
    };
  } catch (error) {
    console.error("[Database] Failed to get thread:", error);
    return { thread: null, replies: [] };
  }
}

/**
 * Create a forum reply
 */
export async function createForumReply(
  data: InsertForumReply
): Promise<ForumReply | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create reply: database not available");
    return null;
  }

  try {
    const result = await db.insert(forumReplies).values(data);
    const id = result[0].insertId as number;

    const inserted = await db
      .select()
      .from(forumReplies)
      .where(eq(forumReplies.id, id))
      .limit(1);

    return inserted.length > 0 ? inserted[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create reply:", error);
    throw error;
  }
}

/**
 * Get pending forum items for moderation
 */
export async function getPendingForumItems(): Promise<{
  threads: ForumThread[];
  replies: ForumReply[];
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get pending items: database not available");
    return { threads: [], replies: [] };
  }

  try {
    const threads = await db
      .select()
      .from(forumThreads)
      .where(eq(forumThreads.status, "pending"))
      .orderBy(forumThreads.createdAt);

    const replies = await db
      .select()
      .from(forumReplies)
      .where(eq(forumReplies.status, "pending"))
      .orderBy(forumReplies.createdAt);

    return { threads, replies };
  } catch (error) {
    console.error("[Database] Failed to get pending items:", error);
    return { threads: [], replies: [] };
  }
}

/**
 * Approve forum thread
 */
export async function approveForumThread(threadId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot approve thread: database not available");
    return false;
  }

  try {
    await db
      .update(forumThreads)
      .set({ status: "published" })
      .where(eq(forumThreads.id, threadId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to approve thread:", error);
    return false;
  }
}

/**
 * Reject forum thread
 */
export async function rejectForumThread(threadId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot reject thread: database not available");
    return false;
  }

  try {
    await db
      .update(forumThreads)
      .set({ status: "rejected" })
      .where(eq(forumThreads.id, threadId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to reject thread:", error);
    return false;
  }
}

/**
 * Approve forum reply
 */
export async function approveForumReply(replyId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot approve reply: database not available");
    return false;
  }

  try {
    const reply = await db
      .select()
      .from(forumReplies)
      .where(eq(forumReplies.id, replyId))
      .limit(1);

    if (reply.length === 0) return false;

    await db
      .update(forumReplies)
      .set({ status: "published" })
      .where(eq(forumReplies.id, replyId));

    // Increment reply count on thread
    await db
      .update(forumThreads)
      .set({ replyCount: reply[0].threadId })
      .where(eq(forumThreads.id, reply[0].threadId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to approve reply:", error);
    return false;
  }
}

/**
 * Reject forum reply
 */
export async function rejectForumReply(replyId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot reject reply: database not available");
    return false;
  }

  try {
    await db
      .update(forumReplies)
      .set({ status: "rejected" })
      .where(eq(forumReplies.id, replyId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to reject reply:", error);
    return false;
  }
}

/**
 * Pin/unpin forum thread
 */
export async function togglePinThread(threadId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot pin thread: database not available");
    return false;
  }

  try {
    const thread = await db
      .select()
      .from(forumThreads)
      .where(eq(forumThreads.id, threadId))
      .limit(1);

    if (thread.length === 0) return false;

    await db
      .update(forumThreads)
      .set({ isPinned: !thread[0].isPinned })
      .where(eq(forumThreads.id, threadId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to pin thread:", error);
    return false;
  }
}

/**
 * Mark reply as answer
 */
export async function markAsAnswer(replyId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot mark as answer: database not available");
    return false;
  }

  try {
    await db
      .update(forumReplies)
      .set({ isAnswer: true })
      .where(eq(forumReplies.id, replyId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to mark as answer:", error);
    return false;
  }
}

