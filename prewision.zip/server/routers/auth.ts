/**
 * Authentication router for local user registration and login
 */

import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import {
  registerUser,
  authenticateUser,
  getUserById,
  getUserByEmail,
  getAllUsers,
} from "../_core/localUserService";
import {
  createOrGetTempSession,
  checkTempSessionValidity,
  formatRemainingTime,
} from "../_core/tempSessionService";

export const authRouter = router({
  /**
   * Register a new user
   */
  register: publicProcedure
    .input(
      z.object({
        email: z.string().email("Invalid email format"),
        password: z.string().min(8, "Password must be at least 8 characters"),
        confirmPassword: z.string(),
        name: z.string().optional(),
      })
    )
    .mutation(async (opts: any) => {
      const input = opts.input;
      if (input.password !== input.confirmPassword) {
        return {
          success: false,
          error: "Passwords do not match",
        };
      }

      const result = await registerUser({
        email: input.email,
        password: input.password,
        name: input.name,
      });

      return result;
    }),

  /**
   * Login with email and password
   */
  login: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      })
    )
    .mutation(async (opts: any) => {
      const input = opts.input;
      const result = await authenticateUser(input.email, input.password);
      return result;
    }),

  /**
   * Get current user info by ID
   */
  getCurrentUser: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(async (opts: any) => {
      const input = opts.input;
      const user = await getUserById(input.userId);
      return user;
    }),

  /**
   * Get user by email
   */
  getUserByEmail: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .query(async (opts: any) => {
      const input = opts.input;
      const user = await getUserByEmail(input.email);
      return user;
    }),

  /**
   * Create or get temporary session by IP
   */
  createTempSession: publicProcedure
    .input(z.object({ ipAddress: z.string() }))
    .mutation(async (opts: any) => {
      const input = opts.input;
      try {
        const session = await createOrGetTempSession(input.ipAddress);
        return {
          success: true,
          ...session,
          formattedTime: formatRemainingTime(session.remainingMs),
        };
      } catch (error) {
        return {
          success: false,
          error: (error as Error).message,
        };
      }
    }),

  /**
   * Check temporary session validity
   */
  checkTempSession: publicProcedure
    .input(z.object({ ipAddress: z.string() }))
    .query(async (opts: any) => {
      const input = opts.input;
      try {
        const validity = await checkTempSessionValidity(input.ipAddress);
        return {
          ...validity,
          formattedTime: formatRemainingTime(validity.remainingMs),
        };
      } catch (error) {
        return {
          isValid: false,
          remainingMs: 0,
          error: (error as Error).message,
        };
      }
    }),

  /**
   * Get all registered users (admin only)
   */
  getAllUsers: publicProcedure
    .input(
      z.object({
        limit: z.number().default(100),
        offset: z.number().default(0),
      })
    )
    .query(async (opts: any) => {
      const input = opts.input;
      const result = await getAllUsers(input.limit, input.offset);
      return result;
    }),
});

