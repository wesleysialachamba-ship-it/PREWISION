import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  chatConversations,
  chatMessages,
  InsertChatConversation,
  InsertChatMessage,
} from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Create a new conversation
 */
export async function createConversation(
  userEmail: string | null,
  title: string = "Nouvelle conversation"
): Promise<number> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(chatConversations).values({
    userEmail,
    title,
    messageCount: 0,
  });

  return result[0].insertId;
}

/**
 * Get all conversations for a user
 */
export async function getUserConversations(userEmail: string | null) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  if (!userEmail) {
    return [];
  }

  const conversations = await db
    .select()
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.userEmail, userEmail),
        eq(chatConversations.isArchived, false)
      )
    )
    .orderBy(desc(chatConversations.updatedAt));

  return conversations;
}

/**
 * Get a specific conversation with all its messages
 */
export async function getConversationWithMessages(conversationId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const conversation = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);

  if (!conversation || conversation.length === 0) {
    return null;
  }

  const messages = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.conversationId, conversationId))
    .orderBy(chatMessages.createdAt);

  return {
    ...conversation[0],
    messages,
  };
}

/**
 * Add a message to a conversation
 */
export async function addMessageToConversation(
  conversationId: number,
  role: "user" | "assistant",
  content: string,
  imageUrl?: string,
  imageSuggestion?: string
): Promise<number> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Insert the message
  const result = await db.insert(chatMessages).values({
    conversationId,
    role,
    content,
    imageUrl,
    imageSuggestion,
  });

  // Update message count in conversation
  const conversation = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);

  if (conversation && conversation.length > 0) {
    const newMessageCount = (conversation[0].messageCount || 0) + 1;
    await db
      .update(chatConversations)
      .set({
        messageCount: newMessageCount,
        updatedAt: new Date(),
      })
      .where(eq(chatConversations.id, conversationId));
  }

  return result[0].insertId;
}

/**
 * Update conversation title
 */
export async function updateConversationTitle(
  conversationId: number,
  title: string
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db
    .update(chatConversations)
    .set({
      title,
      updatedAt: new Date(),
    })
    .where(eq(chatConversations.id, conversationId));
}

/**
 * Archive a conversation
 */
export async function archiveConversation(conversationId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db
    .update(chatConversations)
    .set({
      isArchived: true,
      updatedAt: new Date(),
    })
    .where(eq(chatConversations.id, conversationId));
}

/**
 * Delete a conversation and all its messages
 */
export async function deleteConversation(conversationId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Delete all messages first
  await db
    .delete(chatMessages)
    .where(eq(chatMessages.conversationId, conversationId));

  // Delete the conversation
  await db
    .delete(chatConversations)
    .where(eq(chatConversations.id, conversationId));
}

/**
 * Get recent conversations (for dashboard)
 */
export async function getRecentConversations(limit: number = 10) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const conversations = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.isArchived, false))
    .orderBy(desc(chatConversations.updatedAt))
    .limit(limit);

  return conversations;
}

