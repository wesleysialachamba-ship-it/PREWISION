import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getOrganizations, getNews, getRecentNews, getNewsByCategory, saveChatHistory as saveChatHistoryDb } from "./db";
import { getRecentBlogArticles, getBlogArticlesByCategory, getBlogCategories, getScrapingJobs } from "./blogDb";
import { triggerManualScraping } from "./_core/scrapingScheduler";
import { getActiveResources, recordDownload as recordResourceDownload } from "./resourcesDb";
import { 
  getPublishedThreads, 
  getThreadWithReplies, 
  createForumThread, 
  createForumReply,
  getPendingForumItems,
  approveForumThread,
  rejectForumThread,
  approveForumReply,
  rejectForumReply,
  togglePinThread,
  markAsAnswer
} from "./forumDb";
import { saveFeedback, getRecentFeedback, getFeedbackStats } from "./feedbackDb";
import { notifyOwner } from "./_core/notification";
import {
  createConversation,
  getUserConversations,
  getConversationWithMessages,
  addMessageToConversation,
  updateConversationTitle,
  archiveConversation,
  deleteConversation,
} from "./chatDb";
import {
  registerUser,
  authenticateUser,
} from "./_core/localUserService";
import {
  createOrGetTempSession,
  checkTempSessionValidity,
  formatRemainingTime,
} from "./_core/tempSessionService";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    register: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          password: z.string().min(8),
          confirmPassword: z.string(),
          name: z.string().optional(),
        })
      )
      .mutation(async (opts: any) => {
        const input = opts.input;
        if (input.password !== input.confirmPassword) {
          return { success: false, error: "Passwords do not match" };
        }
        return await registerUser({
          email: input.email,
          password: input.password,
          name: input.name,
        });
      }),
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async (opts: any) => {
        const input = opts.input;
        return await authenticateUser(input.email, input.password);
      }),
    createTempSession: publicProcedure
      .input(z.object({ ipAddress: z.string() }))
      .mutation(async (opts: any) => {
        const input = opts.input;
        try {
          const session = await createOrGetTempSession(input.ipAddress);
          return {
            success: true,
            ...session,
            formattedTime: formatRemainingTime(session.remainingMs),
          };
        } catch (error) {
          return { success: false, error: (error as Error).message };
        }
      }),
    checkTempSession: publicProcedure
      .input(z.object({ ipAddress: z.string() }))
      .query(async (opts: any) => {
        const input = opts.input;
        try {
          const validity = await checkTempSessionValidity(input.ipAddress);
          return {
            ...validity,
            formattedTime: formatRemainingTime(validity.remainingMs),
          };
        } catch (error) {
          return { isValid: false, remainingMs: 0, error: (error as Error).message };
        }
      }),
    getAllUsers: publicProcedure
      .input(
        z.object({
          limit: z.number().default(100),
          offset: z.number().default(0),
        })
      )
      .query(async (opts: any) => {
        const { getAllUsers } = await import("./_core/localUserService");
        const input = opts.input;
        return await getAllUsers(input.limit, input.offset);
      }),
  }),

  // News and Organizations routes
  news: router({
    /**
     * Get all recent news
     */
    getRecent: publicProcedure.query(async () => {
      return await getRecentNews();
    }),

    /**
     * Get paginated news
     */
    getAll: publicProcedure
      .input(
        z.object({
          limit: z.number().default(20),
          offset: z.number().default(0),
          organizationId: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getNews(input.limit, input.offset, input.organizationId);
      }),

    /**
     * Get news by category
     */
    getByCategory: publicProcedure
      .input(
        z.object({
          category: z.string(),
          limit: z.number().default(10),
        })
      )
      .query(async ({ input }) => {
        return await getNewsByCategory(input.category, input.limit);
      }),
  }),

  organizations: router({
    /**
     * Get all organizations
     */
    getAll: publicProcedure.query(async () => {
      return await getOrganizations();
    }),
  }),

  chat: router({
    /**
     * Create a new conversation
     */
    createConversation: publicProcedure
      .input(
        z.object({
          title: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const conversationId = await createConversation(
          ctx.user?.email || null,
          input.title || "Nouvelle conversation"
        );
        return { conversationId };
      }),

    /**
     * Get user's conversations
     */
    getConversations: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user?.email) {
        return [];
      }
      return await getUserConversations(ctx.user.email);
    }),

    /**
     * Get a specific conversation with messages
     */
    getConversation: publicProcedure
      .input(
        z.object({
          conversationId: z.number(),
        })
      )
      .query(async ({ input }) => {
        return await getConversationWithMessages(input.conversationId);
      }),

    /**
     * Add a message to a conversation
     */
    addMessage: publicProcedure
      .input(
        z.object({
          conversationId: z.number(),
          role: z.enum(["user", "assistant"]),
          content: z.string(),
          imageUrl: z.string().optional(),
          imageSuggestion: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const messageId = await addMessageToConversation(
          input.conversationId,
          input.role,
          input.content,
          input.imageUrl,
          input.imageSuggestion
        );
        return { messageId };
      }),

    /**
     * Update conversation title
     */
    updateTitle: publicProcedure
      .input(
        z.object({
          conversationId: z.number(),
          title: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        await updateConversationTitle(input.conversationId, input.title);
        return { success: true };
      }),

    /**
     * Archive a conversation
     */
    archive: publicProcedure
      .input(
        z.object({
          conversationId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await archiveConversation(input.conversationId);
        return { success: true };
      }),

    /**
     * Delete a conversation
     */
    delete: publicProcedure
      .input(
        z.object({
          conversationId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await deleteConversation(input.conversationId);
        return { success: true };
      }),

    /**
     * Save chat interaction (legacy)
     */
    saveInteraction: publicProcedure
      .input(
        z.object({
          message: z.string(),
          response: z.string(),
          category: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await saveChatHistoryDb(ctx.user?.id || null, input.message, input.response, input.category);
      }),
  }),

  blog: router({
    /**
     * Get recent blog articles
     */
    getRecent: publicProcedure
      .input(
        z.object({
          limit: z.number().default(10),
        })
      )
      .query(async ({ input }) => {
        return await getRecentBlogArticles(input.limit);
      }),

    /**
     * Get blog articles by category
     */
    getByCategory: publicProcedure
      .input(
        z.object({
          category: z.string(),
          limit: z.number().default(10),
        })
      )
      .query(async ({ input }) => {
        return await getBlogArticlesByCategory(input.category, input.limit);
      }),

    /**
     * Get all available categories
     */
    getCategories: publicProcedure.query(async () => {
      return await getBlogCategories();
    }),

    /**
     * Get scraping jobs status (admin only)
     */
    getScrapingStatus: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Admin access required");
      }
      return await getScrapingJobs(true);
    }),

    /**
     * Trigger manual scraping (admin only)
     */
    triggerScraping: protectedProcedure.mutation(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Admin access required");
      }
      const results = await triggerManualScraping();
      return { success: true, results };
    }),
  }),

  // Resources routes
  resources: router({
    /**
     * Get all active resources
     */
    list: publicProcedure.query(async () => {
      return await getActiveResources();
    }),

    /**
     * Record a resource download
     */
    recordDownload: publicProcedure
      .input(
        z.object({
          resourceId: z.number(),
          email: z.string().email(),
          name: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        return await recordResourceDownload({
          resourceId: input.resourceId,
          email: input.email,
          name: input.name,
        });
      }),
  }),

  // Forum routes
  forum: router({
    /**
     * Get published forum threads
     */
    getThreads: publicProcedure
      .input(
        z.object({
          limit: z.number().default(20),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        return await getPublishedThreads(input.limit, input.offset);
      }),

    /**
     * Get forum thread with replies
     */
    getThread: publicProcedure
      .input(z.object({ threadId: z.number() }))
      .query(async ({ input }) => {
        return await getThreadWithReplies(input.threadId);
      }),

    /**
     * Create a new forum thread
     */
    createThread: publicProcedure
      .input(
        z.object({
          title: z.string().min(5).max(500),
          content: z.string().min(10),
          authorName: z.string().min(2).max(255),
          authorEmail: z.string().email(),
          category: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        return await createForumThread({
          title: input.title,
          content: input.content,
          authorName: input.authorName,
          authorEmail: input.authorEmail,
          category: input.category,
          status: "pending",
        });
      }),

    /**
     * Create a forum reply
     */
    createReply: publicProcedure
      .input(
        z.object({
          threadId: z.number(),
          content: z.string().min(5),
          authorName: z.string().min(2).max(255),
          authorEmail: z.string().email(),
        })
      )
      .mutation(async ({ input }) => {
        return await createForumReply({
          threadId: input.threadId,
          content: input.content,
          authorName: input.authorName,
          authorEmail: input.authorEmail,
          status: "pending",
        });
      }),

    /**
     * Get pending items for moderation (admin only)
     */
    getPendingItems: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Admin access required");
      }
      return await getPendingForumItems();
    }),

    /**
     * Approve forum thread (admin only)
     */
    approveThread: protectedProcedure
      .input(z.object({ threadId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await approveForumThread(input.threadId);
      }),

    /**
     * Reject forum thread (admin only)
     */
    rejectThread: protectedProcedure
      .input(z.object({ threadId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await rejectForumThread(input.threadId);
      }),

    /**
     * Approve forum reply (admin only)
     */
    approveReply: protectedProcedure
      .input(z.object({ replyId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await approveForumReply(input.replyId);
      }),

    /**
     * Reject forum reply (admin only)
     */
    rejectReply: protectedProcedure
      .input(z.object({ replyId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await rejectForumReply(input.replyId);
      }),

    /**
     * Pin/unpin forum thread (admin only)
     */
    togglePin: protectedProcedure
      .input(z.object({ threadId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await togglePinThread(input.threadId);
      }),

    /**
     * Mark reply as answer (admin only)
     */
    markAsAnswer: protectedProcedure
      .input(z.object({ replyId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await markAsAnswer(input.replyId);
      }),
  }),

  // Feedback routes
  feedback: router({
    /**
     * Submit user feedback
     */
    submit: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          chatbotRating: z.number().min(1).max(5).optional(),
          chatbotFeedback: z.string().optional(),
          articlesRating: z.number().min(1).max(5).optional(),
          articlesFeedback: z.string().optional(),
          additionalComments: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const feedback = await saveFeedback({
          email: input.email,
          chatbotRating: input.chatbotRating,
          chatbotFeedback: input.chatbotFeedback,
          articlesRating: input.articlesRating,
          articlesFeedback: input.articlesFeedback,
          additionalComments: input.additionalComments,
        });

        // Notify admin about new feedback
        if (feedback) {
          await notifyOwner({
            title: "Nouveau feedback reçu",
            content: `Email: ${input.email}\n\nChatbot (${input.chatbotRating}/5): ${input.chatbotFeedback || "N/A"}\n\nArticles (${input.articlesRating}/5): ${input.articlesFeedback || "N/A"}\n\nCommentaires: ${input.additionalComments || "N/A"}`,
          });
        }

        return feedback;
      }),

    /**
     * Get recent feedback (admin only)
     */
    getRecent: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Admin access required");
        }
        return await getRecentFeedback(input.limit);
      }),

    /**
     * Get feedback statistics (admin only)
     */
    getStats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Admin access required");
      }
      return await getFeedbackStats();
    }),
  }),
});

export type AppRouter = typeof appRouter;

