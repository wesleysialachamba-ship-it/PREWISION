/**
 * Image Service - Récupère des images depuis Unsplash pour les articles BTP
 * Utilise des mots-clés pertinents pour le secteur BTP
 */

export interface UnsplashImage {
  id: string;
  urls: {
    regular: string;
    thumb: string;
    small: string;
  };
  alt_description: string;
  user: {
    name: string;
  };
  links: {
    html: string;
  };
}

/**
 * Récupère une image depuis Unsplash basée sur des mots-clés BTP
 */
export async function getImageFromUnsplash(category: string): Promise<string | null> {
  try {
    // Mapping des catégories aux mots-clés Unsplash
    const keywordMap: Record<string, string> = {
      "Sécurité": "construction safety equipment",
      "Santé": "workplace health safety",
      "Prévention": "accident prevention construction",
      "Réglementation": "construction rules safety",
      "Formation": "construction training workers",
      "Innovation": "construction technology safety",
      "Autre": "construction site safety",
    };

    const keywords = keywordMap[category] || "construction site safety";
    
    // Unsplash API endpoint
    const unsplashUrl = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(keywords)}&per_page=1&orientation=landscape`;
    
    const response = await fetch(unsplashUrl, {
      headers: {
        "Authorization": `Client-ID ${process.env.UNSPLASH_ACCESS_KEY || "demo"}`,
      },
    });

    if (!response.ok) {
      console.warn(`Unsplash API error: ${response.status}`);
      return null;
    }

    const data = await response.json() as { results: UnsplashImage[] };
    
    if (!data.results || data.results.length === 0) {
      return null;
    }

    const image = data.results[0];
    return image.urls.regular;
  } catch (error) {
    console.error("Error fetching image from Unsplash:", error);
    return null;
  }
}

/**
 * Récupère une image avec fallback sur une image par défaut
 */
export async function getArticleImage(category: string, title: string): Promise<string> {
  try {
    // Essayer de récupérer depuis Unsplash
    const unsplashImage = await getImageFromUnsplash(category);
    if (unsplashImage) {
      return unsplashImage;
    }
  } catch (error) {
    console.warn("Failed to get Unsplash image:", error);
  }

  // Fallback sur une image par défaut basée sur la catégorie
  const defaultImages: Record<string, string> = {
    "Sécurité": "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=600&h=400&fit=crop",
    "Santé": "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=400&fit=crop",
    "Prévention": "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=600&h=400&fit=crop",
    "Réglementation": "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    "Formation": "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    "Innovation": "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    "Autre": "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=600&h=400&fit=crop",
  };

  return defaultImages[category] || defaultImages["Autre"];
}

/**
 * Extrait une image d'une page HTML via scraping simple
 */
export async function extractImageFromHTML(url: string): Promise<string | null> {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!response.ok) {
      return null;
    }

    const html = await response.text();
    
    // Chercher les images dans les balises og:image ou les images principales
    const ogImageMatch = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/);
    if (ogImageMatch && ogImageMatch[1]) {
      return ogImageMatch[1];
    }

    // Chercher la première image img avec une taille raisonnable
    const imgMatch = html.match(/<img[^>]+src="([^"]+)"[^>]*>/);
    if (imgMatch && imgMatch[1]) {
      const imgUrl = imgMatch[1];
      // Vérifier que ce n'est pas un logo ou une petite image
      if (!imgUrl.includes("logo") && !imgUrl.includes("icon")) {
        return imgUrl;
      }
    }

    return null;
  } catch (error) {
    console.error("Error extracting image from HTML:", error);
    return null;
  }
}

