/**
 * Validation service for SIRET, email, and other data
 */

/**
 * Validate SIRET format (14 digits)
 */
export function validateSiret(siret: string): boolean {
  if (!siret) return true; // SIRET is optional
  
  // Remove spaces and dashes
  const cleanSiret = siret.replace(/[\s-]/g, "");
  
  // Must be 14 digits
  if (!/^\d{14}$/.test(cleanSiret)) {
    return false;
  }
  
  // Optional: Validate SIRET checksum (Luhn algorithm)
  return validateSiretChecksum(cleanSiret);
}

/**
 * Validate SIRET checksum using Luhn algorithm
 */
function validateSiretChecksum(siret: string): boolean {
  if (siret.length !== 14) return false;
  
  let sum = 0;
  for (let i = 0; i < 14; i++) {
    let digit = parseInt(siret[i], 10);
    
    // Double every second digit
    if (i % 2 === 0) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email format
 */
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate password strength
 */
export function validatePassword(password: string): {
  isValid: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push("Le mot de passe doit contenir au moins 8 caractères");
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins une lettre majuscule");
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins une lettre minuscule");
  }
  
  if (!/[0-9]/.test(password)) {
    errors.push("Le mot de passe doit contenir au moins un chiffre");
  }
  
  return {
    isValid: errors.length === 0,
    errors,
  };
}

/**
 * Validate company name
 */
export function validateCompanyName(name: string): boolean {
  return name.length >= 2 && name.length <= 255;
}

/**
 * Validate full name
 */
export function validateFullName(name: string): boolean {
  return name.length >= 2 && name.length <= 255 && /^[a-zA-Z\s'-]+$/.test(name);
}

/**
 * Sanitize email (lowercase)
 */
export function sanitizeEmail(email: string): string {
  return email.toLowerCase().trim();
}

/**
 * Sanitize text input
 */
export function sanitizeText(text: string): string {
  return text.trim().replace(/[<>]/g, "");
}

