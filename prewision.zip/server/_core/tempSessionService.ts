/**
 * Temporary session service for 30-minute free access by IP address
 */

import { getDb } from "../db";
import { tempSessions } from "../../drizzle/schema";
import { eq, and, lte, not } from "drizzle-orm";

const TEMP_SESSION_DURATION_MS = 30 * 60 * 1000; // 30 minutes

export async function createOrGetTempSession(ipAddress: string): Promise<{
  isNew: boolean;
  expiresAt: Date;
  remainingMs: number;
}> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if session already exists for this IP
  const existingSession = await db
    .select()
    .from(tempSessions)
    .where(eq(tempSessions.ipAddress, ipAddress))
    .limit(1);

  if (existingSession.length > 0) {
    const session = existingSession[0];
    
    // Check if session is still valid
    const now = new Date();
    if (session.expiresAt > now && !session.isExpired) {
      const remainingMs = session.expiresAt.getTime() - now.getTime();
      return {
        isNew: false,
        expiresAt: session.expiresAt,
        remainingMs: Math.max(0, remainingMs),
      };
    } else {
      // Session expired, mark it as expired
      await db
        .update(tempSessions)
        .set({ isExpired: true })
        .where(eq(tempSessions.ipAddress, ipAddress));
      
      throw new Error("Session expired");
    }
  }

  // Create new session
  const now = new Date();
  const expiresAt = new Date(now.getTime() + TEMP_SESSION_DURATION_MS);

  await db.insert(tempSessions).values({
    ipAddress,
    createdAt: now,
    expiresAt,
    isExpired: false,
  });

  return {
    isNew: true,
    expiresAt,
    remainingMs: TEMP_SESSION_DURATION_MS,
  };
}

export async function checkTempSessionValidity(ipAddress: string): Promise<{
  isValid: boolean;
  remainingMs: number;
  expiresAt?: Date;
}> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const session = await db
    .select()
    .from(tempSessions)
    .where(eq(tempSessions.ipAddress, ipAddress))
    .limit(1);

  if (session.length === 0) {
    return {
      isValid: false,
      remainingMs: 0,
    };
  }

  const sess = session[0];
  const now = new Date();

  if (sess.isExpired || sess.expiresAt <= now) {
    return {
      isValid: false,
      remainingMs: 0,
      expiresAt: sess.expiresAt,
    };
  }

  const remainingMs = sess.expiresAt.getTime() - now.getTime();

  return {
    isValid: true,
    remainingMs: Math.max(0, remainingMs),
    expiresAt: sess.expiresAt,
  };
}

export async function expireTempSession(ipAddress: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(tempSessions)
    .set({ isExpired: true })
    .where(eq(tempSessions.ipAddress, ipAddress));
}

export async function cleanupExpiredSessions(): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  await db
    .update(tempSessions)
    .set({ isExpired: true })
    .where(and(lte(tempSessions.expiresAt, now), not(tempSessions.isExpired)));

  return 0; // Return count of cleaned sessions
}

export function formatRemainingTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

