/**
 * Perplexity AI Client - Questions BTP
 * Handles secure communication with Perplexity API for BTP-specific questions
 * All API calls are made server-side to prevent key exposure
 * 
 * Updated system prompt:
 * - Concise responses (max 100 words)
 * - Professional expert tone
 * - No references or citations
 * - Clear, practical language
 * - Image suggestions for visual topics
 */

const PERPLEXITY_API_URL = "https://api.perplexity.ai/chat/completions";

export interface PerplexityMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface PerplexityResponse {
  id: string;
  model: string;
  created: number;
  object: string;
  choices: Array<{
    index: number;
    message: {
      role: string;
      content: string;
    };
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface ChatResponse {
  response: string;
  imageSuggestion?: string | null;
  imageUrl?: string | undefined;
}

/**
 * Optimized system prompt for BTP-specific context
 * Ensures responses are:
 * - Concise (max 100 words)
 * - Professional expert tone
 * - Without references or citations
 * - Limited to BTP sector in French
 * - With image suggestions when relevant
 */
const BTP_SYSTEM_PROMPT = `Tu es un expert BTP en sécurité et santé au travail, répondant en français. Donne des réponses concises (max 100 mots), claires, sans jargon complexe, dans un style professionnel comme un formateur BTP expérimenté. N'inclus ni références ni sources.

RÈGLES ESSENTIELLES:
1. MAXIMUM 100 MOTS par réponse - sois concis et direct
2. Style professionnel comme un expert parlant à un collègue
3. N'inclus PAS de références, citations, [1], [2], etc.
4. N'inclus PAS de liens externes ou d'URLs
5. Évite le jargon complexe sauf si demandé explicitement
6. Concentre-toi UNIQUEMENT sur le BTP
7. Réponds TOUJOURS en français

FORMAT DE RÉPONSE:
- Utilise des listes à puces pour la clarté
- Paragraphes courts et directs
- Pratique et applicable immédiatement
- Pas de digressions

SUGGESTION D'IMAGE:
Après ta réponse textuelle, si le sujet se prête à une illustration, ajoute sur une nouvelle ligne:
[IMAGE: description courte pertinente]
Exemples: [IMAGE: casque de sécurité sur chantier], [IMAGE: travaux en hauteur avec harnais], [IMAGE: EPI construction]
Si pas d'image pertinente, n'ajoute rien.

DOMAINES D'EXPERTISE:
Sécurité chantier, EPI, travaux en hauteur, normes DTU, réglementations, matériaux, techniques de construction, gestion de chantier, organismes de prévention (OPPBTP, INRS, CARSAT, FFB).

REFUS:
- Question hors BTP → refuse poliment
- Conseil médical/légal général → refuse
- Langue autre que français → demande reformulation

EXEMPLE:
Q: "Quels EPI pour un chantier?"
R: "Sur un chantier, les EPI obligatoires sont: casque de sécurité, gilet de haute visibilité, chaussures de sécurité, gants adaptés. Selon les tâches: masque respiratoire, lunettes, harnais pour hauteur. Chaque chantier fournit les EPI adaptés à ses risques spécifiques.
[IMAGE: équipements de protection individuelle sur chantier]"`;

/**
 * Extract image suggestion from response
 */
function extractImageSuggestion(response: string): { text: string; imageSuggestion: string | null } {
  const imageMatch = response.match(/\[IMAGE:\s*([^\]]+)\]/);
  const imageSuggestion = imageMatch ? imageMatch[1].trim() : null;
  
  // Remove image suggestion from text
  const text = response.replace(/\[IMAGE:[^\]]*\]/g, "").trim();
  
  return { text, imageSuggestion };
}

/**
 * Clean response by removing references, citations, and external links
 */
function cleanResponse(response: string): string {
  // Remove markdown-style citations like [1], [2], etc.
  let cleaned = response.replace(/\[\d+\]/g, "");

  // Remove URLs and links
  cleaned = cleaned.replace(/https?:\/\/[^\s)]+/g, "");

  // Remove markdown links like [text](url)
  cleaned = cleaned.replace(/\[([^\]]+)\]\([^\)]+\)/g, "$1");

  // Remove norm references in parentheses like (EN 361), (norme EN 364), (R.4323-58)
  cleaned = cleaned.replace(/\s*\((?:norme\s+)?(?:EN|NF|ISO|AFNOR|DTU|R\.\d+)[^)]*\)/gi, "");

  // Remove inline norm references like EN 361, ISO 12345, etc.
  cleaned = cleaned.replace(/\b(?:EN|NF|ISO|AFNOR|DTU|R\.\d+)\s+\d+(?:-\d+)?\b/g, "");

  // Remove excessive whitespace
  cleaned = cleaned.replace(/\s+/g, " ");

  // Remove leading/trailing whitespace
  cleaned = cleaned.trim();

  // Truncate to approximately 100 words if needed
  const words = cleaned.split(/\s+/);
  if (words.length > 120) {
    cleaned = words.slice(0, 120).join(" ") + "...";
  }

  return cleaned;
}

/**
 * Fetch image from Unsplash based on keywords
 */
async function fetchImageFromUnsplash(keywords: string): Promise<string | undefined> {
  try {
    const unsplashUrl = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(keywords)}&per_page=1&orientation=landscape`;
    
    const response = await fetch(unsplashUrl, {
      headers: {
        "Authorization": `Client-ID ${process.env.UNSPLASH_ACCESS_KEY || "demo"}`,
      },
    });

    if (!response.ok) {
      console.warn(`Unsplash API error: ${response.status}`);
      return undefined;
    }

    const data = await response.json() as { results: Array<{ urls: { regular: string } }> };
    
    if (!data.results || data.results.length === 0) {
      return undefined;
    }

    return data.results[0].urls.regular;
  } catch (error) {
    console.error("Error fetching image from Unsplash:", error);
    return undefined;
  }
}

/**
 * Ask Perplexity AI a BTP-specific question with image support
 * Secure server-side implementation
 */
export async function askPerplexityBTP(question: string): Promise<ChatResponse> {
  const apiKey = process.env.PERPLEXITY_API_KEY;

  if (!apiKey) {
    console.error("PERPLEXITY_API_KEY not configured");
    throw new Error(
      "Service de chatbot temporairement indisponible. Veuillez réessayer plus tard."
    );
  }

  // Validate question length
  if (!question || question.trim().length === 0) {
    throw new Error("La question ne peut pas être vide");
  }

  if (question.length > 5000) {
    throw new Error("La question est trop longue (maximum 5000 caractères)");
  }

  try {
    const response = await fetch(PERPLEXITY_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "sonar-pro",
        messages: [
          {
            role: "system",
            content: BTP_SYSTEM_PROMPT,
          },
          {
            role: "user",
            content: question,
          },
        ],
        max_tokens: 500,
        temperature: 0.7,
        top_p: 0.9,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error("Perplexity API Error:", errorData);

      if (response.status === 401) {
        throw new Error("Erreur d'authentification API. Clé API invalide.");
      } else if (response.status === 429) {
        throw new Error(
          "Trop de requêtes. Veuillez attendre quelques secondes avant de réessayer."
        );
      } else if (response.status === 500) {
        throw new Error("Erreur serveur Perplexity. Veuillez réessayer plus tard.");
      }

      throw new Error(`Erreur API: ${response.status} ${response.statusText}`);
    }

    const data: PerplexityResponse = await response.json();

    if (!data.choices || data.choices.length === 0) {
      throw new Error("Aucune réponse reçue de Perplexity");
    }

    const content = data.choices[0].message.content;

    if (!content) {
      throw new Error("Réponse vide reçue de Perplexity");
    }

    // Extract image suggestion and clean response
    const { text: cleanedContent, imageSuggestion } = extractImageSuggestion(content);
    const finalText = cleanResponse(cleanedContent);

    // Fetch image if suggestion exists
    let imageUrl: string | undefined = undefined;
    if (imageSuggestion) {
      const fetchedImage = await fetchImageFromUnsplash(imageSuggestion);
      if (fetchedImage) {
        imageUrl = fetchedImage;
      }
    }

    return {
      response: finalText,
      imageSuggestion,
      imageUrl,
    };
  } catch (error) {
    console.error("Erreur lors de l'appel Perplexity:", error);

    if (error instanceof Error) {
      throw error;
    }

    throw new Error("Une erreur inattendue s'est produite");
  }
}

/**
 * Call Perplexity API with conversation history and image support
 * Maintains context across multiple messages
 */
export async function callPerplexityWithHistory(
  userMessage: string,
  conversationHistory: PerplexityMessage[] = []
): Promise<ChatResponse> {
  const apiKey = process.env.PERPLEXITY_API_KEY;

  if (!apiKey) {
    console.error("PERPLEXITY_API_KEY not configured");
    throw new Error(
      "Service de chatbot temporairement indisponible. Veuillez réessayer plus tard."
    );
  }

  // Validate input
  if (!userMessage || userMessage.trim().length === 0) {
    throw new Error("Le message ne peut pas être vide");
  }

  if (userMessage.length > 5000) {
    throw new Error("Le message est trop long (maximum 5000 caractères)");
  }

  try {
    // Build messages array with system prompt and history
    const messages: PerplexityMessage[] = [
      {
        role: "system",
        content: BTP_SYSTEM_PROMPT,
      },
      ...conversationHistory.filter(
        (msg) => msg.role === "user" || msg.role === "assistant"
      ),
      {
        role: "user",
        content: userMessage,
      },
    ];

    const response = await fetch(PERPLEXITY_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "sonar-pro",
        messages: messages,
        max_tokens: 500,
        temperature: 0.7,
        top_p: 0.9,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error("Perplexity API Error:", errorData);

      if (response.status === 401) {
        throw new Error("Erreur d'authentification API");
      } else if (response.status === 429) {
        throw new Error("Trop de requêtes. Veuillez attendre avant de réessayer.");
      } else if (response.status === 500) {
        throw new Error("Erreur serveur Perplexity. Veuillez réessayer plus tard.");
      }

      throw new Error(`Erreur API: ${response.status}`);
    }

    const data: PerplexityResponse = await response.json();

    if (!data.choices || data.choices.length === 0) {
      throw new Error("Aucune réponse reçue");
    }

    const content = data.choices[0].message.content;

    if (!content) {
      throw new Error("Réponse vide reçue");
    }

    // Extract image suggestion and clean response
    const { text: cleanedContent, imageSuggestion } = extractImageSuggestion(content);
    const finalText = cleanResponse(cleanedContent);

    // Fetch image if suggestion exists
    let imageUrl: string | undefined = undefined;
    if (imageSuggestion) {
      const fetchedImage = await fetchImageFromUnsplash(imageSuggestion);
      if (fetchedImage) {
        imageUrl = fetchedImage;
      }
    }

    return {
      response: finalText,
      imageSuggestion,
      imageUrl,
    };
  } catch (error) {
    console.error("Erreur lors de l'appel Perplexity avec historique:", error);

    if (error instanceof Error) {
      throw error;
    }

    throw new Error("Une erreur inattendue s'est produite");
  }
}

/**
 * Format conversation history for API calls
 */
export function formatConversationHistory(
  messages: Array<{ role: string; content: string }>
): PerplexityMessage[] {
  return messages
    .filter((msg) => msg.role === "user" || msg.role === "assistant")
    .map((msg) => ({
      role: msg.role as "user" | "assistant",
      content: msg.content,
    }));
}

/**
 * Validate if a question is BTP-related
 * Quick client-side check before API call
 */
export function isBTPQuestion(question: string): boolean {
  const btpKeywords = [
    "btp",
    "bâtiment",
    "construction",
    "travaux publics",
    "dtu",
    "maçonnerie",
    "charpente",
    "couverture",
    "béton",
    "acier",
    "normes",
    "chantier",
    "sécurité",
    "prévention",
    "oppbtp",
    "inrs",
    "carsat",
    "ffb",
    "rt2020",
    "re2020",
    "devis",
    "estimation",
    "matériaux",
    "outils",
    "équipements",
    "hauteur",
    "échafaudage",
    "protection",
    "ppe",
    "epi",
    "garde-corps",
    "filet",
    "harnais",
  ];

  const lowerQuestion = question.toLowerCase();
  return btpKeywords.some((keyword) => lowerQuestion.includes(keyword));
}

