import { Router, Request, Response } from "express";
import { askPerplexityBTP, callPerplexityWithHistory, formatConversationHistory, ChatResponse } from "./perplexityClient";

const router = Router();

interface ChatRequest {
  message: string;
  context?: string;
  conversationHistory?: Array<{ role: string; content: string }>;
}

/**
 * POST /api/chat
 * Handle chat messages and return responses from Perplexity AI
 * All API calls are made server-side for security
 */
router.post("/api/chat", async (req: Request, res: Response) => {
  try {
    const { message, context, conversationHistory } = req.body as ChatRequest;

    if (!message || typeof message !== "string") {
      return res.status(400).json({
        error: "Invalid request: message is required and must be a string",
      });
    }

    // Trim message and check length
    const trimmedMessage = message.trim();
    if (trimmedMessage.length === 0) {
      return res.status(400).json({
        error: "Message cannot be empty",
      });
    }

    if (trimmedMessage.length > 5000) {
      return res.status(400).json({
        error: "Message is too long (max 5000 characters)",
      });
    }

    // Call Perplexity API
    let chatResponse: ChatResponse;

    try {
      // Use conversation history if available, otherwise simple query
      if (conversationHistory && conversationHistory.length > 0) {
        chatResponse = await callPerplexityWithHistory(
          trimmedMessage,
          formatConversationHistory(conversationHistory)
        );
      } else {
        chatResponse = await askPerplexityBTP(trimmedMessage);
      }
    } catch (apiError) {
      console.error("Perplexity API Error:", apiError);

      if (apiError instanceof Error) {
        return res.status(503).json({
          error: "Chat service error",
          message: apiError.message,
        });
      }

      return res.status(503).json({
        error: "Chat service error",
        message: "Une erreur s'est produite lors de la communication avec le service IA",
      });
    }

    return res.json({
      success: true,
      response: chatResponse.response,
      imageSuggestion: chatResponse.imageSuggestion,
      imageUrl: chatResponse.imageUrl,
      context: context || "BTP Questions",
    });
  } catch (error) {
    console.error("Chat endpoint error:", error);

    return res.status(500).json({
      error: "Internal server error",
      message:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred",
    });
  }
});

/**
 * GET /api/chat/health
 * Check if chat service is available
 */
router.get("/api/chat/health", (req: Request, res: Response) => {
  const hasApiKey = !!process.env.PERPLEXITY_API_KEY;

  return res.json({
    status: hasApiKey ? "ok" : "error",
    message: hasApiKey
      ? "Chat service is ready"
      : "Perplexity API key is not configured",
    service: "Perplexity AI - Questions BTP",
  });
});

export default router;

