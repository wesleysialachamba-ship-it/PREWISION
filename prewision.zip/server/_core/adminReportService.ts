/**
 * Admin Report Service
 * Generates and sends weekly reports to administrators
 */

import { sendEmail } from "./emailService";

export interface AdminReport {
  period: string;
  generatedAt: Date;
  stats: {
    totalUsers: number;
    newUsers: number;
    verifiedUsers: number;
    activeUsers: number;
    chatbotQuestions: number;
    articlesViewed: number;
    forumThreads: number;
    downloadsCount: number;
  };
  errors: {
    apiErrors: number;
    imageErrors: number;
    formErrors: number;
    databaseErrors: number;
  };
  performance: {
    pageSpeedScore: number;
    averageLoadTime: number;
    cacheHitRate: number;
  };
  topQuestions: Array<{
    question: string;
    count: number;
  }>;
  topArticles: Array<{
    title: string;
    views: number;
  }>;
}

/**
 * Generate weekly admin report
 */
export function generateAdminReport(data: any): AdminReport {
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  return {
    period: `${weekAgo.toLocaleDateString("fr-FR")} - ${now.toLocaleDateString("fr-FR")}`,
    generatedAt: now,
    stats: {
      totalUsers: data.totalUsers || 0,
      newUsers: data.newUsers || 0,
      verifiedUsers: data.verifiedUsers || 0,
      activeUsers: data.activeUsers || 0,
      chatbotQuestions: data.chatbotQuestions || 0,
      articlesViewed: data.articlesViewed || 0,
      forumThreads: data.forumThreads || 0,
      downloadsCount: data.downloadsCount || 0,
    },
    errors: {
      apiErrors: data.apiErrors || 0,
      imageErrors: data.imageErrors || 0,
      formErrors: data.formErrors || 0,
      databaseErrors: data.databaseErrors || 0,
    },
    performance: {
      pageSpeedScore: data.pageSpeedScore || 85,
      averageLoadTime: data.averageLoadTime || 1.2,
      cacheHitRate: data.cacheHitRate || 78,
    },
    topQuestions: data.topQuestions || [],
    topArticles: data.topArticles || [],
  };
}

/**
 * Send admin report via email
 */
export async function sendAdminReport(
  adminEmail: string,
  report: AdminReport
): Promise<boolean> {
  const html = generateAdminReportHTML(report);

  return sendEmail({
    to: adminEmail,
    subject: `Rapport Hebdomadaire PRÉVISION - ${report.period}`,
    html,
  });
}

/**
 * Generate HTML email template for admin report
 */
function generateAdminReportHTML(report: AdminReport): string {
  const totalErrors =
    report.errors.apiErrors +
    report.errors.imageErrors +
    report.errors.formErrors +
    report.errors.databaseErrors;

  return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          background-color: #f9f9f9;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          background-color: #ffffff;
          border-radius: 8px;
          overflow: hidden;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
          background: linear-gradient(135deg, #003D5C 0%, #1a5f7a 100%);
          color: white;
          padding: 30px;
          text-align: center;
        }
        .header h1 {
          margin: 0;
          font-size: 24px;
        }
        .header p {
          margin: 10px 0 0 0;
          opacity: 0.9;
        }
        .content {
          padding: 30px;
        }
        .section {
          margin-bottom: 30px;
        }
        .section h2 {
          color: #003D5C;
          border-bottom: 2px solid #FF7A00;
          padding-bottom: 10px;
          margin-bottom: 15px;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 15px;
          margin-bottom: 20px;
        }
        .stat-card {
          background-color: #f5f5f5;
          padding: 15px;
          border-left: 4px solid #FF7A00;
          border-radius: 4px;
        }
        .stat-card .label {
          font-size: 12px;
          color: #666;
          text-transform: uppercase;
        }
        .stat-card .value {
          font-size: 24px;
          font-weight: bold;
          color: #003D5C;
          margin-top: 5px;
        }
        .error-alert {
          background-color: #fee;
          border-left: 4px solid #d32f2f;
          padding: 15px;
          border-radius: 4px;
          margin-bottom: 15px;
        }
        .success-alert {
          background-color: #efe;
          border-left: 4px solid #388e3c;
          padding: 15px;
          border-radius: 4px;
          margin-bottom: 15px;
        }
        .top-list {
          background-color: #f5f5f5;
          padding: 15px;
          border-radius: 4px;
        }
        .top-list li {
          margin-bottom: 8px;
          padding-bottom: 8px;
          border-bottom: 1px solid #ddd;
        }
        .top-list li:last-child {
          border-bottom: none;
          margin-bottom: 0;
          padding-bottom: 0;
        }
        .footer {
          background-color: #f5f5f5;
          padding: 20px 30px;
          text-align: center;
          font-size: 12px;
          color: #666;
          border-top: 1px solid #ddd;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 15px;
        }
        table th {
          background-color: #003D5C;
          color: white;
          padding: 10px;
          text-align: left;
          font-weight: bold;
        }
        table td {
          padding: 10px;
          border-bottom: 1px solid #ddd;
        }
        table tr:nth-child(even) {
          background-color: #f9f9f9;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>📊 Rapport Hebdomadaire PRÉVISION</h1>
          <p>Période: ${report.period}</p>
        </div>

        <div class="content">
          <!-- User Statistics -->
          <div class="section">
            <h2>👥 Statistiques Utilisateurs</h2>
            <div class="stats-grid">
              <div class="stat-card">
                <div class="label">Total Utilisateurs</div>
                <div class="value">${report.stats.totalUsers}</div>
              </div>
              <div class="stat-card">
                <div class="label">Nouveaux Utilisateurs</div>
                <div class="value">+${report.stats.newUsers}</div>
              </div>
              <div class="stat-card">
                <div class="label">Utilisateurs Vérifiés</div>
                <div class="value">${report.stats.verifiedUsers}</div>
              </div>
              <div class="stat-card">
                <div class="label">Utilisateurs Actifs</div>
                <div class="value">${report.stats.activeUsers}</div>
              </div>
            </div>
          </div>

          <!-- Activity Statistics -->
          <div class="section">
            <h2>📈 Activité du Site</h2>
            <div class="stats-grid">
              <div class="stat-card">
                <div class="label">Questions Chatbot</div>
                <div class="value">${report.stats.chatbotQuestions}</div>
              </div>
              <div class="stat-card">
                <div class="label">Articles Consultés</div>
                <div class="value">${report.stats.articlesViewed}</div>
              </div>
              <div class="stat-card">
                <div class="label">Discussions Forum</div>
                <div class="value">${report.stats.forumThreads}</div>
              </div>
              <div class="stat-card">
                <div class="label">Téléchargements</div>
                <div class="value">${report.stats.downloadsCount}</div>
              </div>
            </div>
          </div>

          <!-- Errors Section -->
          <div class="section">
            <h2>⚠️ Erreurs Détectées</h2>
            ${
              totalErrors > 0
                ? `
              <div class="error-alert">
                <strong>Total Erreurs: ${totalErrors}</strong>
                <ul style="margin: 10px 0 0 0; padding-left: 20px;">
                  ${report.errors.apiErrors > 0 ? `<li>Erreurs API: ${report.errors.apiErrors}</li>` : ""}
                  ${report.errors.imageErrors > 0 ? `<li>Erreurs Images: ${report.errors.imageErrors}</li>` : ""}
                  ${report.errors.formErrors > 0 ? `<li>Erreurs Formulaires: ${report.errors.formErrors}</li>` : ""}
                  ${report.errors.databaseErrors > 0 ? `<li>Erreurs Base de Données: ${report.errors.databaseErrors}</li>` : ""}
                </ul>
              </div>
            `
                : `
              <div class="success-alert">
                <strong>✓ Aucune erreur détectée cette semaine!</strong>
              </div>
            `
            }
          </div>

          <!-- Performance -->
          <div class="section">
            <h2>⚡ Performance</h2>
            <table>
              <tr>
                <th>Métrique</th>
                <th>Valeur</th>
              </tr>
              <tr>
                <td>Score PageSpeed</td>
                <td>${report.performance.pageSpeedScore}/100</td>
              </tr>
              <tr>
                <td>Temps de chargement moyen</td>
                <td>${report.performance.averageLoadTime}s</td>
              </tr>
              <tr>
                <td>Taux de cache</td>
                <td>${report.performance.cacheHitRate}%</td>
              </tr>
            </table>
          </div>

          <!-- Top Questions -->
          ${
            report.topQuestions.length > 0
              ? `
            <div class="section">
              <h2>🔝 Questions Populaires</h2>
              <ol class="top-list">
                ${report.topQuestions
                  .slice(0, 5)
                  .map(
                    (q) =>
                      `<li><strong>${q.question}</strong> (${q.count} fois)</li>`
                  )
                  .join("")}
              </ol>
            </div>
          `
              : ""
          }

          <!-- Top Articles -->
          ${
            report.topArticles.length > 0
              ? `
            <div class="section">
              <h2>📰 Articles Populaires</h2>
              <ol class="top-list">
                ${report.topArticles
                  .slice(0, 5)
                  .map(
                    (a) =>
                      `<li><strong>${a.title}</strong> (${a.views} vues)</li>`
                  )
                  .join("")}
              </ol>
            </div>
          `
              : ""
          }

          <!-- Recommendations -->
          <div class="section">
            <h2>💡 Recommandations</h2>
            <ul style="padding-left: 20px;">
              <li>Continuez à monitorer les erreurs API</li>
              <li>Optimisez les images pour améliorer le PageSpeed</li>
              <li>Encouragez les utilisateurs à vérifier leur email</li>
              <li>Promouvoir les articles populaires</li>
            </ul>
          </div>
        </div>

        <div class="footer">
          <p>© 2025 PRÉVISION - Rapport généré automatiquement</p>
          <p>Pour plus d'informations, consultez le tableau de bord admin</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * Schedule weekly report generation
 */
export function scheduleWeeklyReport(adminEmail: string): void {
  // This would be called by a cron job or scheduler
  console.log(
    `[AdminReportService] Weekly report scheduled for ${adminEmail}`
  );
}

