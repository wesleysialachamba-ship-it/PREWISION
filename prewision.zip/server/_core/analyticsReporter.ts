/**
 * Analytics reporter for weekly email reports
 */

import { invokeLLM } from "./llm";

interface AnalyticsData {
  totalVisits: number;
  uniqueVisitors: number;
  pageViews: Record<string, number>;
  chatbotQuestions: number;
  articleViews: number;
  resourceDownloads: number;
  forumThreads: number;
  newsletterSignups: number;
  topPages: Array<{ page: string; views: number }>;
  topArticles: Array<{ title: string; views: number }>;
  chatbotTopics: Array<{ topic: string; count: number }>;
}

/**
 * Generate analytics report summary using LLM
 */
export async function generateAnalyticsReportSummary(
  data: AnalyticsData
): Promise<string> {
  const prompt = `
Génère un résumé professionnel d'un rapport d'analyse hebdomadaire pour un site BTP. 
Voici les données :

- Total des visites : ${data.totalVisits}
- Visiteurs uniques : ${data.uniqueVisitors}
- Vues de pages : ${data.pageViews}
- Questions du chatbot : ${data.chatbotQuestions}
- Vues d'articles : ${data.articleViews}
- Téléchargements de ressources : ${data.resourceDownloads}
- Discussions du forum : ${data.forumThreads}
- Inscriptions à la newsletter : ${data.newsletterSignups}

Pages les plus populaires :
${data.topPages.map((p) => `- ${p.page}: ${p.views} vues`).join("\n")}

Articles les plus consultés :
${data.topArticles.map((a) => `- ${a.title}: ${a.views} vues`).join("\n")}

Sujets du chatbot les plus fréquents :
${data.chatbotTopics.map((t) => `- ${t.topic}: ${t.count} questions`).join("\n")}

Crée un résumé court (150-200 mots) en français, professionnel, avec les insights clés et recommandations.
`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "Tu es un analyste de données expert en création de rapports professionnels.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    if (
      response.choices &&
      response.choices[0] &&
      response.choices[0].message &&
      response.choices[0].message.content
    ) {
      const content = response.choices[0].message.content;
      return typeof content === 'string' ? content : 'Rapport généré';
    }

    return "Impossible de générer le résumé du rapport.";
  } catch (error) {
    console.error("Error generating analytics report:", error);
    return "Erreur lors de la génération du rapport.";
  }
}

/**
 * Create HTML email template for analytics report
 */
export function createAnalyticsEmailTemplate(
  data: AnalyticsData,
  summary: string
): string {
  return `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #0066cc 0%, #0052a3 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
    .header h1 { margin: 0; font-size: 24px; }
    .header p { margin: 5px 0 0 0; font-size: 14px; opacity: 0.9; }
    .section { margin: 20px 0; padding: 15px; background: #f5f5f5; border-left: 4px solid #0066cc; border-radius: 4px; }
    .section h2 { margin-top: 0; color: #0066cc; font-size: 18px; }
    .metrics { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 15px 0; }
    .metric { background: white; padding: 15px; border-radius: 4px; text-align: center; }
    .metric-value { font-size: 28px; font-weight: bold; color: #0066cc; }
    .metric-label { font-size: 12px; color: #666; margin-top: 5px; }
    .top-list { list-style: none; padding: 0; margin: 10px 0; }
    .top-list li { padding: 8px; background: white; margin: 5px 0; border-radius: 4px; display: flex; justify-content: space-between; }
    .top-list strong { color: #0066cc; }
    .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
    .button { display: inline-block; background: #0066cc; color: white; padding: 10px 20px; border-radius: 4px; text-decoration: none; margin: 10px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>📊 Rapport Hebdomadaire PREWISION</h1>
      <p>Analyse de votre site de prévention BTP</p>
    </div>

    <div class="section">
      <h2>📈 Résumé Exécutif</h2>
      <p>${summary}</p>
    </div>

    <div class="section">
      <h2>📊 Statistiques Principales</h2>
      <div class="metrics">
        <div class="metric">
          <div class="metric-value">${data.totalVisits.toLocaleString("fr-FR")}</div>
          <div class="metric-label">Visites totales</div>
        </div>
        <div class="metric">
          <div class="metric-value">${data.uniqueVisitors.toLocaleString("fr-FR")}</div>
          <div class="metric-label">Visiteurs uniques</div>
        </div>
        <div class="metric">
          <div class="metric-value">${data.chatbotQuestions}</div>
          <div class="metric-label">Questions chatbot</div>
        </div>
        <div class="metric">
          <div class="metric-value">${data.resourceDownloads}</div>
          <div class="metric-label">Ressources téléchargées</div>
        </div>
      </div>
    </div>

    <div class="section">
      <h2>🔝 Pages les Plus Populaires</h2>
      <ul class="top-list">
        ${data.topPages
          .slice(0, 5)
          .map(
            (p) =>
              `<li><strong>${p.page}</strong> <span>${p.views} vues</span></li>`
          )
          .join("")}
      </ul>
    </div>

    <div class="section">
      <h2>📰 Articles les Plus Consultés</h2>
      <ul class="top-list">
        ${data.topArticles
          .slice(0, 5)
          .map(
            (a) =>
              `<li><strong>${a.title}</strong> <span>${a.views} vues</span></li>`
          )
          .join("")}
      </ul>
    </div>

    <div class="section">
      <h2>💬 Sujets du Chatbot les Plus Fréquents</h2>
      <ul class="top-list">
        ${data.chatbotTopics
          .slice(0, 5)
          .map(
            (t) =>
              `<li><strong>${t.topic}</strong> <span>${t.count} questions</span></li>`
          )
          .join("")}
      </ul>
    </div>

    <div class="section">
      <h2>📋 Engagement Communautaire</h2>
      <ul class="top-list">
        <li><strong>Discussions du forum</strong> <span>${data.forumThreads}</span></li>
        <li><strong>Inscriptions newsletter</strong> <span>${data.newsletterSignups}</span></li>
      </ul>
    </div>

    <div class="footer">
      <p>Rapport généré automatiquement par PREWISION</p>
      <p>© 2025 PREWISION - Tous droits réservés</p>
    </div>
  </div>
</body>
</html>
  `;
}

/**
 * Create mock analytics data for testing
 */
export function createMockAnalyticsData(): AnalyticsData {
  return {
    totalVisits: 1250,
    uniqueVisitors: 850,
    pageViews: {
      "/": 450,
      "/blog": 280,
      "/chat": 320,
      "/resources": 200,
    },
    chatbotQuestions: 320,
    articleViews: 280,
    resourceDownloads: 95,
    forumThreads: 12,
    newsletterSignups: 45,
    topPages: [
      { page: "Accueil", views: 450 },
      { page: "Chatbot Questions BTP", views: 320 },
      { page: "Blog Actualités", views: 280 },
      { page: "Ressources", views: 200 },
    ],
    topArticles: [
      { title: "Normes de sécurité pour travaux en hauteur", views: 85 },
      { title: "Prévention des risques électriques", views: 72 },
      { title: "Guide complet des EPI", views: 68 },
      { title: "Sécurité sur les chantiers", views: 55 },
    ],
    chatbotTopics: [
      { topic: "Travaux en hauteur", count: 85 },
      { topic: "EPI et équipements", count: 72 },
      { topic: "Normes DTU", count: 68 },
      { topic: "Prévention des risques", count: 55 },
      { topic: "Formations obligatoires", count: 40 },
    ],
  };
}

