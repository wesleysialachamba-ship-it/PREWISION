/**
 * Email Service using SendGrid
 * Handles newsletter emails and transactional emails
 */

import sgMail from "@sendgrid/mail";

// Initialize SendGrid with API key
const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL || "noreply@prewision.fr";
const FROM_NAME = "PREWISION";

if (SENDGRID_API_KEY) {
  sgMail.setApiKey(SENDGRID_API_KEY);
}

export interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  replyTo?: string;
}

export interface NewsletterEmailData {
  subscriberEmail: string;
  subscriberName?: string;
  articles: Array<{
    id: number;
    title: string;
    summary: string;
    originalUrl: string;
    category: string;
  }>;
  unsubscribeToken: string;
}

/**
 * Send a generic email
 */
export async function sendEmail(options: EmailOptions): Promise<boolean> {
  if (!SENDGRID_API_KEY) {
    console.warn("[EmailService] SendGrid API key not configured");
    return false;
  }

  try {
    const msg = {
      to: options.to,
      from: {
        email: FROM_EMAIL,
        name: FROM_NAME,
      },
      subject: options.subject,
      html: options.html,
      replyTo: options.replyTo || FROM_EMAIL,
    };

    await sgMail.send(msg);
    console.log(`[EmailService] Email sent to ${options.to}`);
    return true;
  } catch (error) {
    console.error("[EmailService] Error sending email:", error);
    return false;
  }
}

/**
 * Send newsletter email
 */
export async function sendNewsletterEmail(
  data: NewsletterEmailData
): Promise<boolean> {
  const html = generateNewsletterHTML(data);

  return sendEmail({
    to: data.subscriberEmail,
    subject: "PREWISION - Actualités Sécurité BTP de la semaine",
    html,
  });
}

/**
 * Generate newsletter HTML template
 */
function generateNewsletterHTML(data: NewsletterEmailData): string {
  const articlesHTML = data.articles
    .map(
      (article) => `
    <div style="margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #e0e0e0;">
      <h3 style="margin: 0 0 10px 0; color: #1e40af; font-size: 18px; font-weight: 600;">
        ${escapeHtml(article.title)}
      </h3>
      <p style="margin: 0 0 5px 0; color: #666; font-size: 13px;">
        <span style="background-color: #f0f0f0; padding: 2px 8px; border-radius: 3px;">
          ${escapeHtml(article.category)}
        </span>
      </p>
      <p style="margin: 10px 0; color: #333; line-height: 1.6; font-size: 14px;">
        ${escapeHtml(article.summary.substring(0, 200))}...
      </p>
      <a href="${article.originalUrl}" style="color: #1e40af; text-decoration: none; font-weight: 500;">
        Lire l'article complet →
      </a>
    </div>
  `
    )
    .join("");

  const unsubscribeLink = `${process.env.VITE_APP_URL || "https://prewision.fr"}/newsletter/unsubscribe?token=${data.unsubscribeToken}`;

  return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          background-color: #f9f9f9;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          background-color: #ffffff;
          border-radius: 8px;
          overflow: hidden;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
          background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
          color: white;
          padding: 40px 20px;
          text-align: center;
        }
        .header h1 {
          margin: 0;
          font-size: 28px;
          font-weight: 700;
        }
        .header p {
          margin: 10px 0 0 0;
          font-size: 14px;
          opacity: 0.9;
        }
        .content {
          padding: 40px 30px;
        }
        .greeting {
          margin-bottom: 30px;
          font-size: 16px;
        }
        .articles {
          margin: 30px 0;
        }
        .cta-button {
          display: inline-block;
          background-color: #2563eb;
          color: white;
          padding: 12px 30px;
          text-decoration: none;
          border-radius: 5px;
          font-weight: 600;
          margin-top: 20px;
        }
        .footer {
          background-color: #f5f5f5;
          padding: 20px 30px;
          text-align: center;
          font-size: 12px;
          color: #666;
          border-top: 1px solid #e0e0e0;
        }
        .footer a {
          color: #2563eb;
          text-decoration: none;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>PREWISION</h1>
          <p>Actualités Sécurité et Santé BTP</p>
        </div>

        <div class="content">
          <div class="greeting">
            <p>Bonjour${data.subscriberName ? ` ${escapeHtml(data.subscriberName)}` : ""},</p>
            <p>Découvrez les ${data.articles.length} dernières actualités de la semaine sur la sécurité et la santé au travail dans le BTP.</p>
          </div>

          <div class="articles">
            ${articlesHTML}
          </div>

          <div style="text-align: center; margin-top: 30px;">
            <a href="${process.env.VITE_APP_URL || "https://prewision.fr"}/chat" class="cta-button">
              Poser une question à notre chatbot
            </a>
          </div>
        </div>

        <div class="footer">
          <p>
            Vous recevez cet email car vous êtes abonné à la newsletter PREWISION.<br>
            <a href="${unsubscribeLink}">Se désabonner</a>
          </p>
          <p style="margin-top: 15px; color: #999;">
            © 2025 PREWISION. Tous droits réservés.
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * Escape HTML special characters
 */
function escapeHtml(text: string): string {
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  };
  return text.replace(/[&<>"']/g, (char) => map[char]);
}

/**
 * Generate email verification token
 */
export function generateEmailVerificationToken(): string {
  const crypto = require("crypto");
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Create email verification URL
 */
export function createVerificationUrl(
  token: string,
  baseUrl: string = "https://prewision.example.com"
): string {
  return `${baseUrl}/verify-email?token=${token}`;
}

/**
 * Send email confirmation
 */
export async function sendConfirmationEmail(data: {
  email: string;
  token: string;
  verificationUrl: string;
  name: string;
  accountType: "personal" | "professional";
}): Promise<boolean> {
  const accountTypeLabel =
    data.accountType === "professional" ? "Professionnel" : "Personnel";

  const html = `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #f9f9f9;
        }
        .header {
          background: linear-gradient(135deg, #003D5C 0%, #1a5f7a 100%);
          color: white;
          padding: 30px;
          text-align: center;
          border-radius: 8px 8px 0 0;
        }
        .content {
          background: white;
          padding: 30px;
          border-radius: 0 0 8px 8px;
        }
        .button {
          display: inline-block;
          background-color: #FF7A00;
          color: white;
          padding: 12px 30px;
          text-decoration: none;
          border-radius: 5px;
          margin: 20px 0;
          font-weight: bold;
        }
        .footer {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #eee;
          font-size: 12px;
          color: #666;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>PRÉVISION</h1>
          <p>Sécurité et Santé au Travail BTP</p>
        </div>
        <div class="content">
          <h2>Bienvenue ${escapeHtml(data.name)} !</h2>
          <p>Merci de vous être inscrit sur PRÉVISION en tant que compte <strong>${accountTypeLabel}</strong>.</p>
          
          <p>Pour confirmer votre adresse email et activer votre compte, veuillez cliquer sur le bouton ci-dessous :</p>
          
          <a href="${data.verificationUrl}" class="button">Confirmer mon email</a>
          
          <p>Ou copiez ce lien dans votre navigateur :</p>
          <p style="word-break: break-all; background: #f5f5f5; padding: 10px; border-radius: 5px;">
            ${data.verificationUrl}
          </p>
          
          <p>Ce lien expire dans 24 heures.</p>
          
          <p>Si vous n'avez pas créé ce compte, veuillez ignorer cet email.</p>
          
          <div class="footer">
            <p>© 2025 PRÉVISION - Tous droits réservés</p>
            <p>Cet email a été envoyé à ${data.email}</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  return sendEmail({
    to: data.email,
    subject: "Confirmez votre adresse email - PRÉVISION",
    html,
  });
}

/**
 * Send test email
 */
export async function sendTestEmail(toEmail: string): Promise<boolean> {
  const html = `
    <html>
      <body style="font-family: Arial, sans-serif;">
        <h1>Test Email from PREWISION</h1>
        <p>This is a test email to verify SendGrid configuration.</p>
        <p>If you received this email, the email service is working correctly.</p>
      </body>
    </html>
  `;

  return sendEmail({
    to: toEmail,
    subject: "Test Email - PREWISION",
    html,
  });
}

