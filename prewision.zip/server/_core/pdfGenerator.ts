/**
 * PDF Generator for BTP Resources
 * Creates professional PDF documents with BTP safety content
 */

import { PDFDocument, PDFPage, rgb } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";

export interface PDFOptions {
  title: string;
  author?: string;
  subject?: string;
  content: string[];
}

/**
 * Generate a professional PDF document
 */
export async function generatePDF(options: PDFOptions): Promise<Buffer> {
  const pdfDoc = await PDFDocument.create();

  // Register font
  pdfDoc.registerFontkit(fontkit);

  // Add metadata
  pdfDoc.setTitle(options.title);
  pdfDoc.setAuthor(options.author || "PREWISION");
  pdfDoc.setSubject(options.subject || "BTP Safety Resources");

  // Create first page with title
  let page = pdfDoc.addPage([595, 842]); // A4 size
  const { width, height } = page.getSize();

  // Add header
  page.drawRectangle({
    x: 0,
    y: height - 100,
    width: width,
    height: 100,
    color: rgb(0.15, 0.4, 0.93), // Blue color
  });

  page.drawText(options.title, {
    x: 40,
    y: height - 50,
    size: 28,
    color: rgb(1, 1, 1),
    maxWidth: width - 80,
  });

  // Add content
  let yPosition = height - 130;
  const lineHeight = 20;
  const pageMargin = 40;
  const maxWidth = width - 2 * pageMargin;

  for (const section of options.content) {
    const lines = wrapText(section, maxWidth, 11);

    for (const line of lines) {
      if (yPosition < 50) {
        // Create new page if needed
        page = pdfDoc.addPage([595, 842]);
        yPosition = height - pageMargin;
      }

      page.drawText(line, {
        x: pageMargin,
        y: yPosition,
        size: 11,
        color: rgb(0.2, 0.2, 0.2),
        maxWidth: maxWidth,
      });

      yPosition -= lineHeight;
    }

    // Add spacing between sections
    yPosition -= 10;
  }

  // Add footer
  const pages = pdfDoc.getPages();
  pages.forEach((page: PDFPage, index: number) => {
    page.drawText(`Page ${index + 1} / ${pages.length}`, {
      x: width - 100,
      y: 20,
      size: 10,
      color: rgb(0.5, 0.5, 0.5),
    });

    page.drawText("© 2025 PREWISION - Actualités Sécurité BTP", {
      x: 40,
      y: 20,
      size: 10,
      color: rgb(0.5, 0.5, 0.5),
    });
  });

  // Save to buffer
  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}

/**
 * Wrap text to fit within a specific width
 */
function wrapText(text: string, maxWidth: number, fontSize: number): string[] {
  const words = text.split(" ");
  const lines: string[] = [];
  let currentLine = "";

  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const estimatedWidth = testLine.length * (fontSize * 0.5); // Rough estimate

    if (estimatedWidth > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }

  if (currentLine) {
    lines.push(currentLine);
  }

  return lines;
}

/**
 * Generate Checklist Sécurité Chantier PDF
 */
export async function generateChecklistPDF(): Promise<Buffer> {
  const content = [
    "CHECKLIST SÉCURITÉ CHANTIER",
    "",
    "Cette checklist vous aide à vérifier les éléments essentiels de sécurité sur votre chantier.",
    "",
    "AVANT LE DÉBUT DES TRAVAUX",
    "☐ Tous les travailleurs ont reçu une formation de sécurité",
    "☐ Les équipements de protection individuelle (EPI) sont disponibles et en bon état",
    "☐ Les zones dangereuses sont délimitées et signalées",
    "☐ Un responsable sécurité est désigné",
    "☐ Un plan d'évacuation d'urgence est affiché",
    "☐ Les équipements de premiers secours sont présents",
    "",
    "PENDANT LES TRAVAUX",
    "☐ Tous les travailleurs portent les EPI appropriés",
    "☐ Les distances de sécurité sont respectées",
    "☐ Les équipements sont utilisés correctement",
    "☐ Les zones de travail sont maintenues propres et organisées",
    "☐ Les risques électriques sont maîtrisés",
    "☐ Les travaux en hauteur utilisent des protections appropriées",
    "☐ Les substances dangereuses sont correctement stockées et étiquetées",
    "",
    "ÉQUIPEMENTS DE PROTECTION INDIVIDUELLE (EPI)",
    "Les EPI obligatoires incluent:",
    "• Casque de sécurité",
    "• Chaussures de sécurité avec semelle antidérapante",
    "• Gilet de visibilité",
    "• Gants de protection appropriés à la tâche",
    "• Lunettes de sécurité si risque de projection",
    "• Masque respiratoire si exposition à poussières ou vapeurs",
    "• Harnais de sécurité pour les travaux en hauteur",
    "",
    "TRAVAUX EN HAUTEUR",
    "Pour les travaux à plus de 2 mètres:",
    "• Utiliser un harnais de sécurité avec longe",
    "• Installer des garde-corps ou filets de sécurité",
    "• Assurer une surveillance constante",
    "• Vérifier régulièrement l'équipement",
    "",
    "INCIDENTS ET ACCIDENTS",
    "En cas d'incident:",
    "• Arrêter immédiatement les travaux",
    "• Alerter les services d'urgence si nécessaire",
    "• Documenter l'incident",
    "• Enquêter sur les causes",
    "• Mettre en place des mesures correctives",
    "",
    "CONTACTS D'URGENCE",
    "SAMU: 15",
    "Pompiers: 18",
    "Police: 17",
    "Responsable sécurité: [À compléter]",
    "Médecin du travail: [À compléter]",
  ];

  return generatePDF({
    title: "Checklist Sécurité Chantier",
    subject: "Guide de vérification de sécurité pour les chantiers BTP",
    content,
  });
}

/**
 * Generate Guide EPI PDF
 */
export async function generateEPIGuidePDF(): Promise<Buffer> {
  const content = [
    "GUIDE COMPLET DES ÉQUIPEMENTS DE PROTECTION INDIVIDUELLE (EPI)",
    "",
    "Les Équipements de Protection Individuelle sont essentiels pour protéger les travailleurs des risques sur les chantiers.",
    "",
    "1. PROTECTION DE LA TÊTE",
    "",
    "Casque de sécurité",
    "• Obligatoire sur tous les chantiers",
    "• Doit être conforme aux normes en vigueur",
    "• À remplacer après un choc important",
    "• Vérifier régulièrement l'état du casque",
    "• Durée de vie: environ 3 ans",
    "",
    "2. PROTECTION DES PIEDS",
    "",
    "Chaussures de sécurité",
    "• Semelle antidérapante obligatoire",
    "• Embout de protection pour les risques de chute d'objets",
    "• Semelle anti-perforation pour les risques de piqûre",
    "• Choisir la taille appropriée pour un confort optimal",
    "• Vérifier l'état régulièrement",
    "",
    "3. PROTECTION DES MAINS",
    "",
    "Gants de protection",
    "• Adapter le type de gant au risque (chimique, thermique, mécanique)",
    "• Vérifier qu'ils ne sont pas endommagés",
    "• Remplacer régulièrement",
    "• Assurer une bonne dextérité pour les tâches précises",
    "",
    "4. PROTECTION DES YEUX",
    "",
    "Lunettes de sécurité",
    "• Obligatoires lors de risques de projection",
    "• Assurer une bonne visibilité",
    "• Nettoyer régulièrement les verres",
    "• Remplacer en cas de rayures ou dommages",
    "",
    "5. PROTECTION RESPIRATOIRE",
    "",
    "Masques et respirateurs",
    "• Masque chirurgical pour les poussières générales",
    "• Respirateur FFP2 pour les poussières fines",
    "• Respirateur avec cartouche pour les vapeurs chimiques",
    "• Assurer un bon ajustement au visage",
    "• Remplacer selon les recommandations du fabricant",
    "",
    "6. PROTECTION AUDITIVE",
    "",
    "Bouchons et casques antibruit",
    "• Obligatoires en environnement bruyant (>85 dB)",
    "• Assurer une bonne insertion des bouchons",
    "• Vérifier l'efficacité de l'atténuation",
    "• Remplacer les bouchons régulièrement",
    "",
    "7. PROTECTION DU CORPS",
    "",
    "Gilets et vêtements de sécurité",
    "• Gilet de visibilité obligatoire sur les chantiers",
    "• Vêtements ignifugés pour les risques thermiques",
    "• Tabliers de protection pour les risques chimiques",
    "",
    "8. PROTECTION CONTRE LES CHUTES",
    "",
    "Harnais et équipements anti-chute",
    "• Obligatoires pour les travaux en hauteur (>2m)",
    "• Vérifier l'intégrité du harnais régulièrement",
    "• Assurer une formation correcte à l'utilisation",
    "• Utiliser avec des points d'ancrage sécurisés",
    "• Remplacer après un choc important",
    "",
    "MAINTENANCE DES EPI",
    "• Inspecter régulièrement tous les EPI",
    "• Nettoyer selon les instructions du fabricant",
    "• Stocker dans un endroit sec et protégé",
    "• Remplacer les EPI endommagés immédiatement",
    "• Tenir un registre de maintenance",
    "",
    "FORMATION ET SENSIBILISATION",
    "Tous les travailleurs doivent:",
    "• Recevoir une formation sur l'utilisation des EPI",
    "• Comprendre les risques spécifiques à leur poste",
    "• Savoir comment inspecter leurs EPI",
    "• Signaler tout EPI endommagé",
    "• Participer à des rappels de sécurité réguliers",
  ];

  return generatePDF({
    title: "Guide Complet des Équipements de Protection Individuelle",
    subject: "Guide EPI pour les professionnels du BTP",
    content,
  });
}

/**
 * Generate Normes Travaux Hauteur PDF
 */
export async function generateHeightWorksPDF(): Promise<Buffer> {
  const content = [
    "NORMES DE SÉCURITÉ POUR LES TRAVAUX EN HAUTEUR",
    "",
    "Les travaux en hauteur représentent l'un des risques majeurs dans le BTP. Ce guide présente les normes essentielles.",
    "",
    "DÉFINITION ET SEUILS",
    "",
    "Un travail en hauteur est défini comme un travail effectué à plus de 2 mètres du sol ou d'une surface stable.",
    "",
    "ÉVALUATION DES RISQUES",
    "Avant tout travail en hauteur, une évaluation des risques doit être effectuée:",
    "• Hauteur de chute potentielle",
    "• Nature du sol ou de la surface",
    "• Conditions météorologiques",
    "• Présence d'obstacles",
    "• Charge de travail",
    "• Expérience du travailleur",
    "",
    "ÉQUIPEMENTS OBLIGATOIRES",
    "",
    "Harnais de sécurité",
    "• Doit être conforme aux normes en vigueur",
    "• Doit être inspecté avant chaque utilisation",
    "• Doit être ajusté correctement au travailleur",
    "• Durée de vie: 5 à 10 ans selon le modèle",
    "",
    "Longe de sécurité",
    "• Doit être reliée à un point d'ancrage sécurisé",
    "• Longueur maximale: 2 mètres",
    "• Doit avoir un absorbeur d'énergie",
    "• Inspection régulière obligatoire",
    "",
    "Points d'ancrage",
    "• Doivent supporter au minimum 10 kN de force",
    "• Doivent être situés au-dessus du point de travail",
    "• Doivent être stables et permanents",
    "• Doivent être inspectés avant utilisation",
    "",
    "PROTECTIONS COLLECTIVES",
    "",
    "Garde-corps",
    "• Hauteur minimale: 1,1 mètre",
    "• Capable de supporter une charge de 1,2 kN",
    "• À installer sur tous les rebords et ouvertures",
    "",
    "Filets de sécurité",
    "• Maille maximale: 100 mm x 100 mm",
    "• À installer sous les zones de travail",
    "• À inspecter régulièrement",
    "",
    "Écrans de protection",
    "• À utiliser pour les risques de chute d'objets",
    "• À installer entre les zones de travail et les zones de passage",
    "",
    "PROCÉDURES DE SÉCURITÉ",
    "",
    "Avant le travail",
    "• Vérifier la météo",
    "• Inspecter tous les équipements",
    "• Vérifier les points d'ancrage",
    "• Mettre en place les protections collectives",
    "• Informer les autres travailleurs",
    "",
    "Pendant le travail",
    "• Rester attaché en permanence",
    "• Ne pas modifier les équipements",
    "• Maintenir une bonne position de travail",
    "• Surveiller les conditions",
    "• Signaler tout problème immédiatement",
    "",
    "Après le travail",
    "• Inspecter les équipements",
    "• Documenter tout incident",
    "• Stocker correctement les équipements",
    "• Nettoyer et entretenir",
    "",
    "FORMATION OBLIGATOIRE",
    "Tous les travailleurs effectuant des travaux en hauteur doivent:",
    "• Recevoir une formation spécifique",
    "• Démontrer leur compétence",
    "• Participer à des recyclages réguliers",
    "• Comprendre les risques spécifiques",
    "• Savoir utiliser correctement les équipements",
    "",
    "RESPONSABILITÉS DE L'EMPLOYEUR",
    "• Fournir les équipements appropriés",
    "• Assurer la formation des travailleurs",
    "• Inspecter régulièrement les équipements",
    "• Maintenir un environnement sécurisé",
    "• Documenter les incidents",
    "• Mettre en place un plan de sauvetage",
  ];

  return generatePDF({
    title: "Normes de Sécurité pour les Travaux en Hauteur",
    subject: "Guide des normes de sécurité pour les travaux en hauteur",
    content,
  });
}

