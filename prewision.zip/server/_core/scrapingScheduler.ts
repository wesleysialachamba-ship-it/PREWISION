/**
 * Automated Article Scraping Scheduler
 * Runs on a schedule to fetch and summarize articles from BTP sources
 */

import { ARTICLE_SOURCES, scrapeArticlesFromSource, summarizeArticle, categorizeArticle } from "./articleScraper";
import { addBlogArticle, articleExists, createOrUpdateScrapingJob } from "../blogDb";

export interface ScrapingResult {
  sourceName: string;
  articlesFound: number;
  articlesAdded: number;
  errors: string[];
}

/**
 * Run the scraping job for all sources
 */
export async function runScrapingJob(): Promise<ScrapingResult[]> {
  console.log("[ScrapingScheduler] Starting automated scraping job...");

  const results: ScrapingResult[] = [];
  const startTime = new Date();

  for (const source of ARTICLE_SOURCES) {
    const result: ScrapingResult = {
      sourceName: source.name,
      articlesFound: 0,
      articlesAdded: 0,
      errors: [],
    };

    try {
      console.log(`[ScrapingScheduler] Processing ${source.name}...`);

      // Update job status to running
      await createOrUpdateScrapingJob({
        sourceUrl: source.url,
        sourceName: source.name,
        status: "running",
        isActive: true,
      });

      // Scrape articles
      const scrapedArticles = await scrapeArticlesFromSource(source);
      result.articlesFound = scrapedArticles.length;

      // Process each article
      for (const article of scrapedArticles) {
        try {
          // Check if article already exists
          const exists = await articleExists(article.url);
          if (exists) {
            console.log(
              `[ScrapingScheduler] Article already exists: ${article.title}`
            );
            continue;
          }

          // Summarize article
          console.log(
            `[ScrapingScheduler] Summarizing: ${article.title.substring(0, 50)}...`
          );
          const summary = await summarizeArticle(article);

          // Categorize article
          const category = categorizeArticle(article);

          // Add to database
          const blogArticle = await addBlogArticle({
            title: article.title,
            summary,
            originalUrl: article.url,
            sourceWebsite: article.source.url,
            sourceTitle: article.source.name,
            category,
            imageUrl: article.imageUrl,
            originalPublishedAt: article.publishedDate,
            isActive: true,
          });

          if (blogArticle) {
            result.articlesAdded++;
            console.log(
              `[ScrapingScheduler] Added article: ${article.title.substring(0, 50)}...`
            );
          }

          // Rate limiting - wait 2 seconds between API calls
          await new Promise((resolve) => setTimeout(resolve, 2000));
        } catch (error) {
          const errorMsg = `Failed to process article: ${article.title}`;
          console.error(`[ScrapingScheduler] ${errorMsg}`, error);
          result.errors.push(errorMsg);
        }
      }

      // Update job status to completed
      await createOrUpdateScrapingJob({
        sourceUrl: source.url,
        sourceName: source.name,
        lastScrapedAt: new Date(),
        nextScrapedAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        articlesFound: result.articlesFound,
        articlesAdded: result.articlesAdded,
        status: "completed",
        isActive: true,
      });

      results.push(result);
    } catch (error) {
      const errorMsg = String(error);
      console.error(
        `[ScrapingScheduler] Error processing ${source.name}:`,
        error
      );

      result.errors.push(errorMsg);

      // Update job status to failed
      await createOrUpdateScrapingJob({
        sourceUrl: source.url,
        sourceName: source.name,
        lastScrapedAt: new Date(),
        status: "failed",
        errorMessage: errorMsg,
        isActive: true,
      });

      results.push(result);
    }
  }

  const endTime = new Date();
  const duration = (endTime.getTime() - startTime.getTime()) / 1000;

  console.log(
    `[ScrapingScheduler] Scraping job completed in ${duration}s. Results:`,
    results
  );

  return results;
}

/**
 * Manual trigger for scraping (for admin panel)
 */
export async function triggerManualScraping(): Promise<ScrapingResult[]> {
  console.log("[ScrapingScheduler] Manual scraping triggered by admin");
  return runScrapingJob();
}

/**
 * Get scraping job summary
 */
export async function getScrapingSummary(): Promise<{
  totalArticles: number;
  totalSources: number;
  lastRun?: Date;
  nextRun?: Date;
}> {
  const { getScrapingJobs } = await import("../blogDb");

  const jobs = await getScrapingJobs(true);

  return {
    totalArticles: jobs.reduce((sum, job) => sum + job.articlesAdded, 0),
    totalSources: jobs.length,
    lastRun: jobs.length > 0 ? jobs[0].lastScrapedAt || undefined : undefined,
    nextRun: jobs.length > 0 ? jobs[0].nextScrapedAt || undefined : undefined,
  };
}

