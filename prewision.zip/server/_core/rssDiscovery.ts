/**
 * RSS Discovery Service - Discovers new BTP security/health websites with RSS feeds
 */

import { invokeLLM } from "./llm";

interface DiscoveredSource {
  name: string;
  description: string;
  websiteUrl: string;
  rssUrl?: string;
  category: string;
  relevanceScore: number;
}

/**
 * Discover new BTP security/health websites using LLM
 */
export async function discoverNewBtpSources(): Promise<DiscoveredSource[]> {
  const prompt = `
Tu es un expert en recherche de sources d'information sur la sécurité et la santé au travail dans le BTP en France.

Découvre et suggère 5-10 nouveaux sites web ou organisations (autres que OPPBTP, PreventionBTP, INRS, FFB, CARSAT, IRIS-ST, Officiel Prevention) qui publient des actualités, guides ou ressources sur :
- Sécurité sur les chantiers
- Santé au travail dans le BTP
- Prévention des risques
- Normes et régulations BTP
- Formations obligatoires

Pour chaque site, fournis :
1. Nom du site/organisation
2. Description (1-2 lignes)
3. URL du site web
4. URL du flux RSS (si disponible, sinon laisse vide)
5. Catégorie (Sécurité, Santé, Prévention, Normes, Formation, etc.)
6. Score de pertinence (0-100)

Format ta réponse en JSON valide avec cette structure :
[
  {
    "name": "Nom du site",
    "description": "Description courte",
    "websiteUrl": "https://...",
    "rssUrl": "https://...rss ou vide",
    "category": "Catégorie",
    "relevanceScore": 85
  }
]

Assure-toi que les sites sont pertinents pour le secteur BTP français et qu'ils publient régulièrement du contenu.
`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "Tu es un expert en recherche d'information et tu fournis des réponses en JSON valide.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    if (
      response.choices &&
      response.choices[0] &&
      response.choices[0].message &&
      response.choices[0].message.content
    ) {
      const content = response.choices[0].message.content;
      const contentStr = typeof content === "string" ? content : "";

      // Extract JSON from response
      const jsonMatch = contentStr.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        try {
          const sources = JSON.parse(jsonMatch[0]) as DiscoveredSource[];
          return sources.filter((s) => s.websiteUrl && s.name);
        } catch (e) {
          console.error("Failed to parse JSON response:", e);
          return [];
        }
      }
    }

    return [];
  } catch (error) {
    console.error("Error discovering new BTP sources:", error);
    return [];
  }
}

/**
 * Verify RSS feed availability
 */
export async function verifyRssFeed(rssUrl: string): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch(rssUrl, {
      method: "HEAD",
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);
    return response.ok;
  } catch (error) {
    console.error(`Failed to verify RSS feed ${rssUrl}:`, error);
    return false;
  }
}

/**
 * Generate admin notification about new sources
 */
export function generateAdminNotification(
  sources: DiscoveredSource[]
): string {
  return `
📰 **Nouvelles sources BTP découvertes**

${sources.length} nouvelles sources potentielles ont été découvertes lors de la vérification mensuelle :

${sources
  .map(
    (s) => `
**${s.name}** (Score: ${s.relevanceScore}/100)
- Catégorie: ${s.category}
- Description: ${s.description}
- Site: ${s.websiteUrl}
- RSS: ${s.rssUrl || "Non disponible"}
`
  )
  .join("\n")}

Accédez au dashboard admin pour approuver ou rejeter ces suggestions.
  `;
}

/**
 * Create mock discovered sources for testing
 */
export function createMockDiscoveredSources(): DiscoveredSource[] {
  return [
    {
      name: "CNAMTS - Actualités Santé Travail",
      description:
        "Caisse Nationale de l'Assurance Maladie - Actualités et ressources sur la santé au travail",
      websiteUrl: "https://www.cnamts.fr",
      rssUrl: "https://www.cnamts.fr/actualites/rss",
      category: "Santé",
      relevanceScore: 92,
    },
    {
      name: "Syndicat des Entreprises de Sécurité",
      description:
        "Informations sur les normes de sécurité et les équipements de protection",
      websiteUrl: "https://www.sdes-securite.fr",
      rssUrl: "https://www.sdes-securite.fr/flux-rss",
      category: "Sécurité",
      relevanceScore: 85,
    },
    {
      name: "Centre d'Études Supérieures de Sécurité",
      description:
        "Recherche et formation en sécurité du travail dans le BTP",
      websiteUrl: "https://www.cess-securite.fr",
      rssUrl: "",
      category: "Formation",
      relevanceScore: 78,
    },
    {
      name: "Fédération Française du Bâtiment - Sécurité",
      description: "Ressources et guides de sécurité pour les entreprises BTP",
      websiteUrl: "https://securite.ffbatiment.fr",
      rssUrl: "https://securite.ffbatiment.fr/rss",
      category: "Prévention",
      relevanceScore: 88,
    },
    {
      name: "Association Nationale pour la Prévention",
      description:
        "Actualités et études sur la prévention des accidents du travail",
      websiteUrl: "https://www.anp-prevention.fr",
      rssUrl: "https://www.anp-prevention.fr/actualites/rss",
      category: "Prévention",
      relevanceScore: 81,
    },
  ];
}

