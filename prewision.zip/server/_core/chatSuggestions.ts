/**
 * Dynamic chat suggestions based on context
 * Provides relevant follow-up questions based on user input
 */

interface SuggestionContext {
  userMessage: string;
  assistantResponse: string;
}

const suggestionMap: Record<string, string[]> = {
  // EPI-related suggestions
  epi: [
    "Quelles normes s'appliquent aux casques de sécurité ?",
    "Comment vérifier l'état de mes EPI ?",
    "Quels EPI pour les travaux électriques ?",
  ],
  ppe: [
    "Quelles normes s'appliquent aux casques de sécurité ?",
    "Comment vérifier l'état de mes EPI ?",
    "Quels EPI pour les travaux électriques ?",
  ],

  // Fall prevention
  chute: [
    "Quels équipements pour les travaux en hauteur ?",
    "Comment installer un harnais de sécurité ?",
    "Quelles sont les normes EN pour les chutes ?",
  ],
  hauteur: [
    "Quels équipements pour les travaux en hauteur ?",
    "Comment installer un harnais de sécurité ?",
    "Quelles sont les normes EN pour les chutes ?",
  ],
  échafaudage: [
    "Comment sécuriser un échafaudage ?",
    "Quelles sont les vérifications obligatoires ?",
    "Quels EPI pour les travaux en hauteur ?",
  ],

  // Electrical safety
  électrique: [
    "Quels sont les risques électriques sur un chantier ?",
    "Comment protéger les câbles électriques ?",
    "Quelles normes pour les installations électriques ?",
  ],
  électricité: [
    "Quels sont les risques électriques sur un chantier ?",
    "Comment protéger les câbles électriques ?",
    "Quelles normes pour les installations électriques ?",
  ],

  // Chemical hazards
  chimique: [
    "Comment gérer les produits chimiques sur un chantier ?",
    "Quels équipements pour les risques chimiques ?",
    "Quelles sont les règles de stockage des produits ?",
  ],
  produit: [
    "Comment gérer les produits chimiques sur un chantier ?",
    "Quels équipements pour les risques chimiques ?",
    "Quelles sont les règles de stockage des produits ?",
  ],

  // Training
  formation: [
    "Quelles formations sont obligatoires sur un chantier ?",
    "Comment organiser une formation sécurité ?",
    "Quels sont les certificats obligatoires ?",
  ],
  habilitation: [
    "Quelles formations sont obligatoires sur un chantier ?",
    "Comment obtenir une habilitation électrique ?",
    "Quels sont les certificats obligatoires ?",
  ],

  // Accident prevention
  accident: [
    "Comment prévenir les accidents sur un chantier ?",
    "Quelles sont les causes principales d'accidents ?",
    "Comment signaler un incident ?",
  ],
  incident: [
    "Comment signaler un incident sur un chantier ?",
    "Quelles sont les procédures d'urgence ?",
    "Comment remplir un rapport d'accident ?",
  ],

  // Regulations
  norme: [
    "Quelles sont les principales normes BTP ?",
    "Comment appliquer les normes DTU ?",
    "Quelles normes pour mon type de chantier ?",
  ],
  dtu: [
    "Quelles sont les principales normes DTU ?",
    "Comment appliquer les normes DTU sur un chantier ?",
    "Où trouver les documents DTU ?",
  ],
  réglementation: [
    "Quelles sont les principales réglementations BTP ?",
    "Comment rester conforme aux normes ?",
    "Quels contrôles sont obligatoires ?",
  ],

  // General
  chantier: [
    "Quels sont les équipements obligatoires sur un chantier ?",
    "Comment organiser la sécurité d'un chantier ?",
    "Quelles sont les responsabilités du chef de chantier ?",
  ],
  sécurité: [
    "Quels sont les équipements obligatoires sur un chantier ?",
    "Comment organiser la sécurité d'un chantier ?",
    "Quels sont les risques principaux du BTP ?",
  ],
};

export function getDynamicSuggestions(context: SuggestionContext): string[] {
  const { userMessage } = context;
  const lowerMessage = userMessage.toLowerCase();

  // Find matching keywords
  for (const [keyword, suggestions] of Object.entries(suggestionMap)) {
    if (lowerMessage.includes(keyword)) {
      // Shuffle and return 2-3 suggestions
      const shuffled = [...suggestions].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, 3);
    }
  }

  // Default suggestions if no keyword matches
  return [
    "Quels équipements de protection sont obligatoires ?",
    "Quelles sont les normes de sécurité pour mon chantier ?",
    "Comment prévenir les accidents sur un chantier ?",
  ];
}

export const DEFAULT_SUGGESTIONS = [
  "Quels équipements de protection sont obligatoires sur un chantier ?",
  "Quelles sont les normes de sécurité pour les travaux en hauteur ?",
  "Comment prévenir les risques électriques sur un chantier ?",
];

