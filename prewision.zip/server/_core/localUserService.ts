/**
 * Local user service for registration and authentication
 */

import { getDb } from "../db";
import { localUsers } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import * as bcrypt from "bcrypt";
import { randomBytes } from "crypto";

const BCRYPT_ROUNDS = 10;

export interface LocalUserInput {
  email: string;
  password: string;
  name?: string;
}

export async function registerUser(input: LocalUserInput): Promise<{
  success: boolean;
  userId?: number;
  error?: string;
}> {
  const db = await getDb();
  if (!db) return { success: false, error: "Database not available" };

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(input.email)) {
    return { success: false, error: "Invalid email format" };
  }

  // Validate password strength
  if (input.password.length < 8) {
    return { success: false, error: "Password must be at least 8 characters" };
  }

  try {
    // Check if user already exists
    const existingUser = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.email, input.email.toLowerCase()))
      .limit(1);

    if (existingUser.length > 0) {
      return { success: false, error: "Email already registered" };
    }

    // Hash password
    const passwordHash = await bcrypt.hash(input.password, BCRYPT_ROUNDS);

    // Generate email verification token
    const emailVerificationToken = randomBytes(32).toString("hex");

    // Insert user
    await db.insert(localUsers).values({
      email: input.email.toLowerCase(),
      passwordHash,
      name: input.name || input.email.split("@")[0],
      emailVerificationToken,
      isEmailVerified: false,
      isActive: true,
    });

    // Get the created user to return the ID
    const createdUser = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.email, input.email.toLowerCase()))
      .limit(1);

    return {
      success: true,
      userId: createdUser[0]?.id,
    };
  } catch (error) {
    console.error("Registration error:", error);
    return { success: false, error: "Registration failed" };
  }
}

export async function authenticateUser(
  email: string,
  password: string
): Promise<{
  success: boolean;
  userId?: number;
  email?: string;
  name?: string;
  error?: string;
}> {
  const db = await getDb();
  if (!db) return { success: false, error: "Database not available" };

  try {
    const user = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.email, email.toLowerCase()))
      .limit(1);

    if (user.length === 0) {
      return { success: false, error: "Invalid email or password" };
    }

    const userData = user[0];

    // Check if user is active
    if (!userData.isActive) {
      return { success: false, error: "User account is inactive" };
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, userData.passwordHash);
    if (!isPasswordValid) {
      return { success: false, error: "Invalid email or password" };
    }

    // Update last login
    await db
      .update(localUsers)
      .set({ lastLoginAt: new Date() })
      .where(eq(localUsers.id, userData.id));

    return {
      success: true,
      userId: userData.id,
      email: userData.email,
      name: userData.name || undefined,
    };
  } catch (error) {
    console.error("Authentication error:", error);
    return { success: false, error: "Authentication failed" };
  }
}

export async function getUserById(userId: number): Promise<{
  id: number;
  email: string;
  name: string | null;
  isEmailVerified: boolean;
  isActive: boolean;
  createdAt: Date;
} | null> {
  const db = await getDb();
  if (!db) return null;

  const user = await db
    .select()
    .from(localUsers)
    .where(eq(localUsers.id, userId))
    .limit(1);

  if (user.length === 0) return null;

  const userData = user[0];
  return {
    id: userData.id,
    email: userData.email,
    name: userData.name,
    isEmailVerified: userData.isEmailVerified,
    isActive: userData.isActive,
    createdAt: userData.createdAt,
  };
}

export async function getUserByEmail(email: string): Promise<{
  id: number;
  email: string;
  name: string | null;
  isEmailVerified: boolean;
  isActive: boolean;
  createdAt: Date;
} | null> {
  const db = await getDb();
  if (!db) return null;

  const user = await db
    .select()
    .from(localUsers)
    .where(eq(localUsers.email, email.toLowerCase()))
    .limit(1);

  if (user.length === 0) return null;

  const userData = user[0];
  return {
    id: userData.id,
    email: userData.email,
    name: userData.name,
    isEmailVerified: userData.isEmailVerified,
    isActive: userData.isActive,
    createdAt: userData.createdAt,
  };
}

export async function verifyUserEmail(token: string): Promise<{
  success: boolean;
  error?: string;
}> {
  const db = await getDb();
  if (!db) return { success: false, error: "Database not available" };

  try {
    const user = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.emailVerificationToken, token))
      .limit(1);

    if (user.length === 0) {
      return { success: false, error: "Invalid verification token" };
    }

    await db
      .update(localUsers)
      .set({
        isEmailVerified: true,
        emailVerificationToken: null,
        emailVerifiedAt: new Date(),
      })
      .where(eq(localUsers.id, user[0].id));

    return { success: true };
  } catch (error) {
    console.error("Email verification error:", error);
    return { success: false, error: "Verification failed" };
  }
}

export async function getAllUsers(limit: number = 100, offset: number = 0): Promise<{
  users: Array<{
    id: number;
    email: string;
    name: string | null;
    isEmailVerified: boolean;
    isActive: boolean;
    createdAt: Date;
    lastLoginAt: Date | null;
  }>;
  total: number;
}> {
  const db = await getDb();
  if (!db) return { users: [], total: 0 };

  const users = await db
    .select()
    .from(localUsers)
    .limit(limit)
    .offset(offset);

  return {
    users: users.map((u) => ({
      id: u.id,
      email: u.email,
      name: u.name,
      isEmailVerified: u.isEmailVerified,
      isActive: u.isActive,
      createdAt: u.createdAt,
      lastLoginAt: u.lastLoginAt,
    })),
    total: users.length,
  };
}

