/**
 * Article Scraper and Summarizer Service
 * Fetches articles from BTP safety sources and summarizes them using Perplexity AI
 */

import { JSDOM } from "jsdom";
import { callPerplexityWithHistory } from "./perplexityClient";

export interface ScrapedArticle {
  title: string;
  url: string;
  excerpt: string;
  publishedDate?: Date;
  imageUrl?: string;
  source: {
    name: string;
    url: string;
  };
}

export interface SummarizedArticle extends ScrapedArticle {
  summary: string;
}

/**
 * Source configurations for scraping
 */
export const ARTICLE_SOURCES = [
  {
    name: "INRS - Publications",
    url: "https://www.inrs.fr/publications",
    selector: ".article-item, .publication-item, article",
    titleSelector: "h2, h3, .title",
    linkSelector: "a",
    dateSelector: ".date, .published-date, time",
  },
  {
    name: "PreventionBTP - Actualités",
    url: "https://www.preventionbtp.fr/actualites",
    selector: ".article, .post, .news-item",
    titleSelector: "h2, h3, .title",
    linkSelector: "a",
    dateSelector: ".date, .published-date, time",
  },
  {
    name: "IRIS-ST - Risques et Métiers",
    url: "https://www.iris-st.org",
    selector: ".article-item, .post, .content-item",
    titleSelector: "h2, h3, .title",
    linkSelector: "a",
    dateSelector: ".date, .published-date, time",
  },
  {
    name: "Officiel Prévention - Dossiers",
    url: "https://www.officiel-prevention.com",
    selector: ".article, .post, .dossier",
    titleSelector: "h2, h3, .title",
    linkSelector: "a",
    dateSelector: ".date, .published-date, time",
  },
];

/**
 * Fetch and parse articles from a source
 */
export async function scrapeArticlesFromSource(
  source: (typeof ARTICLE_SOURCES)[0]
): Promise<ScrapedArticle[]> {
  try {
    console.log(`[Scraper] Fetching articles from ${source.name}...`);

    const response = await fetch(source.url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const html = await response.text();
    const dom = new JSDOM(html);
    const document = dom.window.document;

    const articles: ScrapedArticle[] = [];
    const articleElements = document.querySelectorAll(source.selector);

        // Limit to 5 articles per source
        const limit = Math.min(5, articleElements.length);

        for (let i = 0; i < limit; i++) {
          const element = articleElements[i] as Element;

      try {
        const titleElement = element.querySelector(source.titleSelector);
        const linkElement = element.querySelector(source.linkSelector);
        const dateElement = element.querySelector(source.dateSelector);

        if (!titleElement || !linkElement) continue;

        const title = titleElement.textContent?.trim() || "";
        const href = linkElement.getAttribute("href") || "";

        if (!title || !href) continue;

        // Resolve relative URLs
        const url = href.startsWith("http")
          ? href
          : new URL(href, source.url).toString();

        const excerpt = element.textContent?.substring(0, 200).trim() || "";
        const publishedDate = dateElement
          ? new Date(dateElement.textContent || "")
          : undefined;

        articles.push({
          title,
          url,
          excerpt,
          publishedDate,
          source: {
            name: source.name,
            url: source.url,
          },
        });
      } catch (error) {
        console.error(`[Scraper] Error parsing article element:`, error);
        continue;
      }
    }

    console.log(
      `[Scraper] Found ${articles.length} articles from ${source.name}`
    );
    return articles;
  } catch (error) {
    console.error(`[Scraper] Error scraping ${source.name}:`, error);
    return [];
  }
}

/**
 * Summarize an article using Perplexity AI
 */
export async function summarizeArticle(
  article: ScrapedArticle
): Promise<string> {
  try {
    const prompt = `Résume cet article sur la sécurité/santé BTP en français, de manière claire et concise, sans inclure de références, sources ou liens dans le résumé. Limite à 200 mots.

Titre: ${article.title}
Extrait: ${article.excerpt}
URL: ${article.url}`;

    const chatResponse = await callPerplexityWithHistory(prompt, [
      {
        role: "system",
        content:
          "Tu es un expert en sécurité et santé au travail dans le BTP. Résume les articles de manière claire, concise et accessible.",
      },
    ]);

    return chatResponse.response;
  } catch (error) {
    console.error(`[Summarizer] Error summarizing article:`, error);
    throw error;
  }
}

/**
 * Scrape and summarize articles from all sources
 */
export async function scrapeAndSummarizeArticles(): Promise<
  SummarizedArticle[]
> {
  const allArticles: SummarizedArticle[] = [];

  for (const source of ARTICLE_SOURCES) {
    try {
      const scrapedArticles = await scrapeArticlesFromSource(source);

      for (const article of scrapedArticles) {
        try {
          console.log(`[Summarizer] Summarizing: ${article.title}`);
          const summary = await summarizeArticle(article);

          allArticles.push({
            ...article,
            summary,
          });

          // Rate limiting - wait 2 seconds between API calls
          await new Promise((resolve) => setTimeout(resolve, 2000));
        } catch (error) {
          console.error(
            `[Summarizer] Failed to summarize article: ${article.title}`,
            error
          );
          continue;
        }
      }
    } catch (error) {
      console.error(`[Scraper] Failed to process source: ${source.name}`, error);
      continue;
    }
  }

  return allArticles;
}

/**
 * Fetch article content for better summarization
 */
export async function fetchArticleContent(url: string): Promise<string> {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const html = await response.text();
    const dom = new JSDOM(html);
    const document = dom.window.document;

    // Remove script and style elements
    document.querySelectorAll("script, style, nav, footer").forEach((el: Element) => {
      el.remove();
    });

    // Extract main content
    const mainContent =
      document.querySelector("main") ||
      document.querySelector("article") ||
      document.querySelector(".content") ||
      document.body;

    const text = mainContent?.textContent || "";

    // Clean up whitespace
    return text
      .replace(/\s+/g, " ")
      .trim()
      .substring(0, 2000);
  } catch (error) {
    console.error(`[ContentFetcher] Error fetching content from ${url}:`, error);
    return "";
  }
}

/**
 * Categorize article based on title and content
 */
export function categorizeArticle(
  article: ScrapedArticle
): "Sécurité" | "Santé" | "Prévention" | "Réglementation" | "Formation" | "Innovation" | "Autre" {
  const text = `${article.title} ${article.excerpt}`.toLowerCase();

  if (
    text.includes("sécurité") ||
    text.includes("accident") ||
    text.includes("risque")
  ) {
    return "Sécurité";
  } else if (
    text.includes("santé") ||
    text.includes("maladie") ||
    text.includes("bien-être")
  ) {
    return "Santé";
  } else if (
    text.includes("prévention") ||
    text.includes("protection") ||
    text.includes("équipement")
  ) {
    return "Prévention";
  } else if (
    text.includes("réglementation") ||
    text.includes("norme") ||
    text.includes("loi")
  ) {
    return "Réglementation";
  } else if (
    text.includes("formation") ||
    text.includes("cours") ||
    text.includes("webinaire")
  ) {
    return "Formation";
  } else if (
    text.includes("innovation") ||
    text.includes("technologie") ||
    text.includes("nouveau")
  ) {
    return "Innovation";
  }

  return "Autre";
}

